import {prepareEquipment, fetchEquipmentCatalog, canShowItemWinRate} from './equipment.mjs';
/** AramHex publishes anonymous aggregates under CC BY-NC 4.0. Keep provenance with the result. */
const repo = 'https://raw.githubusercontent.com/czgreat/aramhex-data';
const dragon = 'https://ddragon.leagueoflegends.com';
const needed = ['meta', 'heroes', 'hero_augments', 'augments'];
const optional = ['core_builds', 'hero_items', 'hero_item_holdings', 'equipment_recommendation_heroes', 'equipment_heroes', 'item_metadata','hero_augment_items'];

function insist(value, message) {
  if (!value) throw new Error(message);
}
function count(value, field) {
  insist(Number.isSafeInteger(value) && value >= 0, '数据中的' + field + '异常');
  return value;
}
function percent(part, all) {
  return all > 0 ? Number((100 * part / all).toFixed(6)) : null;
}
function tally(row) {
  const games = count(row.games, '样本数');
  const wins = count(row.wins, '胜场');
  insist(wins <= games, '胜场超过样本数');
  return {games, wins, winRate: percent(wins, games)};
}
function instant(value) {
  return typeof value === 'string' && Number.isFinite(Date.parse(value));
}
async function readJSON(url, hash) {
  const result = await fetch(url, {signal: AbortSignal.timeout(18000)});
  if (!result.ok) throw new Error('数据源返回 HTTP ' + result.status);
  const bytes = await result.arrayBuffer();
  if (hash) {
    const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', bytes));
    const actual = Array.from(digest, n => n.toString(16).padStart(2, '0')).join('');
    insist(actual === hash, '数据文件与发布清单不一致');
  }
  return JSON.parse(new TextDecoder().decode(bytes));
}
function dateOf(meta) {
  return meta.window?.end_exclusive ?? meta.snapshot_at;
}
export function previousNormalRelease(index,current) {
  const version=patch=>patch.split('.').map(Number).reduce((major,minor)=>1000*major+minor);
  return (index.datasets ?? []).filter(d=>d.mode==='normal' && /^\d{1,2}\.\d{1,2}$/.test(d.patch) &&
    d.path==='patches/'+d.patch+'/normal' && version(d.patch)<version(current.patch) &&
    Date.parse(dateOf(d))<=Date.parse(current.window?.start))
    .sort((a,b)=>version(b.patch)-version(a.patch) || Date.parse(dateOf(b))-Date.parse(dateOf(a)))[0];
}
export function prepareHoldingBaseline(release,meta,heroes,augmentRows,current) {
  insist(meta.patch===release.patch && meta.mode==='normal' && meta.snapshot_at===release.snapshot_at &&
    meta.matches.valid===release.matches && instant(dateOf(meta)) && Date.parse(dateOf(meta))<=Date.parse(current.window?.start) &&
    Boolean(meta.augment_exposure) && meta.augment_exposure===current.augment_exposure,'历史样本口径不匹配');
  let players=0;
  const totals={},byHero={};
  for(const [id,h] of Object.entries(heroes)){
    const games=count(h.games,'历史出场人次'), held={};
    players+=games;
    insist(augmentRows[id] && typeof augmentRows[id]==='object','缺少历史英雄表');
    for(const [aid,row] of Object.entries(augmentRows[id])){
      if(Object.hasOwn(meta.excluded_augments ?? {},aid))continue;
      const n=count(row.games,'历史持有人次');
      insist(n<=games,'历史持有超过出场人次');
      held[aid]=n;totals[aid]=(totals[aid] ?? 0)+n;
    }
    byHero[id]={games,held};
  }
  insist(players>0 && players===meta.matches.valid*10,'历史分母不匹配');
  return {patch:meta.patch,start:meta.window?.start,cutoff:dateOf(meta),matches:meta.matches.valid,players,totals,byHero};
}
async function fetchHoldingBaseline(base,index,current) {
  const release=previousNormalRelease(index,current);
  if(!release)return null;
  const files=await Promise.all(['meta','heroes','hero_augments'].map(name=>{
    const file=name+'.json', hash=release.files?.[file]?.sha256;
    insist(/^[0-9a-f]{64}$/.test(hash),'缺少历史样本校验');
    return readJSON(base+release.path+'/'+file,hash);
  }));
  return prepareHoldingBaseline(release,...files,current);
}
function matchingBatches(index, manifest, table) {
  const hash = manifest.files[table]?.sha256;
  if (!hash) return [];
  return (index.datasets ?? []).filter(d => d.mode === manifest.mode && d.files?.[table]?.sha256 === hash)
    .sort((a, b) => Date.parse(a.snapshot_at) - Date.parse(b.snapshot_at));
}
function tableSource(manifest, index, meta, table, noteRegex) {
  const note = (meta.notes ?? []).find(n => noteRegex.test(n) && /沿用|复用|上一期|上个版本/.test(n));
  const batches = matchingBatches(index, manifest, table);
  const prior = batches.find(d => d.patch !== manifest.patch);
  if (prior) {
    return {patch: prior.patch, cutoff: dateOf(prior), note: note ?? '此表沿用此前发布的同一份数据。'};
  }
  if (note) {
    const patch = note.match(/(?:沿用|复用)\s*(\d+\.\d+)/)?.[1] ?? null;
    return {patch, cutoff: null, note};
  }
  return {patch: manifest.patch, cutoff: dateOf(meta), note: ''};
}

export function prepareAugmentGear(meta, table, equipment) {
  const rule=meta.components?.destiny;
  if(!table || rule?.file!=='hero_augment_items.json' || rule.record!=='first legendary_items record')return null;
  const patch=rule.reused_from?.patch || (rule.updated_this_release===true?meta.patch:null);
  const cutoff=rule.end_exclusive;
  if(!patch || !instant(cutoff))return null;
  const gear=new Map(equipment.catalog.map(item=>[item.id,item]));
  const byHero={};
  for(const [heroId,records] of Object.entries(table)){
    const record=records['3081'];
    if(record?.source!=='stats' || !Array.isArray(record.items))continue;
    const rows=[];
    for(const row of record.items){
      const id=String(row.item), item=gear.get(id);
      if(item?.kind!=='complete' || !canShowItemWinRate(id,item))continue;
      const {games,winRate}=tally(row);
      if(games)rows.push({id,games,winRate:record.show_winrate===true?winRate:null});
    }
    byHero[heroId]=rows.sort((a,b)=>b.games-a.games);
  }
  return {augmentId:'3081',patch,cutoff,minimumGames:rule.minimum_games,minimumShare:rule.minimum_share,
    minimumSeconds:rule.minimum_duration_s,byHero};
}

export function prepareStats(manifest, tables, index = {}, catalog = {}, itemCatalog = {}) {
  const meta = tables.meta;
  const matches = count(meta.matches?.valid, '有效对局数');
  const cutoff = dateOf(meta);
  insist(matches > 0 && matches === manifest.matches && meta.patch === manifest.patch &&
    meta.mode === manifest.mode && meta.snapshot_at === manifest.snapshot_at && instant(cutoff),
    '批次元数据与发布清单不一致');
  const heroEntries = Object.entries(tables.heroes);
  const heroParticipations = heroEntries.reduce((n, [, h]) => n + count(h.games, '英雄出场人次'), 0);
  insist(heroParticipations === matches * 10 && (!meta.hero_participations || meta.hero_participations === heroParticipations),
    '英雄出场人次未与有效场次核对一致');
  const directory = Object.fromEntries(Object.values(catalog.data ?? {}).map(h => [h.key, h]));
  const augmentTotals = new Map();
  const buildsMeta = tableSource(manifest, index, meta, 'core_builds.json', /三件套|核心搭配/);
  const itemsMeta = tableSource(manifest, index, meta, 'hero_items.json', /普通成装|普通装备/);
  const itemMetadata = tables.item_metadata ?? {};
  const itemName = id => itemMetadata[id]?.name || '装备 ' + id;
  const excluded = meta.excluded_augments ?? {};
  const equipment = prepareEquipment(manifest,tables,index,itemCatalog);
  const itemDetails = new Map(equipment.catalog.map(i=>[i.id,i]));
  const canShowWins = id=>canShowItemWinRate(id,itemDetails.get(id));
  const heroes = heroEntries.map(([id, h]) => {
    const base = tally(h);
    const augmentCounts = {};
    const recorded = tables.hero_augments[id];
    insist(recorded && typeof recorded === 'object', '缺少英雄海克斯数据');
    for (const [aid, entry] of Object.entries(recorded)) {
      if (Object.hasOwn(excluded, aid)) continue;
      const games = count(entry.games, '持有人次');
      insist(games <= base.games, '持有人次超过英雄出场人次');
      augmentCounts[aid] = games;
      augmentTotals.set(aid, (augmentTotals.get(aid) ?? 0) + games);
    }
    const builds = (tables.core_builds?.[id] ?? []).filter(b => Array.isArray(b.items) && b.items.length === 3)
      .map(b => {
        const itemIds=b.items.map(String);
        const result=tally(b);
        if(!itemIds.every(canShowWins)) {result.winRate=null;result.wins=null;}
        return {items:b.items.map(itemName),itemIds,...result};
      });
    const denominatorTable = meta.equipment?.recommendation_denominator ?
      tables.equipment_recommendation_heroes : tables.equipment_heroes;
    const itemAppearances = denominatorTable?.[id]?.games ?? null;
    const sameItemWindow = itemsMeta.patch === manifest.patch && itemsMeta.cutoff === cutoff;
    const items = Object.entries(tables.hero_items?.[id] ?? {}).sort((a,b) => b[1].games - a[1].games)
      .map(([iid, item]) => ({
        id: iid, name: itemName(iid), ...tally(item),
        ...(!canShowWins(iid)?{wins:null,winRate:null}:{}),
        holdRate: sameItemWindow && itemAppearances ? percent(item.games, itemAppearances) : null
      }));
    const match = directory[id];
    const alias = match?.id ?? '';
    const icon = alias && catalog.version && /^[a-zA-Z0-9]+$/.test(alias) ?
      dragon + '/cdn/' + catalog.version + '/img/champion/' + alias + '.png' : '';
    return {
      id, name: h.name, title: h.title, alias, icon, ...base, itemAppearances,
      pickRate: percent(base.games, heroParticipations), appearancesPer100Matches: percent(base.games, matches),
      augmentCounts, builds, items
    };
  }).sort((a,b) => b.winRate - a.winRate || b.games - a.games);
  const augments = [...augmentTotals].map(([id, games]) => ({
    id, name: tables.augments[id]?.name ?? '强化 ' + id,
    rarity: tables.augments[id]?.rarity ?? 'unknown', games, holdRate: percent(games, heroParticipations)
  })).sort((a,b) => b.games - a.games);
  return {
    patch: meta.patch, seq: manifest.seq, mode: meta.mode, cutoff, start: meta.window?.start ?? null,
    schema:4, matches, heroParticipations, regions: meta.regions ?? [], heroes, augments, equipment, buildsMeta, itemsMeta,
    augmentGear:prepareAugmentGear(meta,tables.hero_augment_items,equipment),
    source: 'https://github.com/czgreat/aramhex-data', license: 'CC BY-NC 4.0'
  };
}

/** Fetch a complete, hash-verified release. Pass its previous numeric seq to skip unchanged snapshots. */
export async function fetchStats(previousSeq = 0) {
  const manifest = await readJSON(repo + '/main/latest.json');
  insist(manifest.schema_version === 1 && manifest.mode === 'normal' && /^\d+\.\d+$/.test(manifest.patch) &&
    manifest.path === 'patches/' + manifest.patch + '/normal' && Number.isSafeInteger(manifest.seq) && manifest.seq > 0,
    '数据清单格式发生变化');
  if (manifest.seq < previousSeq) throw new Error('上游清单早于已取得批次');
  if (manifest.seq === previousSeq) return null;
  const tagBase = repo + '/data-v' + manifest.seq + '/';
  const names = [...needed, ...optional.filter(n => manifest.files?.[n + '.json'])];
  const [tables, index, catalog, itemCatalog] = await Promise.all([
    Promise.all(names.map(async name => {
      const file = name + '.json';
      const hash = manifest.files?.[file]?.sha256;
      insist(typeof hash === 'string' && /^[0-9a-f]{64}$/.test(hash), '缺少发布校验值');
      return [name, await readJSON(tagBase + manifest.path + '/' + file, hash)];
    })).then(Object.fromEntries),
    readJSON(tagBase + 'index.json'),
    readJSON(dragon + '/cdn/' + manifest.patch + '.1/data/zh_CN/champion.json').catch(() => ({})),
    fetchEquipmentCatalog(manifest.patch)
  ]);
  const stats=prepareStats(manifest, tables, index, catalog, itemCatalog);
  stats.holdingBaseline=await fetchHoldingBaseline(tagBase,index,tables.meta).catch(()=>null);
  return stats;
}
