import {prepareEquipment, fetchEquipmentCatalog, canShowItemWinRate} from './equipment.mjs';
/** AramHex publishes anonymous aggregates under CC BY-NC 4.0. Keep provenance with the result. */
const repo = 'https://raw.githubusercontent.com/czgreat/aramhex-data';
const dragon = 'https://ddragon.leagueoflegends.com';
const needed = ['meta', 'heroes', 'hero_augments', 'augments'];
const optional = ['core_builds', 'hero_items', 'hero_item_holdings', 'equipment_recommendation_heroes', 'equipment_heroes', 'item_metadata','hero_augment_items','hero_item_recommendations'];

function insist(value, message) {
  if (!value) throw new Error(message);
}
function count(value, field) {
  insist(Number.isSafeInteger(value) && value >= 0, '数据中的' + field + '异常');
  return value;
}
function percent(part, all) {
  return all > 0 ? Number((100 * part / all).toFixed(6)) : null;
}
function tally(row) {
  const games = count(row.games, '样本数');
  const wins = count(row.wins, '胜场');
  insist(wins <= games, '胜场超过样本数');
  return {games, wins, winRate: percent(wins, games)};
}
function instant(value) {
  return typeof value === 'string' && Number.isFinite(Date.parse(value));
}
async function digest(bytes) {
  const hash=new Uint8Array(await crypto.subtle.digest('SHA-256',bytes));
  return Array.from(hash,n=>n.toString(16).padStart(2,'0')).join('');
}
async function readJSON(url,hash,fetcher=fetch) {
  const tag=url.match(/^https:\/\/raw\.githubusercontent\.com\/czgreat\/aramhex-data\/(main|data-v\d+)\/(.+)$/);
  const sources=[url];
  if(tag)sources.push('https://api.github.com/repos/czgreat/aramhex-data/contents/'+tag[2]+'?ref='+tag[1]);
  let failure;
  for(const source of sources){
    try{
      const api=source.startsWith('https://api.github.com/');
      const result=await fetcher(source,{cache:hash?'default':'no-cache',credentials:'omit',
        headers:api?{Accept:'application/vnd.github.raw+json'}:{},signal:AbortSignal.timeout(18000)});
      if(!result.ok)throw new Error('数据源返回 HTTP '+result.status);
      const bytes=await result.arrayBuffer();
      if(hash)insist(await digest(bytes)===hash,'数据文件与发布清单不一致');
      return JSON.parse(new TextDecoder().decode(bytes));
    }catch(error){failure=error;}
  }
  throw failure;
}
function dateOf(meta) {
  return meta.window?.end_exclusive ?? meta.snapshot_at;
}
export function previousNormalRelease(index,current) {
  const version=patch=>patch.split('.').map(Number).reduce((major,minor)=>1000*major+minor);
  return (index.datasets ?? []).filter(d=>d.mode==='normal' && /^\d{1,2}\.\d{1,2}$/.test(d.patch) &&
    d.path==='patches/'+d.patch+'/normal' && version(d.patch)<version(current.patch) &&
    Date.parse(dateOf(d))<=Date.parse(current.window?.start))
    .sort((a,b)=>version(b.patch)-version(a.patch) || Date.parse(dateOf(b))-Date.parse(dateOf(a)))[0];
}
export function prepareHoldingBaseline(release,meta,heroes,augmentRows,current) {
  insist(meta.patch===release.patch && meta.mode==='normal' && meta.snapshot_at===release.snapshot_at &&
    meta.matches.valid===release.matches && instant(dateOf(meta)) && Date.parse(dateOf(meta))<=Date.parse(current.window?.start) &&
    Boolean(meta.augment_exposure) && meta.augment_exposure===current.augment_exposure,'历史样本口径不匹配');
  let players=0;
  const totals={},byHero={};
  for(const [id,h] of Object.entries(heroes)){
    const games=count(h.games,'历史出场人次'), held={};
    players+=games;
    insist(augmentRows[id] && typeof augmentRows[id]==='object','缺少历史英雄表');
    for(const [aid,row] of Object.entries(augmentRows[id])){
      if(Object.hasOwn(meta.excluded_augments ?? {},aid))continue;
      const n=count(row.games,'历史持有人次');
      insist(n<=games,'历史持有超过出场人次');
      held[aid]=n;totals[aid]=(totals[aid] ?? 0)+n;
    }
    byHero[id]={games,held};
  }
  insist(players>0 && players===meta.matches.valid*10,'历史分母不匹配');
  return {patch:meta.patch,start:meta.window?.start,cutoff:dateOf(meta),matches:meta.matches.valid,players,totals,byHero};
}
async function fetchHoldingBaseline(base,release,current,fetcher) {
  if(!release)return {value:null,status:'not-published'};
  const read=name=>{
    const file=name+'.json', hash=release.files?.[file]?.sha256;
    insist(/^[0-9a-f]{64}$/.test(hash),'缺少历史样本校验');
    return readJSON(base+release.path+'/'+file,hash,fetcher);
  };
  const meta=await read('meta');
  if(!meta.augment_exposure || meta.augment_exposure!==current.augment_exposure)return {value:null,status:'not-comparable'};
  const [heroes,augments]=await Promise.all([read('heroes'),read('hero_augments')]);
  return {value:prepareHoldingBaseline(release,meta,heroes,augments,current),status:'ready'};
}
function matchingBatches(index, manifest, table) {
  const hash = manifest.files[table]?.sha256;
  if (!hash) return [];
  return (index.datasets ?? []).filter(d => d.mode === manifest.mode && d.files?.[table]?.sha256 === hash)
    .sort((a, b) => Date.parse(a.snapshot_at) - Date.parse(b.snapshot_at));
}
function tableSource(manifest, index, meta, table, noteRegex) {
  if(!manifest.files?.[table])return {patch:null,cutoff:null,note:'本批未发布此表。'};
  const note = (meta.notes ?? []).find(n => noteRegex.test(n) && /沿用|复用|上一期|上个版本/.test(n));
  const batches = matchingBatches(index, manifest, table);
  const prior = batches.find(d => d.patch !== manifest.patch);
  if (prior) {
    return {patch: prior.patch, cutoff: dateOf(prior), note: note ?? '此表沿用此前发布的同一份数据。'};
  }
  if (note) {
    const patch = note.match(/(?:沿用|复用)\s*(\d+\.\d+)/)?.[1] ?? null;
    return {patch, cutoff: null, note};
  }
  return {patch: manifest.patch, cutoff: dateOf(meta), note: ''};
}

async function readHighTable(base,index,current,file,fetcher){
  const candidates=(index.datasets || []).filter(d=>d.mode==='normal' && /^\d+\.\d+$/.test(d.patch) &&
    d.path==='patches/'+d.patch+'/normal' && d.bands===true && d.files?.[file] &&
    d.patch.localeCompare(current.patch,'en',{numeric:true})<=0 && Date.parse(dateOf(d))<=Date.parse(dateOf(current)))
    .sort((a,b)=>Date.parse(dateOf(b))-Date.parse(dateOf(a)));
  if(!candidates.length)return null;
  // A republished identical table retains the original sample window.
  const latest=candidates[0], batch=candidates.filter(d=>d.files[file].sha256===latest.files[file].sha256).at(-1);
  const read=name=>{
    const hash=batch.files[name]?.sha256;
    insist(/^[a-f0-9]{64}$/.test(hash),'分段表缺少发布校验值');
    return readJSON(base+batch.path+'/'+name,hash,fetcher);
  };
  const [meta,table]=await Promise.all([read('meta.json'),read(file)]);
  const bands=meta.bands,group=bands?.bands?.high;
  const cutoff=bands?.window?.end_exclusive ?? dateOf(meta);
  insist(meta.patch===batch.patch && meta.mode==='normal' && meta.snapshot_at===batch.snapshot_at &&
    instant(cutoff) && Date.parse(cutoff)<=Date.parse(dateOf(current)) && group?.label?.replace(/\s/g,'')==='前5%' &&
    meta.equipment?.bands?.includes('high'),'分段口径或版本待核实');
  return {meta,table,patch:batch.patch,cutoff,source:base+batch.path+'/'+file};
}
export async function fetchHighBuilds(base,index,current,equipment,fetcher=fetch){
  const batch=await readHighTable(base,index,current,'bands/high/core_builds.json',fetcher);
  if(!batch)return null;
  const {meta,table,patch,cutoff,source}=batch;
  insist(meta.equipment.core_table==='core_builds.json','三件套口径待核实');
  const items=new Map(equipment.catalog.map(i=>[i.id,i])),byHero={};
  for(const [id,rows] of Object.entries(table)){
    insist(/^\d+$/.test(id) && Array.isArray(rows),'分段英雄数据异常');
    byHero[id]=rows.map(row=>{
      insist(row.ordered===true && Array.isArray(row.items) && row.items.length===3 &&
        row.items.every(i=>/^\d+$/.test(String(i))),'分段三件套顺序待核实');
      const itemIds=row.items.map(String),{games,winRate}=tally(row);
      insist(games>0,'分段场数异常');
      return {itemIds,games,winRate:itemIds.every(i=>items.has(i) && canShowItemWinRate(i,items.get(i)))?winRate:null};
    }).sort((a,b)=>b.games-a.games);
  }
  insist(Object.values(byHero).some(rows=>rows.length),'分段三件套样本为空');
  return {patch,cutoff,source,byHero};
}

export function prepareAugmentGear(meta, table, equipment) {
  const rule=meta.components?.destiny;
  if(!table || rule?.file!=='hero_augment_items.json' || !['first legendary_items record','first SUMMARY legendary_items record'].includes(rule.record))return null;
  const patch=rule.reused_from?.patch || (rule.updated_this_release===true?meta.patch:null);
  const cutoff=rule.end_exclusive;
  if(!patch || !instant(cutoff))return null;
  const gear=new Map(equipment.catalog.map(item=>[item.id,item]));
  const byHero={};
  for(const [heroId,records] of Object.entries(table)){
    const record=records['3081'];
    if(record?.source!=='stats' || !Array.isArray(record.items))continue;
    const rows=[];
    for(const row of record.items){
      const id=String(row.item), item=gear.get(id);
      if(item?.kind!=='complete' || !canShowItemWinRate(id,item))continue;
      const {games,winRate}=tally(row);
      if(games)rows.push({id,games,winRate:record.show_winrate===true?winRate:null});
    }
    byHero[heroId]=rows.sort((a,b)=>b.games-a.games);
  }
  return {augmentId:'3081',patch,cutoff,minimumGames:rule.minimum_games,minimumShare:rule.minimum_share,
    minimumSeconds:rule.minimum_duration_s,byHero};
}

export async function fetchHighAugmentGear(base,index,current,equipment,fetcher=fetch){
  const batch=await readHighTable(base,index,current,'bands/high/hero_augment_items.json',fetcher);
  if(!batch)return null;
  const data=prepareAugmentGear(batch.meta,batch.table,equipment);
  insist(data && Date.parse(data.cutoff)<=Date.parse(batch.cutoff),'分段条件装备窗口待核实');
  return {...data,source:batch.source};
}

export function prepareStats(manifest, tables, index = {}, catalog = {}, itemCatalog = {}) {
  const meta = tables.meta;
  const matches = count(meta.matches?.valid, '有效对局数');
  const cutoff = dateOf(meta);
  insist(matches > 0 && matches === manifest.matches && meta.patch === manifest.patch &&
    meta.mode === manifest.mode && meta.snapshot_at === manifest.snapshot_at && instant(cutoff),
    '批次元数据与发布清单不一致');
  const heroEntries = Object.entries(tables.heroes);
  const heroParticipations = heroEntries.reduce((n, [, h]) => n + count(h.games, '英雄出场人次'), 0);
  insist(heroParticipations === matches * 10 && (meta.hero_participations == null || meta.hero_participations === heroParticipations),
    '英雄出场人次未与有效场次核对一致');
  insist(heroEntries.reduce((n,[,h])=>n+count(h.wins,'英雄胜场'),0)===matches*5,'英雄胜场未与有效场次核对一致');
  const directory = Object.fromEntries(Object.values(catalog.data ?? {}).map(h => [h.key, h]));
  const augmentTotals = new Map();
  const buildsMeta = tableSource(manifest, index, meta, 'core_builds.json', /三件套|核心搭配/);
  const recFile=meta.equipment?.recommendation_table ?? 'hero_items.json';
  const recDenomFile=meta.equipment?.recommendation_denominator ?? 'equipment_heroes.json';
  insist(['hero_items.json','hero_item_recommendations.json'].includes(recFile) &&
    ['equipment_heroes.json','equipment_recommendation_heroes.json'].includes(recDenomFile),'装备推荐表结构已变更');
  const recommended=tables[recFile.slice(0,-5)];
  const denominatorTable=tables[recDenomFile.slice(0,-5)];
  const itemsMeta=tableSource(manifest,index,meta,recFile,/普通成装|普通装备/);
  const denomMeta=tableSource(manifest,index,meta,recDenomFile,/普通成装|普通装备/);
  const sameItemWindow=itemsMeta.cutoff && denomMeta.cutoff && itemsMeta.patch===denomMeta.patch &&
    Date.parse(itemsMeta.cutoff)===Date.parse(denomMeta.cutoff);
  const itemMetadata = tables.item_metadata ?? {};
  const itemName = id => itemMetadata[id]?.name || '装备 ' + id;
  const excluded = meta.excluded_augments ?? {};
  const equipment = prepareEquipment(manifest,tables,index,itemCatalog);
  const itemDetails = new Map(equipment.catalog.map(i=>[i.id,i]));
  const canShowWins = id=>canShowItemWinRate(id,itemDetails.get(id));
  const heroes = heroEntries.map(([id, h]) => {
    const base = tally(h);
    const augmentCounts = {};
    const recorded = tables.hero_augments[id];
    insist(recorded && typeof recorded === 'object', '缺少英雄海克斯数据');
    for (const [aid, entry] of Object.entries(recorded)) {
      if (Object.hasOwn(excluded, aid)) continue;
      const games = count(entry.games, '持有人次');
      insist(games <= base.games, '持有人次超过英雄出场人次');
      augmentCounts[aid] = games;
      augmentTotals.set(aid, (augmentTotals.get(aid) ?? 0) + games);
    }
    const builds = (tables.core_builds?.[id] ?? []).filter(b => Array.isArray(b.items) && b.items.length === 3)
      .map(b => {
        const itemIds=b.items.map(String);
        const result=tally(b);
        if(!itemIds.every(canShowWins)) {result.winRate=null;result.wins=null;}
        return {items:b.items.map(itemName),itemIds,...result};
      });
    const rawDenominator=denominatorTable?.[id]?.games;
    if(sameItemWindow && Object.keys(recommended?.[id] ?? {}).length)insist(rawDenominator!=null,'有推荐装备统计的英雄缺少同一窗口分母');
    const itemAppearances=sameItemWindow && rawDenominator!=null?count(rawDenominator,'推荐装备分母'):null;
    const items=Object.entries(recommended?.[id] ?? {}).sort((a,b)=>b[1].games-a[1].games).map(([iid,item])=>{
      const row=tally(item);
      insist(itemAppearances==null || row.games<=itemAppearances,'推荐装备场数超过同一窗口分母');
      return {id:iid,name:itemName(iid),...row,...(!canShowWins(iid)?{wins:null,winRate:null}:{}),
        holdRate:itemAppearances?percent(row.games,itemAppearances):null};
    });
    const match = directory[id];
    const alias = match?.id ?? '';
    const icon = alias && catalog.version && /^[a-zA-Z0-9]+$/.test(alias) ?
      dragon + '/cdn/' + catalog.version + '/img/champion/' + alias + '.png' : '';
    return {
      id, name: h.name, title: h.title, alias, icon, ...base, itemAppearances,
      pickRate: percent(base.games, heroParticipations), appearancesPer100Matches: percent(base.games, matches),
      augmentCounts, builds, items
    };
  }).sort((a,b) => b.winRate - a.winRate || b.games - a.games);
  if(sameItemWindow && itemsMeta.patch===manifest.patch && meta.equipment?.recommendation_participations!=null){
    const total=heroes.reduce((sum,h)=>sum+(h.itemAppearances ?? 0),0);
    insist(total===count(meta.equipment.recommendation_participations,'推荐装备总分母'),'推荐装备分母与元数据不一致');
  }
  const augments = [...augmentTotals].map(([id, games]) => ({
    id, name: tables.augments[id]?.name ?? '强化 ' + id,
    rarity: tables.augments[id]?.rarity ?? 'unknown', games, holdRate: percent(games, heroParticipations)
  })).sort((a,b) => b.games - a.games);
  return {
    patch: meta.patch, seq: manifest.seq, mode: meta.mode, cutoff, start: meta.window?.start ?? null,
    schema:4, matches, heroParticipations, regions: meta.regions ?? [], heroes, augments, equipment, buildsMeta, itemsMeta,
    augmentGear:prepareAugmentGear(meta,tables.hero_augment_items,equipment),
    source: 'https://github.com/czgreat/aramhex-data', license: 'CC BY-NC 4.0'
  };
}

// A hero appearance contributes once to one unordered pair, and once to each member.
async function summonerSample(manifest,index,meta,heroes,version,previous,fetcher){
  const file='hero_spells.json', hash=manifest.files?.[file]?.sha256;
  if(!manifest.files?.[file])return {value:previous || null,status:'not-published'};
  try{
    insist(/^[a-f0-9]{64}$/.test(hash),'召唤师技能表缺少校验值');
    validIndex(index,manifest,['hero_spells']);
    const source=repo+'/data-v'+manifest.seq+'/'+manifest.path+'/'+file;
    const window=tableSource(manifest,index,meta,file,/召唤师技能/);
    const first=matchingBatches(index,manifest,file)[0];
    if(first?.patch===window.patch && dateOf(first)<window.cutoff)window.cutoff=dateOf(first);
    insist(!meta.components?.summoner_spells || meta.components.summoner_spells==='same-window' ||
      window.patch!==manifest.patch || window.cutoff!==dateOf(meta),'召唤师技能来源口径待核实');
    insist(window.patch && instant(window.cutoff),'召唤师技能统计窗口待核实');
    const raw=await readJSON(source,hash,fetcher);
    const byHero={};
    for(const [id,record] of Object.entries(raw)){
      insist(/^[1-9]\d*$/.test(id) && record && typeof record==='object' && !Array.isArray(record),'召唤师技能英雄数据异常');
      const pairs={}, sameWindow=window.patch===manifest.patch && window.cutoff===dateOf(meta);
      let games=0;
      for(const [key,row] of Object.entries(record)){
        const ids=key.split('+');
        insist(ids.length===2 && ids.every(i=>/^[1-9]\d{0,7}$/.test(i)) && ids[0]!==ids[1],'召唤师技能组合无效');
        const normalized=ids.sort((a,b)=>Number(a)-Number(b)).join('+');
        insist(!Object.hasOwn(pairs,normalized),'召唤师技能组合重复');
        pairs[normalized]=count(row.games,'召唤师技能场数');
        games+=pairs[normalized];
      }
      insist(Number.isSafeInteger(games) && (!sameWindow || (heroes[id] && games<=heroes[id].games)),'召唤师技能场数超过英雄分母');
      if(games)byHero[id]={games,pairs};
    }
    insist(Object.keys(byHero).length,'召唤师技能没有有效组合');
    const catalogVersion=version?.startsWith(window.patch+'.')?version:window.patch+'.1';
    let catalog=previous?.catalogVersion===catalogVersion?previous.catalog:null;
    if(!catalog){
      try{
        const book=await readJSON(dragon+'/cdn/'+catalogVersion+'/data/zh_CN/summoner.json',null,fetcher);
        insist(book.version===catalogVersion && book.data,'召唤师技能资料版本不符');
        const entries=Object.values(book.data).filter(r=>/^\d+$/.test(r.key) && r.name && /^[a-zA-Z0-9_]+\.png$/.test(r.image?.full));
        insist(entries.length,'召唤师技能目录为空');
        catalog=Object.fromEntries(entries.map(r=>[r.key,{name:r.name,image:r.image.full}]));
      }catch{/* Counts remain valid when the versioned names are temporarily unavailable. */}
    }
    return {value:{patch:window.patch,cutoff:window.cutoff,seq:manifest.seq,source,hash,byHero,catalogVersion,catalog:catalog || null},status:catalog?'ready':'pending'};
  }catch{return {value:previous || null,status:'pending'};}
}

function declaredTables(meta,tables){
  const equipment=meta.equipment || {};
  const files=[equipment.recommendation_table,equipment.recommendation_denominator,equipment.denominator,equipment.core_table,meta.components?.destiny?.file];
  for(const file of Object.keys(equipment.tables ?? {})){
    if(optional.includes(file.replace(/\.json$/,'')))files.push(file);
  }
  if(meta.components?.equipment_holdings==='same-window')files.push('hero_item_holdings.json','equipment_heroes.json');
  for(const file of files){
    if(file!=null)insist(typeof file==='string' && file.endsWith('.json') && Object.hasOwn(tables,file.slice(0,-5)),'缺少元数据声明的明细表 '+file);
  }
}
function validIndex(index,manifest,names){
  const batch=index.datasets?.find(v=>v.mode===manifest.mode && v.path===manifest.path && v.patch===manifest.patch &&
    v.matches===manifest.matches && v.snapshot_at===manifest.snapshot_at);
  insist(index.latest_seq===manifest.seq && batch &&
    names.every(name=>batch.files?.[name+'.json']?.sha256===manifest.files[name+'.json'].sha256),'发布标签索引与批次清单不符');
}
function enrichmentOf(stats){
  if(stats.enrichment)return stats.enrichment;
  const hasHeroes=stats.heroes.every(h=>h.alias && h.icon);
  return {champions:hasHeroes?'ready':'pending',dragonItems:stats.equipment.catalogVersion?'ready':'pending',
    communityItems:stats.equipment.communityPatch?'ready':'pending',previousHoldings:stats.holdingBaseline?'ready':'pending'};
}

async function gameBooks(patch,fetcher){
  const items=await fetchEquipmentCatalog(patch,fetcher);
  const version=items.dragonVersion || patch+'.1';
  let heroes={};
  try{
    const data=await readJSON(dragon+'/cdn/'+version+'/data/zh_CN/champion.json',null,fetcher);
    if(data?.version===version && data.data)heroes=data;
  }catch{/* Counts remain attributable to their source's champion ID and Chinese name. */}
  const revision=await digest(new TextEncoder().encode(JSON.stringify([heroes,items])));
  return {heroes,items,revision};
}

/** Automatic checks reuse complete batches. Manual checks also verify version-matched game files. */
export async function fetchStats(previousSeq=0,previous=null,manual=false,fetcher=fetch) {
  const manifest=await readJSON(repo+'/main/latest.json',null,fetcher);
  insist(manifest.schema_version===1 && manifest.mode==='normal' && /^\d+\.\d+$/.test(manifest.patch) &&
    manifest.path==='patches/'+manifest.patch+'/normal' && Number.isSafeInteger(manifest.seq) && manifest.seq>0,
    '数据清单格式发生变化');
  if(manifest.seq<previousSeq)throw new Error('上游清单早于已取得批次');
  const same=manifest.seq===previousSeq;
  if(same && previous?.seq===previousSeq)insist(previous.patch===manifest.patch,'同一统计批次的版本发生变化，等待新批号');
  const baseline=same && previous?.seq===previousSeq && previous.patch===manifest.patch ? previous:null;
  if(same && !baseline)return null;
  const names=[...needed,...optional.filter(n=>manifest.files?.[n+'.json'])];
  const identities=names.map(n=>{
    const hash=manifest.files?.[n+'.json']?.sha256;
    insist(typeof hash==='string' && /^[0-9a-f]{64}$/.test(hash),'缺少发布校验值');
    return [n,hash];
  });
  const releaseRevision=await digest(new TextEncoder().encode(JSON.stringify([manifest.path,manifest.snapshot_at,manifest.matches,identities])));
  if(baseline?.releaseRevision)insist(baseline.releaseRevision===releaseRevision,'同一统计批次的发布清单发生变化，等待新批号');
  const spellHash=manifest.files?.['hero_spells.json']?.sha256;
  if(baseline?.summonerSpells?.seq===manifest.seq)insist(spellHash===baseline.summonerSpells.hash,'同批召唤师技能清单发生变化');
  const checkedSpells=spellHash?baseline?.summonerSpells?.hash===spellHash && baseline?.summonerSpells?.seq===manifest.seq:
    baseline?.enrichment?.summonerSpells==='not-published';
  const complete=checkedSpells && baseline?.enrichment?.highBuilds && baseline.enrichment.highAugmentGear && !Object.values(enrichmentOf(baseline)).includes('pending');
  if(complete && !manual)return null;
  const booksPromise=gameBooks(manifest.patch,fetcher);
  if(complete && baseline.catalogFingerprint && (await booksPromise).revision===baseline.catalogFingerprint)return null;
  const tagBase=repo+'/data-v'+manifest.seq+'/';
  const requests=new Map();
  const [tables,index,books]=await Promise.all([
    Promise.all(names.map(async name=>{
      const file=name+'.json',hash=manifest.files?.[file]?.sha256;
      if(!requests.has(hash))requests.set(hash,readJSON(tagBase+manifest.path+'/'+file,hash,fetcher));
      return [name,await requests.get(hash)];
    })).then(Object.fromEntries),
    readJSON(tagBase+'index.json',null,fetcher),booksPromise
  ]);
  validIndex(index,manifest,names);
  declaredTables(tables.meta,tables);
  const prior=previousNormalRelease(index,tables.meta);
  const itemCatalog=books.items;
  const stats=prepareStats(manifest,tables,index,books.heroes,itemCatalog);
  const sourceFor=(batch,file)=>repo+'/data-v'+batch.seq+'/patches/'+batch.patch+'/normal/'+file+'.json';
  if(tables.core_builds)stats.buildsMeta.source=sourceFor(stats,'core_builds');
  else if(previous?.buildsMeta?.cutoff){
    const older=new Map(previous.heroes.map(h=>[h.id,h.builds]));
    for(const hero of stats.heroes)hero.builds=older.get(hero.id) || [];
    stats.buildsMeta={...previous.buildsMeta,source:previous.buildsMeta.source || sourceFor(previous,'core_builds')};
  }
  if(stats.augmentGear)stats.augmentGear.source=sourceFor(stats,'hero_augment_items');
  else if(!tables.hero_augment_items && previous?.augmentGear?.cutoff){
    stats.augmentGear={...previous.augmentGear,source:previous.augmentGear.source || sourceFor(previous,'hero_augment_items')};
  }
  stats.catalogFingerprint=books.revision;
  stats.releaseRevision=releaseRevision;
  const collectBand=(reader,previousValue)=>reader(tagBase,index,tables.meta,stats.equipment,fetcher)
    .then(value=>({value,status:value?'ready':'not-published'}))
    .catch(()=>({value:previousValue || null,status:'pending'}));
  const [history,high,highGear,spells]=await Promise.all([
    fetchHoldingBaseline(tagBase,prior,tables.meta,fetcher).catch(()=>({value:null,status:'pending'})),
    collectBand(fetchHighBuilds,previous?.highBuilds),collectBand(fetchHighAugmentGear,previous?.highAugmentGear),
    summonerSample(manifest,index,tables.meta,tables.heroes,itemCatalog.version,previous?.summonerSpells,fetcher)
  ]);
  stats.highBuilds=high.value;
  stats.highAugmentGear=highGear.value;
  stats.summonerSpells=spells.value;
  stats.holdingBaseline=history.value;
  stats.enrichment={champions:stats.heroes.every(h=>h.alias && h.icon)?'ready':'pending',
    dragonItems:itemCatalog.version?'ready':'pending',communityItems:itemCatalog.communityPatch?'ready':'pending',
    highBuilds:high.status,highAugmentGear:highGear.status,previousHoldings:history.status,summonerSpells:spells.status};
  if(baseline){
    const before=enrichmentOf(baseline);
    const regressed=Object.entries(stats.enrichment).some(([key,status])=>before[key]==='ready' && status!=='ready');
    insist(!regressed,'同一批次的已核验配套资料暂时不可读取，保留已取得数据');
    if(baseline.equipment.catalogVersion && stats.equipment.catalogVersion){
      insist(stats.equipment.catalogVersion.localeCompare(baseline.equipment.catalogVersion,'en',{numeric:true})>=0,
        '装备资料源暂时返回了较早的同版构建');
    }
  }
  stats.revision=await digest(new TextEncoder().encode(JSON.stringify(stats)));
  return stats.revision===baseline?.revision?null:stats;
}
