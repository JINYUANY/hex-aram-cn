// Versioned CN normal-mode offer rules. An observed final loadout cannot establish
// this measure: upgrades, transformations and grants can all change the loadout.
const poolMeasure = 'hero-augment-offer-eligibility';
const poolId = /^[1-9]\d{0,7}$/;
const poolPatch = /^\d{1,2}\.\d{1,2}$/;
const poolMaxBytes = 12 * 1024 * 1024;

function poolText(value, maxLength) {
  if (typeof value !== 'string' || !value.trim() || value.length > maxLength) {
    throw new Error('供选数据缺少有效的文字说明');
  }
  return value.trim();
}

function poolUrl(value) {
  const url = new URL(poolText(value, 2048));
  if (url.protocol !== 'https:' || url.username || url.password) throw new Error('供选来源必须使用 HTTPS 公开链接');
  return url.href;
}

function poolSource(source) {
  return {name: poolText(source?.name, 160), url: poolUrl(source?.url)};
}

function poolRecord(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function poolDate(value) {
  if (typeof value !== 'string' ||
      !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?(?:Z|[+-]\d{2}:\d{2})$/.test(value) ||
      !Number.isFinite(Date.parse(value))) throw new Error('供选来源缺少带时区的发布时间');
  const day = value.slice(0, 10);
  if (new Date(day + 'T00:00:00Z').toISOString().slice(0, 10) !== day) throw new Error('供选来源日期无效');
  return value;
}

export function validateHeroPool(raw, expectedPatch) {
  if (raw?.schema !== 1 || raw.measure !== poolMeasure || raw.region !== 'CN' || raw.mode !== 'normal' ||
      typeof expectedPatch !== 'string' || !poolPatch.test(expectedPatch) || raw.patch !== expectedPatch) {
    throw new Error('供选来源的版本、地区、模式或统计口径不匹配');
  }
  if (!poolRecord(raw.heroes)) throw new Error('供选来源缺少英雄列表');
  const publishedAt = poolDate(raw.publishedAt);
  const source = poolSource(raw.source);
  const heroes = {};
  for (const [heroId, hero] of Object.entries(raw.heroes)) {
    if (!poolId.test(heroId) || !poolRecord(hero) || typeof hero.complete !== 'boolean' || !Array.isArray(hero.rows)) {
      throw new Error('供选来源缺少英雄 ID 或明确的覆盖范围');
    }
    const seen = new Set();
    const rows = hero.rows.map(row => {
      if (typeof row?.augmentId !== 'string' || !poolId.test(row.augmentId) ||
          !['allowed', 'blocked'].includes(row.state) || seen.has(row.augmentId)) {
        throw new Error('强化符文的供选状态重复或无效');
      }
      seen.add(row.augmentId);
      return {augmentId: row.augmentId, state: row.state, detail: poolText(row.detail, 3000), source: poolSource(row.source),
        ...(row.name?{name:poolText(row.name,160)}:{}),...(row.icon?{icon:poolUrl(row.icon)}:{})};
    });
    // A complete list requires affirmative, hero-level provenance for exhaustiveness.
    // A missing hero or partial list leaves all omitted IDs unknown.
    if (hero.complete && !rows.some(row => row.state === 'allowed')) throw new Error('完整供选表缺少可选条目');
    heroes[heroId] = {complete: hero.complete, rows};
    if (hero.complete || hero.coverageSource != null) heroes[heroId].coverageSource = poolSource(hero.coverageSource);
  }
  return {schema: 1, measure: poolMeasure, region: 'CN', mode: 'normal', patch: expectedPatch, publishedAt, source, heroes};
}

export async function fetchHeroPool(url, expectedPatch, fetcher = fetch) {
  if (!url) return null;
  // Only a publisher-configured public URL is accepted by callers. Credentials
  // are never attached and a redirect cannot silently change the configured host.
  const response = await fetcher(poolUrl(url), {
    signal: AbortSignal.timeout(15000), credentials: 'omit', redirect: 'error',
    cache: 'no-store', headers: {Accept: 'application/json'}
  });
  if (!response.ok) throw new Error('供选来源请求失败（' + response.status + '）');
  if (Number(response.headers.get('content-length')) > poolMaxBytes || !response.body) throw new Error('供选来源内容大小无效');
  const reader = response.body.getReader();
  const decoder = new TextDecoder('utf-8', {fatal: true});
  let bytes = 0, content = '';
  try {
    while (true) {
      const {done, value} = await reader.read();
      if (done) break;
      bytes += value.byteLength;
      if (bytes > poolMaxBytes) {
        await reader.cancel();
        throw new Error('供选来源内容超出大小限制');
      }
      content += decoder.decode(value, {stream: true});
    }
    content += decoder.decode();
  } finally {
    reader.releaseLock();
  }
  return validateHeroPool(JSON.parse(content), expectedPatch);
}
