// Each document is evidence about changes announced on that date, not a current full modifier table.
const patchPattern = /^\d{2}\.\d{1,2}$/;
const isoDate = /^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{1,3})?(?:Z|[+-]\d\d:\d\d)$/;
const kinds = new Set(['buff','nerf','adjust','fix','new','other']);

function validDocument(doc) {
  if (!doc || !patchPattern.test(doc.patch) || !patchPattern.test(doc.samplePatch) ||
      !isoDate.test(doc.publishedAt) || !Number.isFinite(Date.parse(doc.publishedAt)) ||
      typeof doc.title !== 'string' || !doc.title.trim() || typeof doc.hotfix !== 'boolean' ||
      !Array.isArray(doc.entries) || doc.entries.length > 1000) return false;
  const [season, minor] = doc.patch.split('.');
  const clientMajor = Number(season) >= 25 ? Number(season) - 10 : Number(season);
  if (doc.samplePatch !== clientMajor + '.' + minor) return false;
  try {
    const url = new URL(doc.url);
    if (url.origin !== 'https://lol.qq.com' || url.username || url.password) return false;
  } catch { return false; }
  return doc.entries.every(row => row && ['aram','mayhem'].includes(row.mode) && kinds.has(row.kind) &&
    typeof row.name === 'string' && row.name.trim() && row.name.length <= 120 && Array.isArray(row.details) &&
    row.details.length > 0 && row.details.length <= 100 && row.details.every(s => typeof s === 'string' && s.trim() && s.length <= 5000));
}

export function validateBalanceNotices(raw) {
  if (raw?.schema !== 1 || raw.region !== 'CN' || !Array.isArray(raw.documents) || raw.documents.length > 80 ||
      !raw.documents.every(validDocument) || new Set(raw.documents.map(d => d.url)).size !== raw.documents.length) {
    throw new Error('国服英雄平衡公告档案无效');
  }
  return raw;
}

export function mergeBalanceNotices(previous, official) {
  const history = previous ? validateBalanceNotices(previous) : {schema:1, region:'CN', documents:[]};
  const notes = official?.mayhem;
  if (official?.notesPending || !notes || !Array.isArray(notes.balanceEntries) || notes.url !== official.url ||
      notes.patch !== official.patch || notes.samplePatch !== official.samplePatch || notes.publishedAt !== official.publishedAt) return history;
  const incoming = [
    {title: notes.title, url: notes.url, publishedAt: notes.publishedAt, hotfix:false, entries:notes.balanceEntries},
    ...(notes.balanceHotfixes || []).filter(d => official.hotfixes?.some(h => h.url === d.url && h.publishedAt === d.publishedAt))
      .map(d => ({...d, hotfix:true}))
  ].map(d => ({...d, patch:notes.patch, samplePatch:notes.samplePatch}));
  if (!incoming.every(validDocument)) throw new Error('国服英雄平衡条目来源无效');
  // A corrected main article replaces its earlier address. A temporarily unavailable
  // hotfix keeps its dated evidence until we have parsed a verified replacement.
  const current = new Map(history.documents.filter(d => d.hotfix || d.patch !== notes.patch).map(d => [d.url,d]));
  for (const doc of incoming) {
    if (doc.entries.length) current.set(doc.url,doc);
    else current.delete(doc.url);
  }
  const documents = [...current.values()].sort((a,b) => Date.parse(b.publishedAt) - Date.parse(a.publishedAt) || a.url.localeCompare(b.url));
  return {schema:1, region:'CN', documents:documents.slice(0,80)};
}
