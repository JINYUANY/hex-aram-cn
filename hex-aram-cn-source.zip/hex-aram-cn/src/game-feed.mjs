import {fetchOfficial} from './official.mjs';
import {fetchMayhemNotes} from './mayhem-notes.mjs';
import {fetchHeroPool,validateHeroPool} from './hero-pool.mjs';

import {mergeBalanceNotices,validateBalanceNotices} from './balance-notices.mjs';
import {fetchChampionBalance,validateChampionBalance} from './champion-balance.mjs';

const patchFormat=/^\d{1,2}\.\d{1,2}$/;
function orderPatch(v){const [a,b]=v.split('.').map(Number);return a*100+b;}
function tencentLink(url){try{return new URL(url).origin==='https://lol.qq.com';}catch{return false;}}
function sameArticle(a,b){return a?.url===b?.url && a?.patch===b?.patch && a?.samplePatch===b?.samplePatch;}
export function carryBalanceSkills(incoming,previous){
  if(!incoming || !previous || incoming.patch!==previous.patch)return incoming;
  let modes=incoming.modes;
  for(const key of ['aram','mayhem']){
    const mode=modes[key],saved=previous.modes[key];
    if(mode?.skillsByHero==null && saved?.skillsByHero && mode.source?.url && mode.source.url===saved.source?.url){
      modes={...modes,[key]:{...mode,skillsByHero:saved.skillsByHero}};
    }
  }
  return modes===incoming.modes?incoming:{...incoming,modes};
}
export function validateGameFeed(raw){
  const o=raw?.official;
  if(raw?.schema!==1 || raw.region!=='CN' || raw.mode!=='normal' || !patchFormat.test(o?.patch) || !patchFormat.test(o.samplePatch) ||
    !tencentLink(o.url) || !tencentLink(o.listUrl) || !o.title || !Number.isFinite(Date.parse(o.publishedAt)) || !Number.isFinite(Date.parse(o.checkedAt)) ||
    !Array.isArray(o.hotfixes) || o.hotfixes.some(h=>!tencentLink(h.url) || !h.title || !Number.isFinite(Date.parse(h.publishedAt))))throw Error('国服公告快照无效');
  const [season,minor]=o.patch.split('.');
  if(o.samplePatch!==String(Number(season)>=25?Number(season)-10:Number(season))+'.'+minor)throw Error('国服公告和客户端版本不对应');
  const validEntry=e=>['buff','nerf','adjust','new','fix','other'].includes(e?.kind) && typeof e.name==='string' &&
    Array.isArray(e.details) && e.details.every(s=>typeof s==='string');
  if(o.mayhem && (!sameArticle(o,o.mayhem) || o.mayhem.schema!==1 || !Array.isArray(o.mayhem.entries) ||
    !o.mayhem.entries.every(validEntry)))throw Error('公告正文版本或条目无效');
  if(o.mayhem?.pendingHotfixes && (!Array.isArray(o.mayhem.pendingHotfixes) || o.mayhem.pendingHotfixes.some(url=>!o.hotfixes.some(h=>h.url===url))))throw Error('热修待核实列表无效');
  if(o.mayhem?.hotfixDetails && (!Array.isArray(o.mayhem.hotfixDetails) || o.mayhem.hotfixDetails.some(h=>
    !tencentLink(h.url) || !o.hotfixes.some(x=>x.url===h.url) || !Array.isArray(h.entries) || !h.entries.every(validEntry))))throw Error('热修范围无效');
  if(o.balanceNotices)validateBalanceNotices(o.balanceNotices);
  if(o.championBalance)validateChampionBalance(o.championBalance,o.samplePatch);
  if(o.heroPool)o.heroPool=validateHeroPool(o.heroPool,o.samplePatch);
  if(raw.aramgg){
    const {catalog,config,status}=raw.aramgg;
    if(status!=='ready' || !catalog || !patchFormat.test(config?.patch) || !Number.isInteger(config.release) ||
        config.version!==config.patch+'.'+config.release || catalog.patch!==config.patch || catalog.version!==config.version ||
        !Array.isArray(catalog.heroes) || !catalog.heroes.length || catalog.heroes.some(h=>!/^\d+$/.test(h.id) ||
          !h.name || !Number.isFinite(h.winRate) || h.winRate<0 || h.winRate>100 ||
          (h.pickRate!=null && (!Number.isFinite(h.pickRate) || h.pickRate<0 || h.pickRate>100)) ||
          (h.games!=null && (!Number.isSafeInteger(h.games) || h.games<0))))throw Error('授权国服英雄榜无效');
  }
  return raw;
}
async function currentBalanceRoster(patch,fallback,fetcher){
  try{
    const version=patch+'.1';
    const result=await fetcher('https://ddragon.leagueoflegends.com/cdn/'+version+'/data/zh_CN/champion.json',
      {signal:AbortSignal.timeout(10000),credentials:'omit'});
    if(!result.ok)return fallback;
    const book=await result.json();
    if(book.version!==version || !book.data)return fallback;
    const heroes=new Map(fallback.map(h=>[String(h.id),h]));
    for(const c of Object.values(book.data)){
      if(/^[1-9]\d*$/.test(c.key) && c.id && c.name && c.title)heroes.set(c.key,{id:c.key,alias:c.id,name:c.title,title:c.name});
    }
    return [...heroes.values()];
  }catch{return fallback;}
}
export async function collectGame(previous,poolURL,fetcher=fetch,roster=[]){
  const o=await fetchOfficial(fetcher);
  if(previous && orderPatch(o.patch)<orderPatch(previous.patch))throw Error('公告版本倒退');
  const same=sameArticle(o,previous);
  if(same){
    if(!o.hotfixesAvailable)o.hotfixes=previous.hotfixes || [];
    o.maintenanceStart ||= previous.maintenanceStart;
    o.maintenanceEnd ||= previous.maintenanceEnd;
    if(o.publishedAt.endsWith('T00:00:00+08:00') && o.publishedAt.slice(0,10)===previous.publishedAt.slice(0,10))o.publishedAt=previous.publishedAt;
  }
  const [notes,rules]=await Promise.allSettled([fetchMayhemNotes(o,fetcher),fetchHeroPool(poolURL,o.samplePatch,fetcher)]);
  o.notesPending=notes.status==='rejected';
  o.mayhem=notes.status==='fulfilled'?notes.value:same?previous.mayhem:null;
  if(same && notes.status==='fulfilled' && previous.mayhem?.hotfixDetails?.length){
    const current=new Set((o.mayhem.hotfixDetails || []).map(h=>h.url));
    for(const h of previous.mayhem.hotfixDetails){
      if(!current.has(h.url) && o.mayhem.pendingHotfixes.includes(h.url) && o.hotfixes.some(link=>link.url===h.url))o.mayhem.hotfixDetails.push(h);
    }
  }
  if(o.mayhem?.hotfixDetails){
    o.mayhem={...o.mayhem,hotfixes:o.hotfixes,pendingHotfixes:(o.mayhem.pendingHotfixes || []).filter(url=>o.hotfixes.some(h=>h.url===url)),hotfixDetails:o.mayhem.hotfixDetails.filter(doc=>o.hotfixes.some(h=>h.url===doc.url))};
  }
  o.poolPending=rules.status==='rejected';
  const prior=previous?.heroPool?.patch===o.samplePatch?previous.heroPool:null;
  o.heroPool=rules.status==='fulfilled' && rules.value && (!prior || Date.parse(rules.value.publishedAt)>=Date.parse(prior.publishedAt))?rules.value:prior;
  o.balanceNotices=mergeBalanceNotices(previous?.balanceNotices,o);
  const priorBalance=previous?.championBalance?.patch===o.samplePatch?previous.championBalance:null;
  o.championBalance=priorBalance;
  if(roster.length){
    try{o.championBalance=await fetchChampionBalance(o,await currentBalanceRoster(o.samplePatch,roster,fetcher),priorBalance,fetcher);}
    catch{o.balancePending=true;}
  }
  return validateGameFeed({schema:1,region:'CN',mode:'normal',official:o}).official;
}
const feedURL='https://raw.githubusercontent.com/JINYUANY/hex-aram-cn/main/live-data.json';
const pendingFeeds=new Map();
async function requestFeed(url,headers,fetcher){
  const result=await fetcher(url,{credentials:'omit',referrerPolicy:'no-referrer',cache:'no-store',headers,signal:AbortSignal.timeout(10000)});
  if(!result.ok)throw Error('公告同步源暂不可用');
  return validateGameFeed(await result.json());
}
function latestFeed(results){
  const feeds=results.filter(r=>r.status==='fulfilled').map(r=>r.value);
  if(!feeds.length)throw Error('公告同步源暂不可用');
  const latest=feeds.reduce((first,next)=>{
    const order=orderPatch(next.official.patch)-orderPatch(first.official.patch);
    return order>0 || (order===0 && Date.parse(next.official.checkedAt)>Date.parse(first.official.checkedAt))?next:first;
  });
  const catalogs=feeds.map(f=>f.aramgg).filter(Boolean);
  const aramgg=catalogs.sort((a,b)=>b.config.version.localeCompare(a.config.version,'en',{numeric:true}))[0];
  const pairSamples=feeds.flatMap(f=>Array.isArray(f.pairSamples)?f.pairSamples:[]);
  return {...latest,aramgg:aramgg || null,...(pairSamples.length?{pairSamples}:{})};
}
export function readGameFeed(manual=false,fetcher=fetch){
  if(!manual && pendingFeeds.has(true))return pendingFeeds.get(true);
  if(pendingFeeds.has(manual))return pendingFeeds.get(manual);
  const stamp=manual?Date.now():Math.floor(Date.now()/60000);
  const raw=()=>requestFeed(feedURL+'?t='+stamp,{},fetcher);
  const backup=()=>requestFeed('https://api.github.com/repos/JINYUANY/hex-aram-cn/contents/live-data.json?ref=main&t='+stamp,
    {Accept:'application/vnd.github.raw+json'},fetcher);
  const request=manual?Promise.allSettled([raw(),backup()]).then(latestFeed):raw().catch(backup);
  const pending=request.finally(()=>pendingFeeds.delete(manual));
  pendingFeeds.set(manual,pending);
  return pending;
}

export function mergeBrowserNews(previous,mirror,directory,now){
  const detailTime=o=>o.detailCheckedAt===undefined?o.checkedAt:o.detailCheckedAt;
  let base=previous;
  if(mirror && (orderPatch(mirror.patch)>orderPatch(base.patch) ||
    (mirror.patch===base.patch && Date.parse(mirror.checkedAt)>=(Date.parse(detailTime(base)) || 0) &&
     (mirror.url===base.url || mirror.publishedAt>=base.publishedAt))))base=mirror;
  const pending=previous.directoryPending;
  const result={...base,detailCheckedAt:detailTime(base),directoryPending:
    pending && pending.url!==base.url && pending.publishedAt>base.publishedAt?pending:null};
  // A body mirror may predate the last directory check, even on the same patch.
  if(base===mirror && previous.url===base.url && previous.directoryAt>mirror.checkedAt){
    result.directoryAt=previous.directoryAt;
    const links=new Map([...previous.hotfixes,...base.hotfixes].map(h=>[h.url,h]));
    result.hotfixes=[...links.values()];
    if(result.mayhem){
      const parsed=new Set((result.mayhem.hotfixDetails || []).map(h=>h.url));
      result.mayhem={...result.mayhem,hotfixes:result.hotfixes,pendingHotfixes:result.hotfixes.filter(h=>!parsed.has(h.url)).map(h=>h.url)};
    }
  }
  if(!directory){
    if(!mirror || base!==mirror)throw Error('腾讯目录及同版本公告镜像未核实');
    return {...result,newsChannel:'mirror'};
  }
  const {head,patch,hotfixes}=directory;
  const same=head.url===base.url && (!patch || patch===base.patch);
  if(!patch && !same && head.publishedAt>=base.publishedAt){
    return {...result,directoryPending:head,directoryAt:now,newsChannel:'pending'};
  }
  if((patch && orderPatch(patch)<orderPatch(base.patch)) || (!same && head.publishedAt<base.publishedAt)){
    return {...result,newsChannel:'directory-behind',directoryAt:now};
  }
  if(!same && !patch)throw Error('公告正文待核实');
  const latest=same?result:{
    ...head,patch,samplePatch:patch.replace(/^\d+/,s=>String(Number(s)>=25?Number(s)-10:Number(s))),
    listUrl:base.listUrl,detailCheckedAt:null,notesPending:true,mayhem:null,
    balanceNotices:base.balanceNotices,heroPool:null,championBalance:null
  };
  const links=new Map([...hotfixes,...(same?result.hotfixes:[])].map(h=>[h.url,h]));
  latest.hotfixes=[...links.values()].sort((a,b)=>b.publishedAt.localeCompare(a.publishedAt));
  if(latest.mayhem){
    const ready=new Set((latest.mayhem.hotfixDetails || []).map(h=>h.url));
    latest.mayhem={...latest.mayhem,hotfixes:latest.hotfixes,pendingHotfixes:latest.hotfixes.filter(h=>!ready.has(h.url)).map(h=>h.url)};
  }
  return validateGameFeed({schema:1,region:'CN',mode:'normal',official:{...latest,hotfixesAvailable:true,
    directoryAt:now,checkedAt:now,newsChannel:'direct'}}).official;
}
