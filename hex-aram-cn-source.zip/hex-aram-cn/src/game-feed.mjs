import {fetchOfficial} from './official.mjs';
import {fetchMayhemNotes} from './mayhem-notes.mjs';
import {fetchHeroPool,validateHeroPool} from './hero-pool.mjs';

import {mergeBalanceNotices,validateBalanceNotices} from './balance-notices.mjs';
import {fetchChampionBalance,validateChampionBalance} from './champion-balance.mjs';

const patchFormat=/^\d{1,2}\.\d{1,2}$/;
function orderPatch(v){const [a,b]=v.split('.').map(Number);return a*100+b;}
function tencentLink(url){try{return new URL(url).origin==='https://lol.qq.com';}catch{return false;}}
function sameArticle(a,b){return a?.url===b?.url && a?.patch===b?.patch && a?.samplePatch===b?.samplePatch;}
export function validateGameFeed(raw){
  const o=raw?.official;
  if(raw?.schema!==1 || raw.region!=='CN' || raw.mode!=='normal' || !patchFormat.test(o?.patch) || !patchFormat.test(o.samplePatch) ||
    !tencentLink(o.url) || !tencentLink(o.listUrl) || !o.title || !Number.isFinite(Date.parse(o.publishedAt)) || !Number.isFinite(Date.parse(o.checkedAt)) ||
    !Array.isArray(o.hotfixes) || o.hotfixes.some(h=>!tencentLink(h.url) || !h.title || !Number.isFinite(Date.parse(h.publishedAt))))throw Error('国服公告快照无效');
  const [season,minor]=o.patch.split('.');
  if(o.samplePatch!==String(Number(season)>=25?Number(season)-10:Number(season))+'.'+minor)throw Error('国服公告和客户端版本不对应');
  const validEntry=e=>['buff','nerf','adjust','new','fix','other'].includes(e?.kind) && typeof e.name==='string' &&
    Array.isArray(e.details) && e.details.every(s=>typeof s==='string');
  if(o.mayhem && (!sameArticle(o,o.mayhem) || o.mayhem.schema!==1 || !Array.isArray(o.mayhem.entries) ||
    !o.mayhem.entries.every(validEntry)))throw Error('公告正文版本或条目无效');
  if(o.mayhem?.hotfixDetails && (!Array.isArray(o.mayhem.hotfixDetails) || o.mayhem.hotfixDetails.some(h=>
    !tencentLink(h.url) || !o.hotfixes.some(x=>x.url===h.url) || !Array.isArray(h.entries) || !h.entries.every(validEntry))))throw Error('热修范围无效');
  if(o.balanceNotices)validateBalanceNotices(o.balanceNotices);
  if(o.championBalance)validateChampionBalance(o.championBalance,o.samplePatch);
  if(o.heroPool)o.heroPool=validateHeroPool(o.heroPool,o.samplePatch);
  if(raw.aramgg){
    const {catalog,config,status}=raw.aramgg;
    if(status!=='ready' || !catalog || !patchFormat.test(config?.patch) || !Number.isInteger(config.release) ||
        config.version!==config.patch+'.'+config.release || catalog.patch!==config.patch || catalog.version!==config.version ||
        !Array.isArray(catalog.heroes) || !catalog.heroes.length || catalog.heroes.some(h=>!/^\d+$/.test(h.id) ||
          !h.name || !Number.isFinite(h.winRate) || h.winRate<0 || h.winRate>100 ||
          (h.pickRate!=null && (!Number.isFinite(h.pickRate) || h.pickRate<0 || h.pickRate>100)) ||
          (h.games!=null && (!Number.isSafeInteger(h.games) || h.games<0))))throw Error('授权国服英雄榜无效');
  }
  return raw;
}
async function currentBalanceRoster(patch,fallback,fetcher){
  try{
    const version=patch+'.1';
    const result=await fetcher('https://ddragon.leagueoflegends.com/cdn/'+version+'/data/zh_CN/champion.json',
      {signal:AbortSignal.timeout(10000),credentials:'omit'});
    if(!result.ok)return fallback;
    const book=await result.json();
    if(book.version!==version || !book.data)return fallback;
    const heroes=new Map(fallback.map(h=>[String(h.id),h]));
    for(const c of Object.values(book.data)){
      if(/^[1-9]\d*$/.test(c.key) && c.id && c.name && c.title)heroes.set(c.key,{id:c.key,alias:c.id,name:c.title,title:c.name});
    }
    return [...heroes.values()];
  }catch{return fallback;}
}
export async function collectGame(previous,poolURL,fetcher=fetch,roster=[]){
  const o=await fetchOfficial(fetcher);
  if(previous && orderPatch(o.patch)<orderPatch(previous.patch))throw Error('公告版本倒退');
  const same=sameArticle(o,previous);
  if(same){
    if(!o.hotfixesAvailable)o.hotfixes=previous.hotfixes || [];
    o.maintenanceStart ||= previous.maintenanceStart;
    o.maintenanceEnd ||= previous.maintenanceEnd;
    if(o.publishedAt.endsWith('T00:00:00+08:00') && o.publishedAt.slice(0,10)===previous.publishedAt.slice(0,10))o.publishedAt=previous.publishedAt;
  }
  const [notes,rules]=await Promise.allSettled([fetchMayhemNotes(o,fetcher),fetchHeroPool(poolURL,o.samplePatch,fetcher)]);
  o.notesPending=notes.status==='rejected';
  o.mayhem=notes.status==='fulfilled'?notes.value:same?previous.mayhem:null;
  if(same && notes.status==='fulfilled' && previous.mayhem?.hotfixDetails?.length){
    const current=new Set((o.mayhem.hotfixDetails || []).map(h=>h.url));
    for(const h of previous.mayhem.hotfixDetails){
      if(!current.has(h.url) && o.hotfixes.some(link=>link.url===h.url))o.mayhem.hotfixDetails.push(h);
    }
  }
  if(o.mayhem?.hotfixDetails){
    o.mayhem={...o.mayhem,hotfixes:o.hotfixes,hotfixDetails:o.mayhem.hotfixDetails.filter(doc=>o.hotfixes.some(h=>h.url===doc.url))};
  }
  o.poolPending=rules.status==='rejected';
  const prior=previous?.heroPool?.patch===o.samplePatch?previous.heroPool:null;
  o.heroPool=rules.status==='fulfilled' && rules.value && (!prior || Date.parse(rules.value.publishedAt)>=Date.parse(prior.publishedAt))?rules.value:prior;
  o.balanceNotices=mergeBalanceNotices(previous?.balanceNotices,o);
  const priorBalance=previous?.championBalance?.patch===o.samplePatch?previous.championBalance:null;
  o.championBalance=priorBalance;
  if(roster.length){
    try{o.championBalance=await fetchChampionBalance(o,await currentBalanceRoster(o.samplePatch,roster,fetcher),priorBalance,fetcher);}
    catch{o.balancePending=true;}
  }
  return validateGameFeed({schema:1,region:'CN',mode:'normal',official:o}).official;
}
const feedURL='https://raw.githubusercontent.com/JINYUANY/hex-aram-cn/main/live-data.json';
let pendingFeed;
async function requestFeed(url,headers={}){
  const result=await fetch(url,{credentials:'omit',referrerPolicy:'no-referrer',cache:'no-store',headers,signal:AbortSignal.timeout(10000)});
  if(!result.ok)throw Error('公告同步源暂不可用');
  return validateGameFeed(await result.json());
}
export function readGameFeed(){
  if(!pendingFeed){
    const minute=Math.floor(Date.now()/60000);
    const backup='https://api.github.com/repos/JINYUANY/hex-aram-cn/contents/live-data.json?ref=main&t='+minute;
    pendingFeed=requestFeed(feedURL+'?t='+minute).catch(()=>requestFeed(backup,{Accept:'application/vnd.github.raw+json'}))
      .finally(()=>{pendingFeed=null;});
  }
  return pendingFeed;
}
