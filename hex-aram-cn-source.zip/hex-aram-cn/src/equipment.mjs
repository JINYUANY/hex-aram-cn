const dragonOrigin = 'https://ddragon.leagueoflegends.com';
const communityOrigin = 'https://raw.communitydragon.org';
// These Mayhem quest rewards directly identify the player's augment.
const rewardItems = new Set(['223069', '226668', '228002', '994403']);
const championItems = new Set(['3400', '3599', '3600']);
const guardianItems = new Set(['2051', '3112', '3177', '3184']);
const typeNames = {
  Health:'生命值', HealthRegen:'生命回复', Mana:'法力', ManaRegen:'法力回复',
  Damage:'攻击力', SpellDamage:'法术强度', CriticalStrike:'暴击', AttackSpeed:'攻击速度',
  Armor:'护甲', MagicResist:'魔法抗性', SpellBlock:'魔法抗性', MagicPenetration:'法术穿透',
  ArmorPenetration:'护甲穿透', AbilityHaste:'技能急速', CooldownReduction:'技能急速',
  NonbootsMovement:'移动速度', Tenacity:'韧性', Slow:'减速', OnHit:'攻击特效',
  Active:'主动效果', Aura:'光环', LifeSteal:'生命偷取', SpellVamp:'技能吸血',
  Consumable:'消耗品', Boots:'鞋子', Lane:'对线', Jungle:'打野', GoldPer:'金币', Vision:'视野'
};

/** Apply the same decision to a single item and every member of an ordered build. */
export function canShowItemWinRate(id, entry) {
  return !rewardItems.has(String(id)) && entry?.id === String(id) && entry.canShowWinRate === true;
}

function checkedCount(n, field) {
  if (!Number.isSafeInteger(n) || n < 0) throw new Error('装备统计中的' + field + '无效');
  return n;
}

function percentage(numerator, denominator) {
  return numerator != null && denominator > 0 ? Number((100 * numerator / denominator).toFixed(6)) : null;
}

function releaseWindow(manifest, tables, index, file) {
  const meta = tables.meta;
  const current = {patch: manifest.patch, cutoff: meta.window?.end_exclusive ?? meta.snapshot_at};
  const hash = manifest.files?.[file]?.sha256;
  if (!hash) return {patch: null, cutoff: null};
  const exact = (index.datasets ?? []).filter(batch => batch.mode === manifest.mode &&
    batch.files?.[file]?.sha256 === hash && batch.patch !== manifest.patch)
    .sort((a,b) => Date.parse(a.snapshot_at) - Date.parse(b.snapshot_at));
  if (exact.length) return {patch: exact[0].patch, cutoff: exact[0].window?.end_exclusive ?? exact[0].snapshot_at};
  return current;
}

function textOnly(value) {
  return String(value ?? '').replace(/<br\s*\/?\s*>/gi, '\n').replace(/<[^>]*>/g, '')
    .replace(/&nbsp;/gi, ' ').replace(/&amp;/gi, '&').replace(/[ \t]+/g, ' ')
    .replace(/ *\n */g, '\n').replace(/\n{3,}/g, '\n\n').trim();
}

function details(html, shortText) {
  const statSection = /<stats>([\s\S]*?)<\/stats>/i;
  const attributes = textOnly(html.match(statSection)?.[1]).split('\n').filter(Boolean);
  const body = html.replace(statSection, '').replace(/<flavorText>[\s\S]*?<\/flavorText>/gi, '');
  // Rendered game strings use zero for unresolved runtime calculations. Preserve actual
  // lower bounds (e.g. 0–30%), decimals and every independently specified number.
  const effects = textOnly(body).replace(/(?<![\d.])0(?![\d.]|\s*[-–—~至到]\s*\d)/g, '〔数值未提供〕')
    .replace(/@[^@\n]+@|\{\{[^}]+\}\}/g, '〔数值未提供〕');
  const short = textOnly(shortText);
  const description = [attributes.join(' · '), short || (!attributes.length && effects)].filter(Boolean).join('。');
  return {attributes, effects, description};
}

function describeItem(id, metadata, facts, gameFile, version, communityPatch, recommended, hasRecommendations, ids) {
  const category = metadata?.category ?? '';
  const tags = gameFile?.categories ?? facts?.tags ?? metadata?.types ?? [];
  const declaredReward = /augment|quest.reward|海克斯代理|强化奖励/i.test(category);
  const arenaOnly = facts?.maps?.['30'] === true && facts?.maps?.['12'] === false;
  const isReward = rewardItems.has(id) || declaredReward;
  const complete = category === 'complete_equipment';
  // An unfamiliar finished item absent from the interference-filtered table may be a reward.
  // The four automatically upgraded tear items have an explicit specialRecipe in Data Dragon.
  const transformFrom = String(gameFile?.specialRecipe || facts?.specialRecipe || '');
  const unclassifiedFinished = hasRecommendations && complete && !recommended && !transformFrom;
  let kind = 'other';
  if (isReward) kind = 'augmentReward';
  else if (championItems.has(id) || facts?.requiredChampion || gameFile?.requiredChampion || arenaOnly || unclassifiedFinished) kind = 'special';
  else if (complete) kind = 'complete';
  else if (tags.includes('Boots')) kind = 'boots';
  else if (guardianItems.has(id)) kind = 'starter';
  else if (tags.includes('Consumable')) kind = 'consumable';
  else if (metadata?.into?.length || facts?.into?.length || facts?.from?.length || gameFile?.to?.length || gameFile?.from?.length) kind = 'component';
  const image = facts?.image?.full;
  const gameAsset = gameFile?.iconPath?.match(/^\/lol-game-data\/assets\/(assets\/[a-z0-9_. /-]+)$/i)?.[1];
  const gameIcon = gameAsset && communityPatch ? communityOrigin + '/' + communityPatch +
    '/plugins/rcp-be-lol-game-data/global/default/' + gameAsset.toLowerCase() : '';
  const icon = version && /^\d+\.png$/.test(image ?? '') ?
    dragonOrigin + '/cdn/' + version + '/img/item/' + image : gameIcon || metadata?.icon || '';
  const from = (gameFile?.from ?? facts?.from ?? []).map(String).filter(i=>ids.has(i));
  if (!from.length && ids.has(transformFrom)) from.push(transformFrom);
  const into = [...new Set((gameFile?.to ?? facts?.into ?? metadata?.into ?? []).map(String).filter(i=>ids.has(i)))];
  const canShowWinRate = !isReward && !arenaOnly && !unclassifiedFinished && !!(recommended || facts || gameFile);
  return {
    id, name: gameFile?.name || facts?.name || metadata?.name || '装备 ' + id, icon, kind,
    ...details(gameFile?.description || facts?.description || '', facts?.plaintext),
    gold: gameFile?.priceTotal ?? facts?.gold?.total ?? metadata?.total ?? null,
    types: [...new Set(tags.map(tag=>typeNames[tag] || tag))], from, into,
    transformFrom: ids.has(transformFrom) ? transformFrom : null, canShowWinRate
  };
}

/** Full six-slot holdings. rows contain [string item ID, holder count, wins or null]. */
export function prepareEquipment(manifest, tables, index = {}, itemCatalog = {}) {
  const holdings = tables.hero_item_holdings;
  const denominators = tables.equipment_heroes;
  const available = !!holdings;
  const metadata = tables.item_metadata ?? {};
  const window = holdings ? releaseWindow(manifest, tables, index, 'hero_item_holdings.json') : {patch:null, cutoff:null};
  const denomWindow = denominators ? releaseWindow(manifest, tables, index, 'equipment_heroes.json') : null;
  const compatible = !!(window.cutoff && denomWindow?.cutoff && window.patch === denomWindow.patch &&
    Date.parse(window.cutoff) === Date.parse(denomWindow.cutoff));
  const recommendationTable = tables.hero_item_recommendations ?? tables.hero_items;
  const recommended = new Set(Object.values(recommendationTable ?? {}).flatMap(rows=>Object.keys(rows)));
  const ids = new Set([...Object.keys(metadata), ...recommended]);
  for (const rows of Object.values(holdings ?? {})) for (const id of Object.keys(rows)) ids.add(id);
  for (const rows of Object.values(tables.hero_items_raw ?? {})) for (const id of Object.keys(rows)) ids.add(id);
  const patchPrefix = manifest.patch + '.';
  const version = typeof itemCatalog?.version === 'string' && itemCatalog.version.startsWith(patchPrefix) &&
    /^\d+\.\d+\.\d+$/.test(itemCatalog.version) ? itemCatalog.version : null;
  const communityPatch = itemCatalog?.communityPatch === manifest.patch ? manifest.patch : null;
  const catalog = new Map();
  for (const id of ids) {
    if (!/^\d+$/.test(id)) throw new Error('装备 ID 无效');
    const facts = version ? itemCatalog.data?.[id] : null;
    const gameFile = communityPatch ? itemCatalog.communityItems?.[id] : null;
    const item = describeItem(id, metadata[id], facts, gameFile, version, communityPatch,
      recommended.has(id), !!recommendationTable, ids);
    catalog.set(id, {...item, games: null, wins: null, holdRate: null, winRate: null});
  }
  // Some game files list a component only on the finished item, including automatic transformations.
  for (const item of catalog.values()) {
    for (const id of item.from) {
      const resultIds = catalog.get(id).into;
      if (!resultIds.includes(item.id)) resultIds.push(item.id);
    }
  }
  const byHero = {};
  let denominator = compatible ? 0 : null;
  for (const heroId of new Set([...Object.keys(holdings ?? {}), ...Object.keys(denominators ?? {})])) {
    const itemRows = holdings?.[heroId];
    const heroDenom = compatible ? checkedCount(denominators?.[heroId]?.games, '英雄装备统计分母') : null;
    if (heroDenom > 0 && !itemRows) throw new Error('装备表缺少有统计分母的英雄');
    if (compatible) denominator += heroDenom;
    const rows = [];
    for (const [id, row] of Object.entries(itemRows ?? {})) {
      const games = checkedCount(row.games, '装备持有人次');
      const wins = checkedCount(row.wins, '装备持有胜场');
      if (wins > games || (heroDenom !== null && games > heroDenom)) throw new Error('装备持有人次或胜场超出样本');
      const item = catalog.get(id);
      item.games = (item.games ?? 0) + games;
      if (item.canShowWinRate) item.wins = (item.wins ?? 0) + wins;
      rows.push([id, games, item.canShowWinRate ? wins : null]);
    }
    rows.sort((a,b) => b[1] - a[1] || Number(a[0])-Number(b[0]));
    byHero[heroId] = {denominator:heroDenom, rows};
  }
  const equipmentMeta = tables.meta.equipment ?? {};
  const validMatches = compatible && denominator % 10 === 0 ? denominator / 10 : null;
  if (compatible && window.patch === manifest.patch && equipmentMeta.valid_matches != null &&
      equipmentMeta.valid_matches !== validMatches) throw new Error('装备样本场次与英雄分母不一致');
  for (const row of catalog.values()) {
    row.holdRate = percentage(row.games, denominator);
    row.winRate = percentage(row.wins, row.games);
  }
  return {
    ...window, available, denominator, matches: validMatches, minimumDuration: equipmentMeta.minimum_duration_s ?? null,
    lowSampleThreshold: tables.meta.low_sample_threshold ?? null, catalogVersion: version, communityPatch,
    catalog: [...catalog.values()].sort((a,b) => (b.games ?? -1) - (a.games ?? -1) || Number(a.id) - Number(b.id)),
    byHero
  };
}

async function fetchDragonItems(patch,fetcher) {
  let version=patch+'.1';
  try {
    const versions=await fetcher(dragonOrigin+'/api/versions.json',{cache:'no-cache',signal:AbortSignal.timeout(6000)});
    if(versions.ok){
      const known=await versions.json();
      if(Array.isArray(known)){
        const builds=known.filter(v=>typeof v==='string' && v.startsWith(patch+'.') && /^\d+\.\d+\.\d+$/.test(v));
        version=builds.sort((a,b)=>Number(b.split('.')[2])-Number(a.split('.')[2]))[0] ?? version;
      }
    }
  }catch{/* The initial build can be available before the version index updates. */}
  try{
    const response=await fetcher(dragonOrigin+'/cdn/'+version+'/data/zh_CN/item.json',{cache:'no-cache',signal:AbortSignal.timeout(12000)});
    if(response.ok){
      const catalog=await response.json();
      if(catalog.version===version && catalog.data && Object.keys(catalog.data).length)return {...catalog,dragonVersion:version};
    }
  }catch{/* Keep the selected version for the independent hero catalog. */}
  return {dragonVersion:version};
}

/** Optional static catalogs, pinned to the same major.minor patch as the source. */
export async function fetchEquipmentCatalog(patch,fetcher=fetch) {
  if(!/^\d+\.\d+$/.test(patch))return {};
  const gameFiles=async()=>{
    try{
      const response=await fetcher(communityOrigin+'/'+patch+
        '/plugins/rcp-be-lol-game-data/global/zh_cn/v1/items.json',{cache:'no-cache',signal:AbortSignal.timeout(15000)});
      if(!response.ok)return {};
      const data=await response.json();
      if(!Array.isArray(data))return {};
      const available=data.filter(item=>Number.isSafeInteger(item?.id) && typeof item.name==='string' && item.name.trim());
      return available.length?{communityPatch:patch,communityItems:Object.fromEntries(available.map(item=>[String(item.id),item]))}:{};
    }catch{return {};}
  };
  const [official,community]=await Promise.all([fetchDragonItems(patch,fetcher),gameFiles()]);
  return {...official,...community};
}
