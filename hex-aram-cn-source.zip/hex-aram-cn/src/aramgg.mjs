// Only the documented third-party API is used. Protected resources are projected
// here so augment wins and win rates never enter the client or persistent cache.
const base = 'https://data.dtodo.cn/api/v1/zh-CN/';
const patchPattern = /^\d{1,2}\.\d{1,2}$/;
const heroPattern = /^[1-9]\d{0,5}$/;
const pending = new Map();
const recent = new Map();

async function get(resource, key) {
  const response = await fetch(base + resource, {
    redirect:'manual', signal:AbortSignal.timeout(20000),
    headers:key ? {Accept:'application/json',Authorization:'Bearer ' + key} : {Accept:'application/json'}
  });
  if (!response.ok) throw Object.assign(new Error('ARAMGG request failed'), {http:response.status});
  return response.json();
}
function failure(error) {
  if (error.http === 401 || error.http === 403) return 'credentials';
  return error.http === 429 ? 'quota' : 'unavailable';
}
function metadata(raw) {
  if (raw?.service !== 'aramgg-data-api' || raw.locale !== 'zh-CN' ||
      raw.schemaVersion !== 1 || !patchPattern.test(raw.gamePatch) ||
      !Number.isSafeInteger(raw.apiRelease) || raw.apiRelease < 0 ||
      raw.dataVersion !== raw.gamePatch + '.' + raw.apiRelease) throw new Error('Unknown ARAMGG release');
  return {patch:raw.gamePatch,release:raw.apiRelease,version:raw.dataVersion,publishedAt:isoTime(raw.publishedAt)};
}
function isoTime(s) {
  return typeof s === 'string' && /^\d{4}-\d{2}-\d{2}T.*(?:Z|[+-]\d{2}:\d{2})$/i.test(s) && Number.isFinite(Date.parse(s)) ? s : null;
}
function statDate(s) {
  if (typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && Number.isFinite(Date.parse(s)) &&
      new Date(s).toISOString().slice(0,10) === s) return s;
  return isoTime(s);
}
function ratio(value) {
  return Number.isFinite(value) && value >= 0 && value <= 1 ? Number((value * 100).toFixed(6)) : null;
}
function sampleCount(n) {
  return Number.isSafeInteger(n) && n >= 0 ? n : null;
}
function parseCatalog(payload, config) {
  if (metadata(payload.meta).version !== config.version || !Array.isArray(payload.data))
    throw new Error('Mismatched ARAMGG snapshot');
  const heroes = [], ids = new Set();
  for (const h of payload.data) {
    const s=h?.stats;
    if (s?.region !== 'CN' || s.source !== 'tencent' || s.gamePatch !== config.patch) continue;
    const winRate=ratio(s.winRate), pickRate=ratio(s.pickRate), id=String(h.id);
    if (winRate == null || !heroPattern.test(id) || !h.name || typeof h.name !== 'string') continue;
    if (ids.has(id)) throw new Error('Duplicate champion');
    ids.add(id);
    heroes.push({id,name:h.name,title:h.title || '',alias:h.alias || '',winRate,pickRate,
      games:sampleCount(s.games),date:statDate(s.date)});
  }
  if (!heroes.length) throw new Error('No verified CN hero samples');
  const dates = [...new Set(heroes.map(h=>h.date))];
  return {patch:config.patch,version:config.version,date:dates.length===1 ? dates[0] : null,heroes};
}
function compareRelease(a,b) {
  const va=a.version.split('.').map(Number), vb=b.version.split('.').map(Number);
  return va[0]-vb[0] || va[1]-vb[1] || va[2]-vb[2];
}
export async function fetchAramgg(previous,key) {
  const config=metadata(await get('config.json'));
  if (previous.config && compareRelease(config,previous.config)<0) throw new Error('Stale ARAMGG config');
  let catalog=previous.catalog, status='needs-key';
  if(key) {
    try {
      if (catalog?.version !== config.version) catalog=parseCatalog(await get('champions.json',key),config);
      status='ready';
    } catch (error) {status=failure(error);}
  }
  return {config,catalog,status};
}
function trioSnapshot(payload,config,id) {
  if (metadata(payload.meta).version !== config.version || String(payload.data?.champion?.id)!==id ||
      !Array.isArray(payload.data.augmentTrios)) throw new Error('Unknown trio snapshot');
  const rows=[], seen=new Set();
  const augmentNames=new Map((payload.data.augments || []).map(a=>[String(a.id),a.name]));
  let unverified=0;
  for (const t of payload.data.augmentTrios) {
    const s=t?.stats;
    const region=['CN','WORLD'].includes(s?.region) ? s.region : null, games=sampleCount(s?.games);
    const patch=patchPattern.test(s?.gamePatch) ? s.gamePatch : null;
    const ids=(t?.augmentIds || t?.augments?.map(a=>a.id) || []).map(String);
    if (s?.source !== 'aramgg-client-upload' || !games || ids.length!==3 ||
        ids.some(n=>!/^\d+$/.test(n)) || new Set(ids).size!==3) {
      unverified++; continue;
    }
    const names=ids.map(id=>t.augments?.find(a=>String(a.id)===id)?.name || augmentNames.get(id) || '强化 '+id);
    const tag=[patch,region,...ids.slice().sort()].join('/');
    if(seen.has(tag)) continue;
    seen.add(tag);
    rows.push({augmentIds:ids,names,games,region,patch,date:statDate(s.date)});
  }
  rows.sort((a,b)=>b.games-a.games);
  return {status:'ready',version:config.version,patch:config.patch,rows,unverified};
}
export async function getTrios(summary,env,id) {
  if(!env.ARAMGG_API_KEY) return {status:'needs-key',rows:[]};
  const config=summary.config;
  if (!config) return {status:'unavailable',rows:[]};
  if (summary.status === 'credentials' || summary.status === 'quota') return {status:summary.status,rows:[]};
  const path='gg-trios/v2-'+config.version+'-'+id;
  const cached=recent.get(path);
  if (cached && Date.now()<cached.until) return cached.value;
  if (pending.has(path)) return pending.get(path);
  const work=(async()=>{
    let value;
    try {
      const saved=await env.BUCKET?.get(path);
      if(saved) value=await saved.json();
      else {
        value=trioSnapshot(await get('champions/'+id+'.json',env.ARAMGG_API_KEY),config,id);
        if(env.BUCKET) await env.BUCKET.put(path,JSON.stringify(value),{onlyIf:{etagDoesNotMatch:'*'}});
      }
    } catch(error) {value={status:failure(error),version:config.version,rows:[]};}
    if(recent.size>=350) recent.delete(recent.keys().next().value);
    recent.set(path,{value,until:Date.now()+(value.status==='ready'?3600000:300000)});
    return value;
  })().finally(()=>pending.delete(path));
  pending.set(path,work);
  return work;
}
