// Each owner-managed object describes one reviewed sample; browsers can only read it.
const positiveId=value=>typeof value==='string' && /^[1-9]\d{0,7}$/.test(value);
const positiveCount=value=>Number.isSafeInteger(value) && value>0;

export function verifiedPairs(raw,patch,heroId,items=new Map()) {
  const setData=raw?.schema===2 && raw.measure==='same-player-final-augment-set';
  if((!setData && !(raw?.schema===1 && raw.measure==='same-player-final-augment-pair')) || raw.region!=='CN' || raw.mode!=='normal' || raw.patch!==patch ||
      raw.heroId!==heroId ||
      !Array.isArray(raw.rows) || !raw.rows.length || !raw.source?.name?.trim() ||
      !['complete','partial'].includes(raw.coverage))throw Error('Invalid pair sample');
  const sourceUrl=new URL(raw.source.url);
  if(sourceUrl.protocol!=='https:' || sourceUrl.username || sourceUrl.password)throw Error('Invalid source URL');
  if(typeof raw.cutoff!=='string' || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2}(\.\d{1,3})?)?(Z|[+-]\d{2}:\d{2})$/.test(raw.cutoff) ||
      !Number.isFinite(Date.parse(raw.cutoff)) || Date.parse(raw.cutoff)>Date.now())throw Error('Missing sample cutoff');
  if(raw.heroGames!=null && !positiveCount(raw.heroGames))throw Error('Invalid hero denominator');
  const seen=new Set(),rows=[];
  for(const row of raw.rows){
    const ids=row?.augmentIds;
    if(!Array.isArray(ids) || ids.length<2 || ids.length>(setData?6:2) || !ids.every(positiveId) || new Set(ids).size!==ids.length ||
        !positiveCount(row.games) || (raw.heroGames!=null && row.games>raw.heroGames))throw Error('Invalid exact pair');
    const pair=ids.slice().sort((a,b)=>Number(a)-Number(b)), key=pair.join('/');
    if(seen.has(key))throw Error('Duplicate pair in one cohort');
    const projected={augmentIds:pair,games:row.games};
    if(setData && Array.isArray(row.finalItems)){
      const used=new Set();
      projected.items=row.finalItems.filter(i=>items.get(i.id)?.kind==='complete' && items.get(i.id)?.canShowWinRate===true).map(i=>{
        if(used.has(i.id) || !positiveCount(i.games) || i.games>row.games || !Number.isSafeInteger(i.wins) || i.wins<0 || i.wins>i.games)throw Error('Invalid set equipment');
        used.add(i.id);
        return {id:i.id,games:i.games,winRate:100*i.wins/i.games};
      }).sort((a,b)=>b.games-a.games);
    }
    seen.add(key);rows.push(projected);
  }
  rows.sort((a,b)=>b.games-a.games || Number(a.augmentIds[0])-Number(b.augmentIds[0]) || Number(a.augmentIds[1])-Number(b.augmentIds[1]));
  return {status:'ready',patch,heroId,region:'CN',coverage:raw.coverage,heroGames:raw.heroGames ?? null,
    source:{name:raw.source.name.trim(),url:sourceUrl.href},cutoff:raw.cutoff,rows};
}
export async function readVerifiedPairs(bucket,patch,heroId,getCatalog) {
  const empty={patch,heroId,region:'CN',cutoff:null,rows:[]};
  if(!bucket)return {...empty,status:'unavailable'};
  try{
    const obj=await bucket.get('augment-pairs/cn-normal-'+patch+'-hero-'+heroId);
    if(!obj)return {...empty,status:'unpublished'};
    const raw=await obj.json();
    const equipment=raw?.schema===2 && getCatalog?await getCatalog():null;
    const items=new Map((equipment?.patch===patch?equipment.catalog:[]).map(item=>[item.id,item]));
    return verifiedPairs(raw,patch,heroId,items);
  }catch{return {...empty,status:'unavailable'};}
}
