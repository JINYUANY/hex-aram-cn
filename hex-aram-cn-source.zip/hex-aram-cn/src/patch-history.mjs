import {poolExclusions} from './mayhem-notes.mjs';

// Only record statements that tie a named ability to an augment. A bug interaction
// is evidence about that spell on the date of the notice, not a whole-hero offer rule.
function skillNotices(entries){
  const rows=[];
  for(const entry of entries || []){
    if(entry.category!=='BUG修复' || !['fix','other'].includes(entry.kind))continue;
    for(const line of entry.details){
      const body=line.split('该BUG曾导致：')[1]?.replace(/^在【海克斯大乱斗】中，/,'');
      if(!body || body.includes('被供应给'))continue;
      let m=body.match(/^([\p{Script=Han}·]+)的【([^】]+)】无法与【([^】]+)】配合生效。$/u);
      if(m){rows.push({hero:m[1],skill:m[2],augment:m[3],line});continue;}
      m=body.match(/^([\p{Script=Han}·]+)在使用【([^】]+)】时，处于([^，]+形态)下仍可施放【([^】]+)】。$/u);
      if(m){rows.push({hero:m[1],augment:m[2],skill:m[3]+' · '+m[4],line});continue;}
      const names=[...body.matchAll(/【([^】]+)】/g)].map(x=>x[1]).filter(n=>n!=='海克斯大乱斗');
      if(names.length!==1 || !/(?:触发|施加|返还|没有正确提供|冷却|分裂|处决效果|刷新持续时长)/.test(body))continue;
      // Start at the subject (or a clause/list boundary); discard unattested qualifiers.
      const conditional=body.match(/^如果([\p{Script=Han}·]+)拥有【[^】]+】，那么她的([QWER])/u);
      if(conditional){rows.push({hero:conditional[1],augment:names[0],skill:conditional[2],line});continue;}
      const subject=body.replace(/^(?:拥有|在拥有)【[^】]+】(?:时，|的)/,'')
        .replace(/^【[^】]+】(?:不会正确返还|不会施加至|没有正确提供移动速度至)/,'')
        .replace(/^【[^】]+】不会将它的伤害施加至某些强化普攻技能，包括/,'').replace(/，以及/g,'，');
      for(const ref of subject.matchAll(/(?:^|[，、]|以及|和)([\p{Script=Han}·]{1,12}?)的[（(]?([QWER])[)）]?/gu)){
        rows.push({hero:ref[1],augment:names[0],skill:ref[2],line});
      }
    }
  }
  return rows;
}

// Keep the published time of each Tencent article separate from the client's last sync.
export function mergePatchHistory(...sources){
  const docs=new Map();
  function add(row){
    if(!row || !/^\d{2}\.\d{1,2}$/.test(row.patch) || typeof row.title!=='string' ||
       !/^https:\/\/lol\.qq\.com\//.test(row.url) || !Number.isFinite(Date.parse(row.publishedAt)))return;
    const existing=docs.get(row.url);
    const valid=Array.isArray(row.entries) && row.entries.every(e=>e && typeof e.name==='string' &&
      typeof e.category==='string' && Array.isArray(e.details) && e.details.every(line=>typeof line==='string'));
    const entries=valid?row.entries:existing?.entries ?? null;
    const changes=Array.isArray(row.offerChanges) && row.offerChanges.length && row.offerChanges.every(r=>
      r && typeof r.hero==='string' && typeof r.augment==='string' && typeof r.skill==='string' && ['added','removed'].includes(r.state))
      ?row.offerChanges:existing?.offerChanges;
    const rows=new Map();
    for(const change of [...(changes || []),...poolExclusions(entries || [])]){
      rows.set(JSON.stringify([change.hero,change.augment,change.skill,change.state]),change);
    }
    const interactions=skillNotices(entries);
    docs.set(row.url,{patch:row.patch,title:row.title,url:row.url,publishedAt:row.publishedAt,entries,...(interactions.length?{skillInteractions:interactions}:{}),...(rows.size?{offerChanges:[...rows.values()]}:{}),...(row.hotfix?{hotfix:true}:{})});
  }
  for(const source of sources){
    if(!source)continue;
    if(Array.isArray(source.history))source.history.forEach(add);
    const notes=source.mayhem;
    const same=notes && notes.patch===source.patch && notes?.url===source.url;
    add({...source,offerChanges:same?notes.offerChanges:undefined,entries:same?notes.entries:null});
    for(const h of source.hotfixes || []){
      const detail=same?notes.hotfixDetails?.find(d=>d.url===h.url):null;
      add({...h,patch:source.patch,hotfix:true,offerChanges:detail?.offerChanges,entries:detail?.entries});
    }
  }
  return [...docs.values()].sort((a,b)=>Date.parse(b.publishedAt)-Date.parse(a.publishedAt) || a.url.localeCompare(b.url));
}
