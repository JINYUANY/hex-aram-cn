// The two Wiki tables have distinct units and scopes. Only explicit fields are imported.
// The numerical extracts from LoL Wiki are attributed to their permanent page revisions (CC BY-SA 3.0).
const balanceWikiAPI = 'https://wiki.leagueoflegends.com/en-us/api.php';
const balanceWikiClassic = 'Module:ChampionData/data';
const balanceWikiMayhem = 'ARAM: Mayhem';
const balanceMetrics = {
  dmg_dealt: ['造成伤害', '%', 100, 'higher'],
  dmg_taken: ['承受伤害', '%', 100, 'lower'],
  shielding: ['护盾效果', '%', 100, 'higher'],
  healing: ['治疗效果', '%', 100, 'higher'],
  energyregen_mod: ['能量回复', '%', 100, 'higher'],
  ability_haste: ['技能急速', '点', 0, 'higher'],
  tenacity: ['额外韧性', '%', 0, 'higher'],
  total_as: ['总攻击速度加成', '%', 0, 'higher']
};
const balanceWikiLabels = {
  'damage dealt': 'dmg_dealt', 'damage received': 'dmg_taken', 'healing done': 'healing',
  'shielding done': 'shielding', 'ability haste': 'ability_haste', 'tenacity': 'tenacity',
  'total attack speed': 'total_as', 'total attack speed increase': 'total_as'
};
const balanceTencentLabels = {
  '造成伤害':'dmg_dealt', '承受伤害':'dmg_taken', '治疗效果':'healing', '护盾修正':'shielding',
  '护盾效果':'shielding', '韧性':'tenacity', '技能急速':'ability_haste', '总攻击速度提升':'total_as'
};
const balancePatchSyntax = /^\d{1,2}\.\d{1,2}$/;
const balanceKey = name => String(name || '').toLowerCase().replace(/[^a-z0-9]/g,'');
const balancePageRevision = (id) => 'https://wiki.leagueoflegends.com/en-us/Special:PermanentLink/' + id;
const balanceSourceWiki = (rev,patch) => ({name:'英雄联盟 Wiki · 社区资料', url:balancePageRevision(rev.revid), patch, publishedAt:rev.timestamp});
const balanceIsWiki = s => /^https:\/\/wiki\.leagueoflegends\.com\/en-us\/Special:PermanentLink\/[1-9]\d*$/.test(s?.url || '');
const balanceRevisionNumber = s => Number(s?.url?.split('/').pop()) || 0;
function balanceMetric(key,value) {
  const [label,unit,baseline,favorable]=balanceMetrics[key];
  return {key,label,value:Math.round(value*1000)/1000,unit,baseline,favorable};
}
function balanceValidSource(source,patch) {
  if (!source || source.patch!==patch || typeof source.name!=='string' || !source.name.trim() ||
      !Number.isFinite(Date.parse(source.publishedAt))) return false;
  if (balanceIsWiki(source)) return true;
  try { const u=new URL(source.url); return u.origin==='https://lol.qq.com' && !u.username && !u.password; }
  catch { return false; }
}
function balanceClientPatch(patch) {
  const [major,n]=patch.split('.'),season=Number(major);
  return (season>=25 ? season-10 : season)+'.'+n;
}
export function validateChampionBalance(raw,expectedClientPatch) {
  const invalid=()=>{throw Error('英雄模式平衡资料的版本、来源或指标无效');};
  if (raw?.schema!==1 || raw.region!=='CN' || !balancePatchSyntax.test(raw.officialPatch) ||
      raw.patch!==balanceClientPatch(raw.officialPatch) || (expectedClientPatch!=null && raw.patch!==expectedClientPatch)) invalid();
  for (const modeName of ['aram','mayhem']) {
    const mode=raw.modes?.[modeName];
    if (!mode || !['ready','cached','pending'].includes(mode.status) ||
        !(mode.source===null ? mode.status==='pending' : mode.status!=='pending' && balanceIsWiki(mode.source) && balanceValidSource(mode.source,raw.officialPatch)) ||
        typeof mode.byHero!=='object' || !mode.byHero || Array.isArray(mode.byHero) || Object.keys(mode.byHero).length>400) invalid();
    for (const [id,row] of Object.entries(mode.byHero)) {
      if (!/^[1-9]\d{0,5}$/.test(id) || !balanceValidSource(row?.source,raw.officialPatch) || !Array.isArray(row.metrics) ||
          !row.metrics.length || row.metrics.length>Object.keys(balanceMetrics).length || new Set(row.metrics.map(m=>m?.key)).size!==row.metrics.length) invalid();
      for (const m of row.metrics) {
        const def=Object.hasOwn(balanceMetrics,m?.key) && balanceMetrics[m.key];
        if (!def || m.label!==def[0] || m.unit!==def[1] || m.baseline!==def[2] || m.favorable!==def[3] ||
            !Number.isFinite(m.value) || m.value < (m.baseline===100 ? 0 : -100) || m.value>500 ||
            (m.source!==undefined && !balanceValidSource(m.source,raw.officialPatch)) ||
            (balanceIsWiki(m.source || row.source) && (m.source || row.source).url!==mode.source?.url)) invalid();
      }
    }
  }
  return raw;
}
async function balanceWikiQuery(params,fetcher) {
  const query=new URLSearchParams({action:'query',format:'json',formatversion:'2',prop:'revisions',...params});
  const response=await fetcher(balanceWikiAPI+'?'+query,{signal:AbortSignal.timeout(8000),headers:{'Api-User-Agent':'hex-aram-cn (https://github.com/JINYUANY/hex-aram-cn)'}});
  if(!response.ok)throw Error('英雄联盟 Wiki 请求失败');
  const pages=(await response.json())?.query?.pages;
  if(!Array.isArray(pages) || pages.length!==1 || !Array.isArray(pages[0]?.revisions))throw Error('Wiki 修订版本不可用');
  return pages[0];
}
function balanceWikiContent(page,title) {
  const rev=page.revisions[0];
  if(page.title!==title || !Number.isSafeInteger(rev?.revid) || rev.revid<=0 || !Number.isFinite(Date.parse(rev.timestamp)) ||
     typeof rev.slots?.main?.content!=='string')throw Error('Wiki 修订内容无效');
  return rev;
}
function balanceMarkedPatches(s) {
  return [...s.matchAll(/\bV(\d{1,2})\.(\d{1,2})\b/g)].map(m=>Number(m[1])*100+Number(m[2]));
}
const balancePatchNumber = s => {const [a,b]=s.split('.').map(Number);return a*100+b;};
function balanceClassicData(rev,patch,ids) {
  const content=rev.slots.main.content.replace(/--\[\[[\s\S]*?\]\]|--[^\n]*/g,'');
  const updates=[...content.matchAll(/\["changes"\]\s*=\s*"(V\d{1,2}\.\d{1,2})"/g)].flatMap(m=>balanceMarkedPatches(m[1]));
  if (!updates.length || Math.max(...updates)!==balancePatchNumber(patch))throw Error('常规大乱斗资料尚未匹配本版');
  const source=balanceSourceWiki(rev,patch), byHero={}, names=new Map();
  const headers=[...content.matchAll(/^[ \t]*\["([^"\n]+)"\]\s*=\s*\{\s*\["id"\]\s*=\s*(\d+)\s*,/gm)];
  for(const [index,hero] of headers.entries()) {
    const id=hero[2];
    if(!ids.has(id))continue;
    names.set(balanceKey(hero[1]),id);
    // Lua resolves repeated table keys to the last definition. Non-primary forms can share an ID.
    if(byHero[id])continue;
    const block=content.slice(hero.index,headers[index+1]?.index);
    const fields=[...block.matchAll(/^[ \t]*\["aram"\]\s*=\s*\{([^}]*)\}/gm)].at(-1)?.[1] || '';
    const metrics=[];
    for(const [,key,val] of fields.matchAll(/\["(\w+)"\]\s*=\s*(-?\d+(?:\.\d+)?)\s*(?=,|$)/g)) {
      if (!Object.hasOwn(balanceMetrics,key))continue;
      const value=Number(val);
      const display=key==='ability_haste' ? value : (key==='tenacity' || key==='total_as') ? (value-1)*100 : value*100;
      metrics.push(balanceMetric(key,display));
    }
    if(metrics.length)byHero[id]={source,metrics};
  }
  if(!Object.keys(byHero).length)throw Error('未读取到常规大乱斗的具名数值');
  return {mode:{status:'ready',source,byHero},names};
}
function balanceMayhemData(rev,patch,names) {
  const content=rev.slots.main.content;
  const table=content.match(/^===\s*List of mode overrides\s*===\s*$[\s\S]*?^Champions\s*=\s*$[\s\S]*?^\{\|[^\n]*\n([\s\S]*?)^\|\}/mi)?.[1];
  if(!table)throw Error('海克斯模式强化表暂不可用');
  const source=balanceSourceWiki(rev,patch), byHero={};
  for(const line of table.split(/^\|-\s*$/m)) {
    const hero=line.match(/^\|\s*\{\{ci\|([^}|\n]+)\}\}/im)?.[1], id=names.get(balanceKey(hero));
    const general=line.match(/^\|[ \t]*Special modifiers[ \t]*\n([\s\S]*?)(?=^\||$(?![\s\S]))/im)?.[1];
    if(!id || !general)continue;
    const metrics=[];
    for(const match of general.replace(/\{\{fd\|(-?\d+(?:\.\d+)?)\}\}/g,'$1').matchAll(/^\*[ \t]+([A-Za-z ]+) changed to ([+−-]?\d+(?:\.\d+)?)(%?) from [^\n]+/gim)) {
      const key=balanceWikiLabels[match[1].toLowerCase()];
      if(!key || (match[3]==='%')!==(balanceMetrics[key][1]==='%'))continue;
      metrics.push(balanceMetric(key,balanceMetrics[key][2]+Number(match[2].replace('−','-'))));
    }
    if(metrics.length)byHero[id]={source,metrics};
  }
  if(!Object.keys(byHero).length)throw Error('未读取到海克斯模式的具名数值');
  return {status:'ready',source,byHero};
}
async function balanceMayhemRevision(patch,fetcher) {
  const history=await balanceWikiQuery({titles:balanceWikiMayhem,rvlimit:'100',rvprop:'ids|timestamp|comment'},fetcher);
  const target=balancePatchNumber(patch);
  const rev=history.revisions.find(r=>{
    // A mention of an older patch in prose (such as a revert) cannot date the table.
    const tag=r.comment?.match(/^(?:\/\*[^*]*\*\/\s*)?(?:\[\[)?(V\d{1,2}\.\d{1,2})\b/);
    return tag && balanceMarkedPatches(tag[1])[0]===target;
  });
  if(history.title!==balanceWikiMayhem || !Number.isSafeInteger(rev?.revid))throw Error('尚无本版明确标记的海克斯 Wiki 修订');
  const doc=await balanceWikiQuery({revids:String(rev.revid),rvslots:'main',rvprop:'ids|timestamp|content'},fetcher);
  const pinned=balanceWikiContent(doc,balanceWikiMayhem);
  if(pinned.revid!==rev.revid)throw Error('海克斯 Wiki 修订不符');
  return pinned;
}
function balanceCachedMode(previous) {
  if(!previous?.source)return {status:'pending',source:null,byHero:{}};
  const byHero={};
  for(const [id,row] of Object.entries(previous.byHero)){
    const metrics=row.metrics.filter(m=>balanceIsWiki(m.source || row.source));
    if(metrics.length)byHero[id]={source:previous.source,metrics};
  }
  return {status:'cached',source:previous.source,byHero};
}
function balanceApplyNotices(modes,official,byName) {
  const notes=official.mayhem;
  const direct=notes?.patch===official.patch && notes.samplePatch===official.samplePatch && notes.url===official.url && Array.isArray(notes.balanceEntries)
    ? [{...notes,entries:notes.balanceEntries},...(notes.balanceHotfixes || []).filter(h=>
        official.hotfixes?.some(link=>link.url===h.url && link.publishedAt===h.publishedAt))
        .map(h=>({...h,patch:notes.patch,samplePatch:notes.samplePatch}))] : [];
  const docs=official.balanceNotices?.documents || direct;
  for(const doc of [...docs].filter(d=>d.patch===official.patch && d.samplePatch===official.samplePatch)
      .sort((a,b)=>Date.parse(a.publishedAt)-Date.parse(b.publishedAt))) {
    const source={name:'腾讯英雄联盟国服公告',url:doc.url,publishedAt:doc.publishedAt,patch:doc.patch};
    if(!balanceValidSource(source,official.patch) || balanceIsWiki(source))continue;
    for(const entry of doc.entries){
      const id=byName.get(entry.name), mode=Object.hasOwn(modes,entry.mode) && modes[entry.mode];
      if(!id || !mode)continue;
      for(const detail of entry.details){
        const match=detail.trim().replace(/^(?:(?:&bull;|[●•·])\s*)+/,'').match(/^([^：:]+)[：:]\s*([+−-]?\d+(?:\.\d+)?)\s*(%?)\s*(?:⇒|→|->)\s*([+−-]?\d+(?:\.\d+)?)\s*(%?)\s*[。.]?$/);
        const key=match && Object.hasOwn(balanceTencentLabels,match[1].trim()) && balanceTencentLabels[match[1].trim()];
        if(!key || (key!=='tenacity' && (match[5]==='%')!==(balanceMetrics[key][1]==='%')) || match[3]!==match[5])continue;
        const metric=balanceMetric(key,Number(match[4].replace('−','-')));
        const row=mode.byHero[id] ||= {source,metrics:[]};
        if(row.source.url!==source.url)metric.source=source;
        row.metrics=row.metrics.filter(m=>m.key!==key);
        row.metrics.push(metric);
      }
    }
  }
}
/** A pending Wiki revision leaves verified CN announcement values available. Sources refresh independently. */
export async function fetchChampionBalance(official,roster,previous=null,fetcher=fetch) {
  if(!balancePatchSyntax.test(official?.patch) || balanceClientPatch(official.patch)!==official.samplePatch)throw Error('国服版本无效');
  const heroes=Array.isArray(roster)?roster:Object.values(roster?.byId || roster || {});
  const ids=new Set(heroes.map(h=>String(h.id)));
  const byName=new Map(heroes.flatMap(h=>[h.name,h.title].filter(Boolean).map(n=>[n,String(h.id)])));
  const names=new Map(heroes.flatMap(h=>[h.alias,h.key].filter(Boolean).map(n=>[balanceKey(n),String(h.id)])));
  const prior=previous?.patch===official.samplePatch ? validateChampionBalance(previous,official.samplePatch) : null;
  const classic=balanceWikiQuery({titles:balanceWikiClassic,rvslots:'main',rvprop:'ids|timestamp|content'},fetcher)
    .then(p=>balanceClassicData(balanceWikiContent(p,balanceWikiClassic),official.patch,ids));
  const [a,m]=await Promise.allSettled([classic,balanceMayhemRevision(official.patch,fetcher)]);
  const modes={aram:balanceCachedMode(prior?.modes.aram),mayhem:balanceCachedMode(prior?.modes.mayhem)};
  if(a.status==='fulfilled'){
    for(const [name,id] of a.value.names)names.set(name,id);
    if(balanceRevisionNumber(a.value.mode.source)>=balanceRevisionNumber(modes.aram.source))modes.aram=a.value.mode;
  }
  if(m.status==='fulfilled' && m.value.revid>=balanceRevisionNumber(modes.mayhem.source)){
    try{modes.mayhem=balanceMayhemData(m.value,official.patch,names);}catch{/* Retain same-version evidence when the public table format changes. */}
  }
  balanceApplyNotices(modes,official,byName);
  return validateChampionBalance({schema:1,region:'CN',patch:official.samplePatch,officialPatch:official.patch,modes},official.samplePatch);
}
