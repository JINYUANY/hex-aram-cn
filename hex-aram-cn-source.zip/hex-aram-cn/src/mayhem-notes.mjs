// Tencent publishes a GBK article per patch. Read only the dedicated mode section.
const entities = {
  nbsp: ' ', ensp: ' ', emsp: ' ', quot: '"', amp: '&', apos: "'", lt: '<', gt: '>',
  rArr: '⇒', rarr: '→', uarr: '↑', darr: '↓', ndash: '–', mdash: '—', hellip: '…',
  ldquo: '“', rdquo: '”', lsquo: '‘', rsquo: '’', times: '×', middot: '·', bull: '•',
};

function plain(html) {
  return html.replace(/<[^>]+>/g, '').replace(/&(#x[\da-fA-F]+|#\d+|\w+);/g, (raw, key) => {
    if (key[0] !== '#') return entities[key] ?? raw;
    const code = key[1] === 'x' ? parseInt(key.slice(2), 16) : Number(key.slice(1));
    return code > 0 && code <= 0x10ffff ? String.fromCodePoint(code) : '';
  }).replace(/\s+/g, ' ').trim();
}

function tencentArticle(value) {
  const url = new URL(value);
  if (url.origin !== 'https://lol.qq.com' || url.username || url.password) throw new Error('无效的腾讯版本公告网址');
  return url;
}

function checkSource(official) {
  tencentArticle(official.url);
  if (!/^\d{2}\.\d{1,2}$/.test(official.patch) || !/^\d{2}\.\d{1,2}$/.test(official.samplePatch) ||
      !Number.isFinite(Date.parse(official.publishedAt))) throw new Error('缺少有效的腾讯版本公告信息');
}

function headingKind(label) {
  if (/BUG修复|问题修复|错误修复|修复项/i.test(label)) return 'fix';
  if (/削弱|减弱/.test(label)) return 'nerf';
  if (/增强|加强/.test(label)) return 'buff';
  if (/新增|新加入|全新/.test(label)) return 'new';
  return null;
}

// Classify only directly comparable numbers with an unambiguous direction.
// Breakpoints, changed units, mixed effects and narrative changes remain adjustments.
function numericKind(detail) {
  const match = detail.match(/^([^：:]+)[：:]\s*([^⇒→]+?)\s*(?:⇒|→)\s*(.+)$/);
  if (!match) return null;
  const [, metric, before, after] = match;
  const lowerBetter = /^(?:承受伤害|受到伤害|冷却时间|充能时间|法力消耗)$/;
  const higherBetter = /^(?:造成伤害|(?:基础|额外)?伤害|韧性|护盾修正|总攻击速度提升|额外经验|(?:基础|额外)?(?:攻击力|法术强度|生命值|护甲|魔法抗性|技能急速)|治疗(?:效果)?修正)$/;
  if (!lowerBetter.test(metric) && !higherBetter.test(metric)) return null;
  const number = /\d+(?:\.\d+)?/g;
  const shape = s => s.replace(number, '#').replace(/\s+/g, '');
  if (shape(before) !== shape(after) || /(?:^|[+，,(])\s*[-−]\s*\d/.test(before + ',' + after)) return null;
  const oldNumbers = before.match(number) || [], newNumbers = after.match(number) || [];
  const directions = new Set(oldNumbers.map((value, i) => Math.sign(Number(newNumbers[i]) - Number(value))).filter(Boolean));
  if (directions.size !== 1) return null;
  const rises = directions.has(1);
  return (lowerBetter.test(metric) ? !rises : rises) ? 'buff' : 'nerf';
}

function entry(category, name, details, explicit) {
  details = details.map(line => line.replace(/^[●•]\s*/, ''));
  let kind = explicit || 'adjust', basis = explicit ? '公告标题' : '公告条目';
  if (details.some(x => /暂未(?:修复|生效)|尚未(?:修复|生效)|尚待修复|未能修复/.test(x))) {
    kind = 'other'; basis = '公告条目';
  } else if (!explicit) {
    const changes = new Set(details.map(numericKind));
    if (changes.size === 1 && !changes.has(null)) {
      kind = [...changes][0]; basis = '数值方向';
    }
  }
  return { kind, category, name, details, basis };
}

function modeBlocks(html, mode = 'mayhem') {
  const heading = mode === 'aram' ? /^(?:模式[：:]\s*)?(?:极地大乱斗|普通大乱斗)(?:模式)?(?:更新|改动|调整)?$/ : /^(?:模式[：:]\s*)?海克斯大乱斗(?:模式)?(?:更新|改动|调整)?$/;
  const clean = html.replace(/<!--[\s\S]*?-->|<(script|style)\b[^>]*>[\s\S]*?<\/\1>/gi, '');
  const headings = [...clean.matchAll(/<h([1-6])\b[^>]*>([\s\S]*?)<\/h\1>/gi)];
  const blocks = [];
  for (let i = 0; i < headings.length; i++) {
    const start = headings[i];
    if (!heading.test(plain(start[2]))) continue;
    const end = headings.slice(i + 1).find(h => Number(h[1]) <= Number(start[1]));
    // Some legacy articles end the mode section at the article container.
    const tail = clean.slice(start.index + start[0].length, end?.index);
    const foot = tail.search(/<\/article>|<(?:div|footer)\b[^>]*\bclass=["'][^"']*(?:art-foot|art-page|pagefoot|footer)/i);
    blocks.push({ body: foot < 0 ? tail : tail.slice(0, foot), level: Number(start[1]) });
  }
  return blocks;
}

function sectionEntries(block) {
  const entries = [];
  let category = '', categoryLabel = '', current = null;
  const flush = () => {
    if (current?.details.length) entries.push(entry(category, current.name, current.details, current.explicit));
    current = null;
  };
  // A full bold paragraph is a heading; inline bold inside a stat is not.
  for (const token of block.body.matchAll(/<(h[1-6]|p|li)\b[^>]*>([\s\S]*?)<\/\1>/gi)) {
    const tag = token[1].toLowerCase(), body = token[2];
    const text = plain(body);
    if (!text) continue;
    if (tag === 'h' + (block.level + 1)) {
      flush();
      categoryLabel = text;
      category = /(?:强化符文|海克斯符文)/.test(text) ? '强化符文' :
        /^(?:英雄|装备)(?:增强|加强|调整|削弱|改动)?$/.test(text) ? text.slice(0, 2) : text;
      continue;
    }
    if (!category) continue;
    const categoryKind = headingKind(categoryLabel);
    if (tag === 'li' && categoryKind === 'fix') {
      flush();
      const issue = text.replace(/^修复了一个(?:视觉)?BUG[，,]该BUG曾导致[：:]\s*/i, '');
      const subject = issue.match(/【([^】]+)】/)?.[1] || issue.replace(/^修复了/, '').replace(/[，。；（].*$/, '');
      entries.push(entry(category, subject.length > 23 ? subject.slice(0, 22) + '…' : subject, [text], categoryKind));
      continue;
    }
    if (tag === 'li' && /(?:移除|移出)/.test(categoryLabel)) {
      flush();
      entries.push(entry(category, text, [categoryLabel], null));
      continue;
    }
    // A few official lists place an unformatted champion name inside the previous list.
    // Only accept a short name when the following list entry is a numeric stat.
    if (category === '英雄' && tag === 'li' && /^[\p{Script=Han}·]{2,9}$/u.test(text) &&
        /^\s*<li\b[^>]*>[^<。]{1,30}[：:]\s*\d/i.test(block.body.slice(token.index + token[0].length))) {
      flush();
      current = { name: text, details: [], explicit: categoryKind };
      continue;
    }
    const fullBold = /^\s*<(strong|b)\b[^>]*>(?:(?!<\/\1>)[\s\S])+<\/\1>\s*$/i.test(body);
    if ((tag === 'p' && fullBold && !/[⇒→]/.test(text)) || /^h\d$/.test(tag)) {
      flush();
      if (/^(?:白银|黄金|棱彩)阶$/.test(text)) continue;
      const explicit = /^(?:新增|新加入|全新)(?:\s|[：:])/.test(text) ? 'new' : categoryKind;
      const name = text.replace(/^(?:新增|新加入|全新)[\s：:]+/, '').replace(/[：:]$/, '');
      current = { name, details: [], explicit };
      continue;
    }
    if (!current && tag === 'li') {
      const named = body.trim().match(/^<(?:strong|b)\b[^>]*>([\s\S]*?)<\/(?:strong|b)>\s*[：:]\s*([\s\S]+)$/i);
      if (named) entries.push(entry(category, plain(named[1]), [plain(named[2])], categoryKind));
      continue;
    }
    if (current) current.details.push(...body.split(/<br\b[^>]*>/i).map(plain).filter(Boolean));
  }
  flush();
  return entries;
}

function parseMain(official, html, allowClassicOnly) {
  checkSource(official);
  const title = plain(html.match(/<h1\b[^>]*>([\s\S]*?)<\/h1>/i)?.[1] || '');
  const versions = [...title.matchAll(/\b(\d{2}\.\d{1,2})\b/g)].map(x => x[1]);
  // Some Tencent PC releases use only a maintenance date in the title. The
  // opening maintenance paragraph explicitly names the version being deployed.
  const maintenanceVersion = !versions.length && normalizedTitle(title) === normalizedTitle(official.title) &&
    /停机.*版本更新公告/.test(title) && [...html.matchAll(/<p\b[^>]*>([\s\S]*?)<\/p>/gi)].slice(0, 12)
      .map(match => plain(match[1]).match(/(?:LOL|英雄联盟)将(?:于|在)[^。]{0,70}?(?:停机|维护)[^。]{0,130}?发布\s*(\d{2}\.\d{1,2})\s*版本/i)?.[1])
      .find(Boolean);
  if (!title.includes('版本') || !(versions.includes(official.patch) || maintenanceVersion === official.patch)) {
    throw new Error('公告正文标题与国服版本不一致');
  }
  const mayhemBlocks = modeBlocks(html);
  const entries = mayhemBlocks.flatMap(sectionEntries);
  const balanceEntries = championBalanceEntries(html, entries);
  if (!entries.length && !(allowClassicOnly && !mayhemBlocks.length && balanceEntries.length)) {
    throw new Error('腾讯公告中尚未识别到海克斯大乱斗的分项改动');
  }
  const { patch, samplePatch, url, publishedAt } = official;
  return { schema: 1, patch, samplePatch, title, url, publishedAt, entries, balanceEntries, hotfixes: official.hotfixes || [], hotfixDetails: [], balanceHotfixes: [] };
}

function championBalanceEntries(html, mayhem) {
  const project = (mode, rows) => rows.filter(row => row.category === '英雄')
    .map(({name, kind, details}) => ({mode, name, kind, details}));
  return [...project('mayhem', mayhem), ...project('aram', modeBlocks(html, 'aram').flatMap(sectionEntries))];
}

/** Returns only changes explicitly inside a dedicated mainland Mayhem section. */
export function parseMayhemArticle(official, html) {
  return parseMain(official, html, false);
}

async function downloadArticle(url, fetcher) {
  const response = await fetcher(url.href, { signal: AbortSignal.timeout(12000) });
  if (!response.ok) throw new Error('腾讯公告正文读取失败（' + response.status + '）');
  if (response.url && new URL(response.url).origin !== url.origin) throw new Error('公告正文来源域名不匹配');
  return response;
}

function normalizedTitle(value) {
  return plain(value || '').replace(/\s+/g, '');
}

async function articleContent(source, fetcher) {
  let url = tencentArticle(source.url);
  if (url.pathname === '/news/detail.shtml') {
    const id = url.searchParams.get('docid');
    if (!/^\d+$/.test(id || '')) throw new Error('无效的公告文档编号');
    const endpoint = new URL('https://apps.game.qq.com/cmc/zmMcnContentInfo?r0=json&source=web_pc&type=0&docid=' + id);
    const doc = await (await downloadArticle(endpoint, fetcher)).json();
    const row = doc?.data?.result;
    if (row?.sAuthor !== '英雄联盟官方' || String(row.iDocID) !== id ||
        normalizedTitle(row.sTitle) !== normalizedTitle(source.title)) throw new Error('腾讯公告文档身份不匹配');
    if (!row.sRedirectURL) {
      if (typeof row.sContent !== 'string') throw new Error('缺少腾讯公告正文');
      return { title: plain(row.sTitle), body: row.sContent };
    }
    url = tencentArticle(row.sRedirectURL);
  }
  const response = await downloadArticle(url, fetcher);
  const bytes = new Uint8Array(await response.arrayBuffer());
  const prefix = new TextDecoder().decode(bytes.subarray(0, 1800));
  const encoding = /charset\s*=\s*["']?gb(?:k|2312|18030)/i.test(prefix + ' ' + (response.headers?.get('content-type') || '')) ? 'gb18030' : 'utf-8';
  const body = new TextDecoder(encoding).decode(bytes);
  return { title: plain(body.match(/<h1\b[^>]*>([\s\S]*?)<\/h1>/i)?.[1] || ''), body };
}

// The CMC editor uses equal-size bold paragraphs for sibling sections and a small
// span with ● for a list marker. Preserve every sibling boundary, including other modes.
function hotfixBody(html) {
  const modeHeading = label => label.match(/^(海克斯大乱斗|极地大乱斗|普通大乱斗)(?:模式)?\s*[：:\-—]?\s*(BUG修复|问题修复|英雄(?:增强|削弱|调整)?|强化符文|装备|系统|平衡性调整|调整|改动|更新)?$/i);
  const safe = value => value.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const heading = (level, label) => {
    const mode = modeHeading(label);
    if (!mode) return '<h' + level + '>' + safe(label) + '</h' + level + '>';
    const category = mode[2] || '模式调整';
    return '<h' + level + '>' + mode[1] + '</h' + level + '><h' + (level + 1) + '>' + safe(category) + '</h' + (level + 1) + '>';
  };
  return html.replace(/<(h[1-5]|p)\b[^>]*>([\s\S]*?)<\/\1>/gi, (original, tag, inner) => {
    const label = plain(inner);
    if (tag.toLowerCase() !== 'p') return heading(Number(tag[1]), label);
    const strong = inner.match(/<(strong|b)\b[^>]*>([\s\S]*?)<\/\1>/i);
    if (strong && plain(strong[2]) === label) {
      const px = inner.match(/font-size\s*:\s*(\d+(?:\.\d+)?)px/i)?.[1];
      if (px && Number(px) >= 16) return heading(3, label);
      if (/^(?:英雄(?:增强|削弱|调整)?|强化符文|装备|系统|BUG修复|问题修复)$/i.test(label)) return heading(4, label);
    }
    if (/^[●•]/.test(label)) return '<li>' + safe(label.replace(/^[●•]\s*/, '')) + '</li>';
    return original;
  });
}

async function fetchHotfix(official, source, fetcher) {
  if (!source || typeof source.title !== 'string' || !source.title.trim() ||
      /云顶|手游|测试服/.test(source.title) || !Number.isFinite(Date.parse(source.publishedAt)) ||
      Date.parse(source.publishedAt) < Date.parse(official.publishedAt)) return null;
  const versions = [...source.title.matchAll(/\b(\d{2}\.\d{1,2})\b/g)];
  if (versions.length && versions.every(x => x[1] !== official.patch && x[1] !== official.samplePatch)) return null;
  const { title, body } = await articleContent(source, fetcher);
  if (normalizedTitle(title) !== normalizedTitle(source.title)) return null;
  const html = hotfixBody(body);
  const entries = modeBlocks(html).flatMap(sectionEntries);
  const balanceEntries = championBalanceEntries(html, entries);
  return {title, url: source.url, publishedAt: source.publishedAt, entries, balanceEntries, scoped: Boolean(entries.length || balanceEntries.length)};
}

export async function fetchMayhemNotes(official, fetcher = fetch) {
  checkSource(official);
  const { title, body } = await articleContent(official, fetcher);
  // CMC supplies the verified document title separately from its rich-text body.
  const article = /<h1\b/i.test(body) ? body : '<h1>' + title.replace(/[<>]/g, '') + '</h1>' + body;
  const notes = parseMain(official, article, true);
  const results = await Promise.allSettled(notes.hotfixes.map(source => fetchHotfix(official, source, fetcher)));
  for (const result of results) {
    if (result.status !== 'fulfilled' || !result.value) continue;
    const {entries, balanceEntries, scoped, ...source} = result.value;
    if (entries.length) notes.hotfixDetails.push({...source, entries});
    if (scoped) notes.balanceHotfixes.push({...source, entries: balanceEntries});
  }
  return notes;
}
