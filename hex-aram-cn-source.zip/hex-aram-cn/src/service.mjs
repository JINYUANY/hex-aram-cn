// The bundler supplies assets, embedded seeds and the two independent source adapters.
const pollMs = 5 * 60 * 1000;
const kinds = ['official', 'stats', 'aramgg'];
const current = new Map();
const inflight = new Map();

function entry(kind) {
  return current.get(kind) || {value: seeds[kind], checked: 0, tried: 0, stale: false};
}
function patchNumber(patch) {
  const [major, minor] = patch.split('.').map(Number);
  return major * 1000 + minor;
}
function json(value, options = {}) {
  return new Response(JSON.stringify(value), {headers: {'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...options}});
}
function isUsableSnapshot(kind,state,local){
  if(!state || !Number.isFinite(state.tried) || !state.value)return false;
  const v=state.value, baseline=local.value;
  if(kind==='stats')return v.schema===baseline.schema && Number.isSafeInteger(v.seq) && v.seq>=baseline.seq &&
    /^\d+\.\d+$/.test(v.patch) && patchNumber(v.patch)>=patchNumber(baseline.patch) &&
    Number.isFinite(Date.parse(v.cutoff)) && Date.parse(v.cutoff)>=Date.parse(baseline.cutoff) &&
    (v.seq!==baseline.seq || ((!baseline.revision || v.revision) &&
      Object.entries(baseline.enrichment || {}).every(([k,state])=>state!=='ready' || v.enrichment?.[k]==='ready') &&
      (!baseline.equipment?.catalogVersion || (v.equipment?.catalogVersion || '').localeCompare(baseline.equipment.catalogVersion,'en',{numeric:true})>=0))) &&
    Array.isArray(v.heroes) && v.heroes.length>0 && Array.isArray(v.augments) && Array.isArray(v.regions) && Array.isArray(v.equipment?.catalog);
  if(kind==='aramgg')return /^\d+\.\d+\.\d+$/.test(v.config?.version) &&
    v.config.version.localeCompare(baseline.config.version,'en',{numeric:true})>=0 &&
    (!v.catalog || Array.isArray(v.catalog.heroes));
  if(!/^\d+\.\d+$/.test(v.patch) || patchNumber(v.patch)<patchNumber(baseline.patch) || !v.samplePatch ||
      !Array.isArray(v.hotfixes) || !Number.isFinite(Date.parse(v.publishedAt)) || !Number.isFinite(Date.parse(v.checkedAt)))return false;
  try{validateGameFeed({schema:1,region:'CN',mode:'normal',official:v});}catch{return false;}
  return v.patch!==baseline.patch || Date.parse(v.checkedAt)>=Date.parse(baseline.checkedAt);
}
async function loadStored(bucket, kind) {
  const local=entry(kind);
  if(!bucket)return {state:local};
  const path=kind==='stats'?'snapshots/stats-v4':'snapshots/'+kind;
  let object;
  try{object=await bucket.get(path);}catch{return {state:local,unavailable:true};}
  if(!object)return {state:local};
  let saved;
  try{saved=await object.json();}catch{return {state:local,etag:object.etag};}
  if(!isUsableSnapshot(kind,saved,local))return {state:local,etag:object.etag};
  if(kind==='official' && ['mayhem','balanceNotices','championBalance'].some(key=>local.value[key] && !saved.value[key]) && saved.value.patch===local.value.patch && saved.value.url===local.value.url){
    saved.value={...local.value,...saved.value};
    for(const key of ['mayhem','balanceNotices','championBalance'])saved.value[key] ??= local.value[key];
    saved.tried=0;
  }
  if(kind==='official' && saved.value.championBalance && local.value.championBalance){
    saved.value.championBalance=carryBalanceSkills(saved.value.championBalance,local.value.championBalance);
  }
  const state=saved.tried>=local.tried?saved:local;
  current.set(kind,state);return {state,etag:object.etag};
}
async function sync(kind, env, manual=false, reconnect=false) {
  const bucket=env.BUCKET;
  let state = entry(kind);
  const now = Date.now();
  const fresh = s => !(manual && env.PUBLIC_CHANNEL) && !(reconnect && env.PUBLIC_CHANNEL && s.stale) && s.tried && now - s.tried < (manual ? 12000 : s.stale ? 60000 : pollMs);
  if (fresh(state)) return state;
  if (inflight.has(kind)) return inflight.get(kind);
  const work = (async () => {
    let etag,unavailable;
    if (bucket) ({state, etag,unavailable} = await loadStored(bucket, kind));
    if (fresh(state)) return state;
    let next;
    try {
      let value;
      if (kind === 'stats') value=await fetchStats(state.value.seq,state.value,manual);
      else if (kind === 'aramgg') {
        let previous=state.value, mirrored=null;
        if(env.PUBLIC_CHANNEL){
          const feed=await readGameFeed(manual).catch(()=>null);
          const mirror=feed?.aramgg, incoming=mirror?.catalog;
          if(incoming?.heroes?.length && incoming.version===mirror.config?.version && incoming.patch===mirror.config.patch &&
              (!previous.catalog || patchNumber(incoming.patch)>=patchNumber(previous.catalog.patch)) &&
              (!previous.catalog || incoming.version.localeCompare(previous.catalog.version,'en',{numeric:true})>=0)){
            mirrored=mirror;previous={...previous,catalog:incoming};
          }
        }
        value=await fetchAramgg(previous,env.ARAMGG_API_KEY).catch(error=>{
          if(mirrored && mirrored.config.version.localeCompare(previous.config.version,'en',{numeric:true})>=0)return {...mirrored,status:'mirror'};
          throw error;
        });
        if(env.PUBLIC_CHANNEL && value.catalog && !env.ARAMGG_API_KEY)value.status='mirror';
      }
      else if(env.PUBLIC_CHANNEL){
        const feed=await readGameFeed(manual);
        value={...feed.official};
        if(value.patch===state.value.patch && value.url===state.value.url){
          for(const key of ['championBalance','balanceNotices'])value[key] ??= state.value[key];
          value.championBalance=carryBalanceSkills(value.championBalance,state.value.championBalance);
        }
        if(value.patch===state.value.patch && Date.parse(value.checkedAt)<Date.parse(state.value.checkedAt))throw Error('公告镜像尚未追上缓存');
      } else value=await collectGame(state.value,env.HERO_POOL_URL,fetch,entry('stats').value.heroes);
      if(kind==='stats' && value && (patchNumber(value.patch)<patchNumber(state.value.patch) ||
         (value.patch===state.value.patch && Date.parse(value.cutoff)<Date.parse(state.value.cutoff))))throw Error('样本时间或版本倒退');
      if (kind === 'official' && patchNumber(value.patch) < patchNumber(state.value.patch))
        throw new Error('上游返回较早公告');
      if (kind === 'official' && value.url === state.value.url) {
        value = {...value, maintenanceStart:value.maintenanceStart || state.value.maintenanceStart,
          maintenanceEnd:value.maintenanceEnd || state.value.maintenanceEnd,
          hotfixes:value.hotfixesAvailable ? value.hotfixes : state.value.hotfixes};
        if (value.publishedAt.endsWith('T00:00:00+08:00') && value.publishedAt.slice(0,10) === state.value.publishedAt.slice(0,10))
          value.publishedAt = state.value.publishedAt;
      }
      next = {value:value || state.value, tried:now, checked:kind==='official'?Date.parse(value.checkedAt):now, stale:kind==='official' && now-Date.parse(value.checkedAt)>8*3600000};
    } catch (error) {
      next = {...state, tried:now, stale:true};
      if(kind==='aramgg') {
        const reason=error.http ? 'HTTP '+error.http : error.name==='TimeoutError' ? 'timeout' : error.name;
        console.warn('ARAMGG public manifest refresh failed',reason);
        next.reason=reason;
      }
    }
    if (bucket && !unavailable) {
      const path = kind === 'stats' ? 'snapshots/stats-v4' : 'snapshots/' + kind;
      try {
        const result=await bucket.put(path,JSON.stringify(next),{onlyIf:etag?{etagMatches:etag}:{etagDoesNotMatch:'*'}});
        if(!result){
          const winner=await loadStored(bucket,kind);
          if(!winner.unavailable && winner.etag && isUsableSnapshot(kind,winner.state,next))return winner.state;
        }
      }catch{/* The verified result remains usable in memory when storage is unavailable. */}
    }
    current.set(kind, next);
    return next;
  })().catch(() => ({...entry(kind), stale:true})).finally(() => inflight.delete(kind));
  inflight.set(kind, work);
  return work;
}
function metadata(state) {
  return {checked:state.checked, stale:state.stale, ...(state.stale && state.reason ? {reason:state.reason} : {})};
}
export default {
  async fetch(request, env = {}) {
    const url = new URL(request.url);
    const path = url.pathname;
    if (!['GET','HEAD'].includes(request.method)) return new Response('Method not allowed', {status:405});
    if (path === '/api/bootstrap') {
      const states = await Promise.all(kinds.map(k => loadStored(env.BUCKET, k).then(r => r.state)
        .catch(() => ({...entry(k), stale:true}))));
      return json(Object.fromEntries(kinds.map((k,i) => [k, {value:states[i].value, ...metadata(states[i])}])));
    }
    if (path === '/api/official' || path === '/api/stats' || path === '/api/aramgg') {
      const kind = path.slice(5);
      const state = await sync(kind, env, url.searchParams.has('check'),url.searchParams.has('reconnect'));
      const unchanged = kind === 'stats' && String(state.value.seq) === url.searchParams.get('seq') &&
        (state.value.revision || '') === (url.searchParams.get('rev') || '');
      return json({value:unchanged ? null : state.value, ...metadata(state)});
    }
    const pairRequest=path.match(/^\/api\/augment-pairs\/(\d{1,2}\.\d{1,2})\/([1-9]\d{0,5})$/);
    if(pairRequest)return json(await readVerifiedPairs(env.BUCKET,pairRequest[1],pairRequest[2],async()=>(await loadStored(env.BUCKET,'stats')).state.value.equipment));
    const trioHero = path.match(/^\/api\/aramgg\/trios\/([1-9]\d{0,5})$/)?.[1];
    if (trioHero) {
      const gg = (await sync('aramgg',env)).value;
      const ah=(await loadStored(env.BUCKET,'stats').catch(()=>({state:entry('stats')}))).state.value;
      if (!ah.heroes.some(h=>h.id===trioHero) && !gg.catalog?.heroes.some(h=>h.id===trioHero)) return new Response('未知英雄',{status:404});
      return json(await getTrios(gg,env,trioHero));
    }
    if (path === '/api/sync') {
      const states = await Promise.all(kinds.map(kind => sync(kind, env,url.searchParams.has('check'))));
      return json({official:{patch:states[0].value.patch,...metadata(states[0])},
        stats:{patch:states[1].value.patch, seq:states[1].value.seq, matches:states[1].value.matches,
          cutoff:states[1].value.cutoff,...metadata(states[1])},
        aramgg:{publishedVersion:states[2].value.config.version,samplePatch:states[2].value.catalog?.patch || null,
          access:states[2].value.status,...metadata(states[2])}});
    }
    const asset = assets[path === '/' ? '/index.html' : path];
    if (!asset) return new Response('页面不存在', {status:404});
    const [type, content, binary] = asset;
    const body = request.method === 'HEAD' ? null : binary ? Uint8Array.from(atob(content), c => c.charCodeAt(0)) : content;
    return new Response(body, {headers:{'content-type':type,'cache-control':'no-cache','x-content-type-options':'nosniff'}});
  }
};
