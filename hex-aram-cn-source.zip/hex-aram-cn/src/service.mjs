// The bundler supplies assets, embedded seeds and the two independent source adapters.
const pollMs = 5 * 60 * 1000;
const kinds = ['official', 'stats', 'aramgg'];
const current = new Map();
const inflight = new Map();

function entry(kind) {
  return current.get(kind) || {value: seeds[kind], checked: 0, tried: 0, stale: false};
}
function patchNumber(patch) {
  const [major, minor] = patch.split('.').map(Number);
  return major * 1000 + minor;
}
function json(value, options = {}) {
  return new Response(JSON.stringify(value), {headers: {'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...options}});
}
async function loadStored(bucket, kind) {
  const local = entry(kind);
  if (!bucket) return {state:local};
  const path = kind === 'stats' ? 'snapshots/stats-v4' : 'snapshots/' + kind;
  const object = await bucket.get(path);
  if (!object) return {state:local};
  const saved = await object.json();
  const state = saved.tried >= local.tried ? saved : local;
  current.set(kind, state);
  return {state, etag:object.etag};
}
async function sync(kind, env) {
  const bucket=env.BUCKET;
  let state = entry(kind);
  const now = Date.now();
  const fresh = s => s.tried && now - s.tried < (s.stale ? 60000 : pollMs);
  if (fresh(state)) return state;
  if (inflight.has(kind)) return inflight.get(kind);
  const work = (async () => {
    let etag;
    if (bucket) ({state, etag} = await loadStored(bucket, kind));
    if (fresh(state)) return state;
    let next;
    try {
      let value;
      if (kind === 'stats') value=await fetchStats(state.value.seq);
      else if (kind === 'aramgg') value=await fetchAramgg(state.value,env.ARAMGG_API_KEY);
      else value=await fetchOfficial();
      if(kind==='stats' && value && !value.holdingBaseline && value.patch===state.value.patch)
        value.holdingBaseline=state.value.holdingBaseline ?? null;
      if (kind === 'official' && patchNumber(value.patch) < patchNumber(state.value.patch))
        throw new Error('上游返回较早公告');
      if (kind === 'official' && value.url === state.value.url) {
        value = {...value, maintenanceStart:value.maintenanceStart || state.value.maintenanceStart,
          maintenanceEnd:value.maintenanceEnd || state.value.maintenanceEnd,
          hotfixes:value.hotfixesAvailable ? value.hotfixes : state.value.hotfixes};
        if (value.publishedAt.endsWith('T00:00:00+08:00') && value.publishedAt.slice(0,10) === state.value.publishedAt.slice(0,10))
          value.publishedAt = state.value.publishedAt;
      }
      next = {value:value || state.value, tried:now, checked:now, stale:false};
    } catch (error) {
      next = {...state, tried:now, stale:true};
      if(kind==='aramgg') {
        const reason=error.http ? 'HTTP '+error.http : error.name==='TimeoutError' ? 'timeout' : error.name;
        console.warn('ARAMGG public manifest refresh failed',reason);
        next.reason=reason;
      }
    }
    if (bucket) {
      const path = kind === 'stats' ? 'snapshots/stats-v4' : 'snapshots/' + kind;
      const result = await bucket.put(path, JSON.stringify(next),
        {onlyIf:etag ? {etagMatches:etag} : {etagDoesNotMatch:'*'}});
      if (!result) {
        const winner = await loadStored(bucket, kind);
        return winner.state;
      }
    }
    current.set(kind, next);
    return next;
  })().catch(() => ({...entry(kind), stale:true})).finally(() => inflight.delete(kind));
  inflight.set(kind, work);
  return work;
}
function metadata(state) {
  return {checked:state.checked, stale:state.stale, ...(state.stale && state.reason ? {reason:state.reason} : {})};
}
export default {
  async fetch(request, env = {}) {
    const url = new URL(request.url);
    const path = url.pathname;
    if (!['GET','HEAD'].includes(request.method)) return new Response('Method not allowed', {status:405});
    if (path === '/api/bootstrap') {
      const states = await Promise.all(kinds.map(k => loadStored(env.BUCKET, k).then(r => r.state)
        .catch(() => ({...entry(k), stale:true}))));
      return json(Object.fromEntries(kinds.map((k,i) => [k, {value:states[i].value, ...metadata(states[i])}])));
    }
    if (path === '/api/official' || path === '/api/stats' || path === '/api/aramgg') {
      const kind = path.slice(5);
      const state = await sync(kind, env);
      const unchanged = kind === 'stats' && String(state.value.seq) === url.searchParams.get('seq');
      return json({value:unchanged ? null : state.value, ...metadata(state)});
    }
    const pairRequest=path.match(/^\/api\/augment-pairs\/(\d{1,2}\.\d{1,2})\/([1-9]\d{0,5})$/);
    if(pairRequest)return json(await readVerifiedPairs(env.BUCKET,pairRequest[1],pairRequest[2],async()=>(await loadStored(env.BUCKET,'stats')).state.value.equipment));
    const trioHero = path.match(/^\/api\/aramgg\/trios\/([1-9]\d{0,5})$/)?.[1];
    if (trioHero) {
      const gg = (await sync('aramgg',env)).value;
      const ah=(await loadStored(env.BUCKET,'stats').catch(()=>({state:entry('stats')}))).state.value;
      if (!ah.heroes.some(h=>h.id===trioHero) && !gg.catalog?.heroes.some(h=>h.id===trioHero)) return new Response('未知英雄',{status:404});
      return json(await getTrios(gg,env,trioHero));
    }
    if (path === '/api/sync') {
      const states = await Promise.all(kinds.map(kind => sync(kind, env)));
      return json({official:{patch:states[0].value.patch,...metadata(states[0])},
        stats:{patch:states[1].value.patch, seq:states[1].value.seq, matches:states[1].value.matches,
          cutoff:states[1].value.cutoff,...metadata(states[1])},
        aramgg:{publishedVersion:states[2].value.config.version,samplePatch:states[2].value.catalog?.patch || null,
          access:states[2].value.status,...metadata(states[2])}});
    }
    const asset = assets[path === '/' ? '/index.html' : path];
    if (!asset) return new Response('页面不存在', {status:404});
    const [type, content, binary] = asset;
    const body = request.method === 'HEAD' ? null : binary ? Uint8Array.from(atob(content), c => c.charCodeAt(0)) : content;
    return new Response(body, {headers:{'content-type':type,'cache-control':'no-cache','x-content-type-options':'nosniff'}});
  }
};
