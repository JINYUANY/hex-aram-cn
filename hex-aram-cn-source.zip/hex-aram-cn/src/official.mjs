// Public, anonymous Tencent sources. The first page of the PC patch archive excludes TFT.
const archive = 'https://lol.qq.com/gicp/news/423/2/1334/1.html';
const notices = 'https://apps.game.qq.com/cmc/zmMcnTargetContentList?r0=json&page=1&num=30&target=24&source=web_pc';

async function get(url, fetcher) {
  const response = await fetcher(url, { signal: AbortSignal.timeout(8000) });
  if (!response.ok) throw new Error('腾讯公告请求失败（' + response.status + '）');
  return response;
}

async function html(url, fetcher) {
  const bytes = new Uint8Array(await (await get(url, fetcher)).arrayBuffer());
  const prefix = new TextDecoder().decode(bytes.subarray(0, 1800));
  return new TextDecoder(/charset\s*=\s*["']?gb(?:k|2312|18030)/i.test(prefix) ? 'gb18030' : 'utf-8').decode(bytes);
}

function plain(s) {
  return s.replace(/<[^>]*>/g, ' ').replace(/&(?:nbsp|ensp|emsp);/gi, ' ').replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim();
}

function officialURL(href) {
  const url = new URL(href, archive);
  if (url.origin !== 'https://lol.qq.com') throw new Error('无效的国服公告网址');
  return url.href;
}

function shanghai(s) {
  const normalized = s.trim().replace(' ', 'T');
  return (normalized.length === 10 ? normalized + 'T00:00:00' : normalized) + '+08:00';
}

function archiveHead(doc) {
  const row = doc.match(/<li\b[^>]*class=["']newsitem["'][^>]*>([\s\S]*?)<\/li>/i)?.[1];
  const link = row?.match(/<a\b[^>]*\bhref=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/i);
  const date = row?.match(/\b(20\d{2}-\d{2}-\d{2})\b/)?.[1];
  if (!link || !date) throw new Error('腾讯版本公告列表格式已变更');
  return { title: plain(link[2]), url: officialURL(link[1]), publishedAt: shanghai(date) };
}

function feedRows(doc) {
  const result = doc?.data?.result;
  if (!Array.isArray(result) || !result.length) throw new Error('腾讯综合公告列表暂不可用');
  return result.filter(x => x.sAuthor === '英雄联盟官方' && typeof x.sTitle === 'string' &&
    /^20\d{2}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(x.sCreated) && /^\d+$/.test(x.iDocID))
    .map(x => {
      const canonical = 'https://lol.qq.com/news/detail.shtml?docid=' + x.iDocID;
      let url = canonical;
      if (x.sRedirectURL) {
        try { url = officialURL(x.sRedirectURL); } catch { /* Use the official document URL. */ }
      }
      return { title: plain(x.sTitle), url, publishedAt: shanghai(x.sCreated) };
    }).sort((a, b) => b.publishedAt.localeCompare(a.publishedAt));
}

function maintenanceTimes(body, publishedAt) {
  const match = body.match(/(?:LOL|英雄联盟|我们)?将(?:于|在)\s*(\d{1,2})月(\d{1,2})日([^。；]{0,160}?(?:停机|维护)[^。；]{0,130})/i);
  if (!match) return {};
  const month = Number(match[1]), day = Number(match[2]);
  let year = Number(publishedAt.slice(0, 4));
  if (month === 1 && publishedAt.slice(5, 7) === '12') year++;
  if (month < 1 || month > 12 || day < 1 || day > 31) return {};
  const pad = v => String(v).padStart(2, '0');
  const date = year + '-' + pad(month) + '-' + pad(day);
  const range = match[3].match(/(\d{1,2})[:：](\d{2})\s*[-－—~至]\s*(\d{1,2})[:：](\d{2})/);
  if (!range) return {};
  const at = (hour, minute) => shanghai(date + ' ' + pad(hour) + ':' + minute + ':00');
  const start = at(range[1], range[2]);
  const end = at(range[3], range[4]);
  return { maintenanceStart: start, maintenanceEnd: end > start ? end : null };
}

/**
 * Latest announced mainland PC patch. maintenanceEnd is Tencent's scheduled end,
 * not a claim all servers are live. checkedAt records retrieval of official metadata.
 * Null maintenance times mean they could not be extracted. hotfixesAvailable=false
 * means the secondary list was unavailable. On total failure the caller retains
 * its previous successful snapshot, including its original checkedAt.
 */
export async function fetchOfficial(fetcher = fetch) {
  const [latest, supplementary] = await Promise.allSettled([
    html(archive, fetcher).then(archiveHead),
    get(notices, fetcher).then(r => r.json()).then(feedRows)
  ]);
  const rows = supplementary.status === 'fulfilled' ? supplementary.value : [];
  const feedPatch = rows.find(x => !/云顶|手游|测试服|周免/.test(x.title) &&
    /\d{2}\.\d{1,2}版本(?:更新)?公告/.test(x.title));
  let head = latest.status === 'fulfilled' ? latest.value : feedPatch;
  // The two publication systems may arrive in either order. Prefer a newer day.
  if (head && feedPatch && feedPatch.publishedAt.slice(0, 10) > head.publishedAt.slice(0, 10)) head = feedPatch;
  if (!head) throw new Error('腾讯国服版本公告暂不可用');

  let article = '';
  try { article = await html(head.url, fetcher); } catch { /* Keep the verified index entry. */ }
  const body = plain(article);
  const release = body.match(/发布\s*(\d{2}\.\d{1,2})\s*版本/)?.[1];
  const titleVersions = [...head.title.matchAll(/\b(\d{2}\.\d{1,2})\b/g)];
  const patch = release || titleVersions.at(-1)?.[1];
  if (!patch) throw new Error('正在等待国服公告确认版本号');
  const [major, minor] = patch.split('.');
  // Since 2025 the public season-year (e.g. 26.23) and client patch
  // (16.23) have different major numbers. A caller must match both explicitly.
  const samplePatch = String(Number(major) >= 25 ? Number(major) - 10 : Number(major)) + '.' + minor;
  const exact = article.match(/class=["']art-time["'][^>]*>\s*(20\d{2}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})/i)?.[1];
  const publishedAt = exact ? shanghai(exact) : head.publishedAt;
  return { patch, samplePatch, title: head.title, url: head.url, publishedAt,
    maintenanceStart: null, maintenanceEnd: null, ...maintenanceTimes(body, publishedAt),
    checkedAt: new Date().toISOString(), listUrl: archive,
    hotfixes: rows.filter(x => x.publishedAt >= publishedAt && !/云顶|手游|测试服/.test(x.title) &&
      /热更|热修|不停机更新|平衡性调整公告/.test(x.title)).slice(0, 6),
    hotfixesAvailable: supplementary.status === 'fulfilled' };
}
