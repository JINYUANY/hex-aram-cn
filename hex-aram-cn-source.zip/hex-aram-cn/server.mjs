import './build.mjs';
import {createServer} from 'node:http';
import {mkdir,readFile,writeFile,rename} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const {default:worker} = await import('./dist/server/index.js');
await mkdir('.cache',{recursive:true});
const fileFor = key => '.cache/' + key.split('/').at(-1) + '.json';
const digest = text => createHash('sha256').update(text).digest('hex');
const bucket = {
  async get(key) {
    try {
      const data = await readFile(fileFor(key),'utf8');
      return {etag:digest(data),json:async()=>JSON.parse(data)};
    } catch (e) {if(e.code==='ENOENT')return null;throw e;}
  },
  async put(key, data, opts) {
    const current = await this.get(key);
    const condition = opts.onlyIf;
    if (condition.etagMatches && condition.etagMatches !== current?.etag || condition.etagDoesNotMatch === '*' && current) return null;
    const name = fileFor(key);
    const tmp = name + '.' + process.pid + '.tmp';
    await writeFile(tmp,data);
    await rename(tmp,name);
    return {etag:digest(data)};
  }
};
const port = Number(process.env.PORT || 4187);
const base = 'http://127.0.0.1:' + port;
const env = {BUCKET:bucket,HERO_POOL_URL:process.env.HERO_POOL_URL,ARAMGG_API_KEY:process.env.ARAMGG_API_KEY};
const server = createServer(async (req,res)=>{
  try {
    const result = await worker.fetch(new Request(new URL(req.url,base),{method:req.method}),env);
    res.writeHead(result.status,Object.fromEntries(result.headers));res.end(Buffer.from(await result.arrayBuffer()));
  } catch {res.writeHead(500);res.end('读取暂时失败');}
});
server.on('error',e=>{console.error(e.message);process.exitCode=1;});
server.listen(port,'127.0.0.1',()=> {
  console.log('国服海克斯战局查询页 ' + base);
  const update=()=>worker.fetch(new Request(base+'/api/sync'),env).catch(()=>{});
  update(); setInterval(update,300000).unref();
});
