import {readFile, readdir, mkdir, writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
process.chdir(fileURLToPath(new URL('.', import.meta.url)));
const types = {html:'text/html; charset=utf-8', js:'text/javascript; charset=utf-8', css:'text/css; charset=utf-8', json:'application/json', webp:'image/webp'};
const assets = {};
for (const file of await readdir('public')) {
  const suffix = file.split('.').at(-1);
  const content = await readFile('public/' + file);
  const binary = suffix === 'webp';
  assets['/' + file] = [types[suffix], content.toString(binary ? 'base64' : 'utf8'), binary];
}
for (const kind of ['champion','augment']) {
  const file=kind+'-catalog.json';
  assets['/'+file]=[types.json,await readFile('data/'+file,'utf8'),false];
}
const equipmentSource=(await readFile('src/equipment.mjs','utf8')).replace(/^export /gm,'');
const parts = ['const assets=' + JSON.stringify(assets) + ';', 'const {prepareEquipment,fetchEquipmentCatalog,canShowItemWinRate}=(()=>{\n'+equipmentSource+'\nreturn {prepareEquipment,fetchEquipmentCatalog,canShowItemWinRate};\n})();'];
const seeds = {};
for (const [kind, fn] of [['official','fetchOfficial'], ['stats','fetchStats']]) {
  seeds[kind] = JSON.parse(await readFile('data/' + kind + '.json', 'utf8'));
  const source = (await readFile('src/' + kind + '.mjs','utf8')).replace(/^import .* from '\.\/equipment\.mjs';\n/m,'').replace(/^export /gm,'');
  parts.push('const ' + fn + ' = (() => {\n' + source + '\nreturn ' + fn + ';\n})();');
}
seeds.official.mayhem=JSON.parse(await readFile('data/mayhem-notes.json','utf8'));
seeds.official.heroPool=JSON.parse(await readFile('data/hero-pool.json','utf8'));
for (const [name,functions] of [['mayhem-notes','fetchMayhemNotes'],['hero-pool','fetchHeroPool,validateHeroPool'],['game-feed','collectGame,readGameFeed,validateGameFeed']]){
  const code=(await readFile('src/'+name+'.mjs','utf8')).replace(/^import .+;$/gm,'').replace(/^export /gm,'');
  parts.push('const {'+functions+'}=(()=>{\n'+code+'\nreturn {'+functions+'};})();');
}
seeds.aramgg=JSON.parse(await readFile('data/aramgg.json','utf8'));
const ggSource=(await readFile('src/aramgg.mjs','utf8')).replace(/^export /gm,'');
parts.push('const {fetchAramgg,getTrios} = (()=>{\n'+ggSource+'\nreturn {fetchAramgg,getTrios};\n})();');
const pairsSource=(await readFile('src/augment-pairs.mjs','utf8')).replace(/^export /gm,'');
parts.push('const readVerifiedPairs=(()=>{\n'+pairsSource+'\nreturn readVerifiedPairs;\n})();');
parts.push('const seeds=' + JSON.stringify(seeds) + ';', await readFile('src/service.mjs', 'utf8'));
await mkdir('dist/server', {recursive:true});
await writeFile('dist/server/index.js', parts.join('\n'));
export {assets};
export const browserService=parts.slice(1).join('\n').replace('export default {','return {');
