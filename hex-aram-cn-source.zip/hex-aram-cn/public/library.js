'use strict';
let championBook = {}, augmentBook = {}, itemIcons = {}, equipmentById = new Map();
let bundledCatalogs, activeCatalogRequest, selectedCatalogPatch, retryCatalogAfter=0;
const itemKinds = {complete:'成装',boots:'鞋子',component:'组件',consumable:'消耗品',starter:'出门装',special:'特殊物品',augmentReward:'强化关联物品',other:'其他'};
const panelStats = [
  ['hp','生命值','hpperlevel'],['mp','技能资源','mpperlevel'],['attackdamage','攻击力','attackdamageperlevel'],
  ['attackspeed','攻击速度','attackspeedperlevel'],['armor','护甲','armorperlevel'],['spellblock','魔抗','spellblockperlevel'],
  ['hpregen','生命回复','hpregenperlevel'],['mpregen','资源回复','mpregenperlevel'],['crit','暴击率','critperlevel'],
  ['attackrange','攻击距离'],['movespeed','移动速度']
];
function atlasTile(path,index,cols,rows,style='') {
  if(!Number.isInteger(index) || index<0 || !cols || !rows) return '';
  const x=100*(index%cols)/Math.max(1,cols-1), y=100*Math.floor(index/cols)/Math.max(1,rows-1);
  return '<span aria-hidden="true" class="portrait '+style+'" style="background-image:url('+artPath(path)+');background-size:'+(cols*100)+'% '+(rows*100)+'%;background-position:'+x+'% '+y+'%"></span>';
}
function imageFallback(url,letter) {
  let safe=false;
  try {safe=new URL(url).protocol==='https:';} catch {}
  return safe ? '<img class="portrait" loading="lazy" referrerpolicy="no-referrer" src="'+esc(url)+'" alt="">' :
    '<span class="portrait" aria-hidden="true">'+esc(letter)+'</span>';
}
function itemIcon(item) {
  return (stats.equipment?.catalogVersion===itemIcons.version && atlasTile('/items-atlas.webp',itemIcons.byId?.[item.id],itemIcons.cols,itemIcons.rows)) ||
    imageFallback(item.icon,item.name.slice(0,1));
}
function lookupAugmentIcon(a) {
  const entry=currentAugmentDefinition(a);
  if(entry?.icon){
    const bundled=bundledCatalogs?.augments;
    const fallback=bundled?.patch===stats.patch && bundled.byId?.[a.id];
    if(globalThis.navigator?.onLine===false && fallback?.name===entry.name && bundled.atlas && Number.isInteger(fallback.iconIndex))
      return atlasTile('/augment-atlas.webp',fallback.iconIndex,bundled.atlas.columns,bundled.atlas.rows,'augment-art');
    return imageFallback(entry.icon,a.name.slice(0,1));
  }
  const grid=augmentBook.atlas;
  return grid && entry ? atlasTile('/augment-atlas.webp',entry.iconIndex,grid.columns,grid.rows,'augment-art') : '';
}
function currentAugmentDefinition(a) {
  const entry=augmentBook.patch===stats?.patch && augmentBook.byId?.[a.id];
  return entry && entry.name===a.name && (!a.rarity || entry.rarity===a.rarity) ? entry : undefined;
}
function definition(a) {
  return currentAugmentDefinition(a)?.description || '';
}
function skillIcon(skill) {
  if(skill.url)return imageFallback(skill.url,skill.slot);
  const s=championBook.sprite;
  return s?atlasTile('/champion-skills.webp',skill.icon,s.cols,s.rows,'skill-icon'):'';
}
// Dynamic catalogs are keyed by the sample's in-game patch, independently of the app release.
function selectGameCatalogPatch(patch) {
  if(!/^\d+\.\d+$/.test(patch) || selectedCatalogPatch===patch)return;
  bundledCatalogs ??= {heroes:championBook,augments:augmentBook};
  selectedCatalogPatch=patch;
  activeCatalogRequest=null;
  retryCatalogAfter=0;
  const cached=kind=>{
    try {
      const value=JSON.parse(localStorage.getItem('hex-aram:game-catalog-v1:'+kind));
      return value?.patch===patch && value.byId && Object.keys(value.byId).length ? value : {};
    } catch {return {};}
  };
  const heroes=cached('heroes'), augments=cached('augments');
  const baseHeroes=bundledCatalogs.heroes.version?.startsWith(patch+'.')?bundledCatalogs.heroes:{};
  const baseAugments=bundledCatalogs.augments.patch===patch?bundledCatalogs.augments:{};
  const revision=v=>Number(v?.split('.')[2] || 0);
  championBook=heroes.version?.startsWith(patch+'.') && revision(heroes.version)>revision(baseHeroes.version)?heroes:baseHeroes;
  augmentBook=augments.patch===patch && (!baseAugments.byId ||
    (augments.textAvailable && augments.sampleSeq>=baseAugments.sampleSeq))?augments:baseAugments;
}
function storeGameCatalog(kind,book) {
  try {localStorage.setItem('hex-aram:game-catalog-v1:'+kind,JSON.stringify(book));} catch {}
}
function catalogRevision(response) {
  return response.headers?.get('etag') || response.headers?.get('last-modified') || '';
}
async function catalogJSON(url,revisions) {
  const response=await fetch(url,{cache:'no-cache',signal:AbortSignal.timeout(120000)});
  if(!response.ok || (response.url && new URL(response.url).pathname!==new URL(url).pathname))throw Error('对应版本的资料暂不可用');
  if(revisions)revisions[url]=catalogRevision(response);
  return response.json();
}
function cleanGameText(text) {
  return text.replace(/<(?:br|hr)\s*\/?>|<li>/gi,'\n').replace(/<[^>]+>|%i:[^%]+%/gi,'')
    .replace(/&(?:nbsp|amp|lt|gt|quot|apos|#39);/g,s=>({'&nbsp;':' ','&amp;':'&','&lt;':'<','&gt;':'>','&quot;':'"','&apos;':"'",'&#39;':"'"}[s]))
    .replace(/[ \t]+/g,' ').replace(/\s*\n+\s*/g,'\n').trim();
}
async function downloadHeroCatalog(sample,checkRevision=false) {
  const patch=sample.patch;
  const valid=v=>typeof v==='string' && /^\d+\.\d+\.\d+$/.test(v) && v.startsWith(patch+'.');
  const hint=sample.equipment?.catalogVersion;
  let version=valid(hint)?hint:patch+'.1';
  if(checkRevision || !valid(hint)){
    try {
      const versions=await catalogJSON('https://ddragon.leagueoflegends.com/api/versions.json');
      if(Array.isArray(versions)){
        const revisions=versions.filter(valid);
        if(revisions.length)version=[version,...revisions].sort((a,b)=>Number(b.split('.')[2])-Number(a.split('.')[2]))[0];
      }
    } catch {}
  }
  if(championBook.version===version && sample.heroes.every(h=>championBook.byId?.[h.id]))return championBook;
  const cdn='https://ddragon.leagueoflegends.com/cdn/'+version;
  const sourceUrl=cdn+'/data/zh_CN/championFull.json';
  const source=await catalogJSON(sourceUrl);
  if(source.version!==version || !source.data)throw Error('英雄资料版本不一致');
  const byId={},roles={Assassin:'刺客',Fighter:'战士',Mage:'法师',Marksman:'射手',Support:'辅助',Tank:'坦克'};
  for(const c of Object.values(source.data)){
    const skills=[c.passive,...c.spells].map((s,index)=>({
      slot:['P','Q','W','E','R'][index], name:s.name,description:cleanGameText(s.description),
      url:cdn+'/img/'+(index?'spell':'passive')+'/'+encodeURIComponent(s.image.full)
    }));
    if(!/^\d+$/.test(c.key) || !c.title || !c.name || skills.length!==5 || skills.some(s=>!s.name || !s.description))
      throw Error('英雄技能资料不完整');
    // Search aliases stay attached only to the same champion identity.
    const original=bundledCatalogs?.heroes.byId?.[c.key];
    const keywords=original?.key===c.id?original.keywords:[];
    byId[c.key]={id:c.key,key:c.id,name:c.title,title:c.name,keywords,stats:c.stats,resourceType:c.partype,
      roles:c.tags.map(t=>roles[t] || t),skills};
  }
  if(!sample.heroes.every(h=>byId[h.id]))throw Error('英雄资料不完整');
  return {patch,version,fetchedAt:new Date().toISOString(),locale:'zh_CN',sourceUrl,byId};
}
// RST v5 exports newly introduced translation keys as the low 38 bits of XXH3-64.
// Default short-input secret and zero-seed mixes from the XXH3 specification (https://xxhash.com/).
const rstSecret=new DataView(Uint8Array.from((
  'b8fe6c3923a44bbe7c01812cf721ad1cded46de9839097db7240a4a4b7b3671f'+
  'cb79e64eccc0e578825ad07dccff7221b8084674f743248ee03590e6813a264c'+
  '3c2852bb91c300cb88d0658b1b532ea371644897a20df94e3819ef46a9deacd8'+
  'a8fa763fe39c343ff9dcbbc7c70b4f1d8a51e04bcdb45931c89f7ec9d9787364'
).match(/../g),byte=>parseInt(byte,16)).buffer);
function rstKey(name) {
  if(name.length<4 || name.length>128 || !/^[a-z0-9_.:-]+$/.test(name))return '';
  const bytes=Uint8Array.from(name,c=>c.charCodeAt(0)), input=new DataView(bytes.buffer), n=bytes.length;
  const uint=x=>BigInt.asUintN(64,x), word=(view,pos)=>view.getBigUint64(pos,true);
  const fold=(a,b)=>{const p=a*b;return uint(p)^(p>>64n);};
  const keyed=(i,j)=>word(input,i)^word(rstSecret,j);
  let hash;
  if(n<=8){
    const rotate=(x,b)=>uint(x<<b)|(x>>(64n-b));
    hash=(BigInt(input.getUint32(0,true))<<32n)|BigInt(input.getUint32(n-4,true));
    hash^=word(rstSecret,8)^word(rstSecret,16);
    hash=uint((hash^rotate(hash,49n)^rotate(hash,24n))*0x9fb21c651e98df25n);
    hash=uint((hash^((hash>>35n)+BigInt(n)))*0x9fb21c651e98df25n);
    hash^=hash>>28n;
  }else{
    if(n<=16){
      const lo=keyed(0,24)^word(rstSecret,32), hi=keyed(n-8,40)^word(rstSecret,48);
      const swapped=new DataView(new ArrayBuffer(8));
      swapped.setBigUint64(0,lo);
      hash=BigInt(n)+word(swapped,0)+hi+fold(lo,hi);
    }else{
      hash=BigInt(n)*0x9e3779b185ebca87n;
      for(let i=0;i<Math.ceil(n/32);i++){
        const left=16*i,right=n-16*(i+1),offset=32*i;
        hash+=fold(keyed(left,offset),keyed(left+8,offset+8));
        hash+=fold(keyed(right,offset+16),keyed(right+8,offset+24));
      }
    }
    hash=uint(hash);
    hash=uint((hash^(hash>>37n))*0x165667919e3779f9n);
    hash^=hash>>32n;
  }
  return '{'+(hash&0x3fffffffffn).toString(16).padStart(10,'0')+'}';
}
function localizedGameString(strings,key) {
  const name=key?.trim().toLowerCase();
  if(!name)return '';
  const result=strings[name] ?? strings[rstKey(name)];
  return typeof result==='string'?result:'';
}
function binCalculationKey(name) {
  let h=2166136261;
  for(const c of name)h=Math.imul(h^c.charCodeAt(0),16777619);
  return '{'+(h>>>0).toString(16).padStart(8,'0')+'}';
}
function describeModeAugment(augment,mode,strings) {
  let template=localizedGameString(strings,augment.DescriptionTra);
  if(!template)return {description:'',descriptionNote:'当前版本的简体中文效果文本尚未取得。'};
  const slot=augment.AugmentNameId.match(/^GoH_PentakillAug_([QWER])$/)?.[1];
  const skill=slot?slot+'技能':'所选技能';
  for(let depth=0;depth<4 && template.includes('{{');depth++){
    template=template.replace(/\{\{(.*?)\}\}/g,(whole,key)=>key.trim().toLowerCase()==='spellname'?skill:
      localizedGameString(strings,key) || whole);
  }
  if(template.includes('{{'))return {description:'',descriptionNote:'当前版本的效果文本包含尚待核对的引用。'};
  const spell=mode[augment.RootSpell]?.mSpell || {},values=new Map();
  for(const row of spell.DataValues || []){
    if(row.values?.length && Number.isFinite(row.values[0]) && row.values.every(n=>n===row.values[0]))
      values.set(row.name.toLowerCase(),row.values[0]);
  }
  const calcs=new Map(Object.entries(spell.mSpellCalculations || {}).map(([k,v])=>[k.toLowerCase(),v]));
  const format=n=>String(Number(n.toFixed(5)));
  const scalar=part=>part?.__type==='NumberCalculationPart'?part.mNumber ?? 0:
    part?.__type==='NamedDataValueCalculationPart'?values.get(part.mDataValue.toLowerCase()):undefined;
  let unresolved=false;
  function number(name,factor,unit){
    if(values.has(name))return format(values.get(name)*factor)+unit;
    if(name==='questrequirement'){
      const stages=mode[augment.QuestData?.Quest]?.Milestones?.map(stage=>stage['{7fec0982}']);
      if(stages?.length && stages.every(Number.isInteger))return stages.join('/')+unit;
    }
    const calc=calcs.get(name) || calcs.get(binCalculationKey(name));
    const parts=calc?.mFormulaParts || [], multiplier=calc?.mMultiplier?scalar(calc.mMultiplier):1;
    if(!parts.length || !Number.isFinite(multiplier))return null;
    const scale=multiplier*factor*(calc.mDisplayAsPercent?100:1);
    const suffix=unit || (calc.mDisplayAsPercent?'%':'');
    if(parts.every(p=>Number.isFinite(scalar(p)))){
      const value=parts.reduce((sum,p)=>sum+scalar(p),0)*scale;
      if(!calc.mRangedMultiplier)return format(value)+suffix;
      const ranged=scalar(calc.mRangedMultiplier);
      if(!Number.isFinite(ranged))return null;
      const precision=Math.min(10,Math.max(0,calc.mPrecision ?? 0));
      return '（近战'+Number(value.toFixed(precision))+suffix+'、远程'+Number((value*ranged).toFixed(precision))+suffix+'）';
    }
    if(calc.mRangedMultiplier)return null;
    const terms=parts.map(p=>{
      if(Number.isFinite(scalar(p)))return format(scalar(p)*scale);
      if(p.__type==='ByCharLevelInterpolationCalculationPart' && Number.isFinite(p.mStartValue) && Number.isFinite(p.mEndValue))
        return format(p.mStartValue*scale)+'～'+format(p.mEndValue*scale)+'（随等级成长）';
      if(p.__type==='ByCharLevelBreakpointsCalculationPart' && p.mBreakpoints?.length===1){
        const base=p.mLevel1Value,step=p.mBreakpoints[0];
        if(Number.isFinite(base) && Number.isFinite(step.mAdditionalBonusAtThisLevel))
          return format(base*scale)+'（'+step.mLevel+'级起为'+format((base+step.mAdditionalBonusAtThisLevel)*scale)+'）';
      }
      if(!['StatByNamedDataValueCalculationPart','StatByCoefficientCalculationPart'].includes(p.__type))return null;
      const stat={0:'法术强度',1:'护甲',2:'攻击力',6:'魔法抗性',12:'生命值'}[p.mStat ?? 0];
      const coefficient=p.mCoefficient ?? values.get(p.mDataValue?.toLowerCase());
      if(!stat || ![0,2].includes(p.mStatFormula ?? 0) || !Number.isFinite(coefficient))return null;
      return format(coefficient*scale)+'×'+(p.mStatFormula===2?'额外':p.mStat===12?'最大':'')+stat;
    });
    if(terms.includes(null))return null;
    return (terms.length===1?terms[0]:'（'+terms.join('＋')+'）')+suffix;
  }
  const text=cleanGameText(template).replaceAll('【'+skill+'】技能',skill).replaceAll('【'+skill+'】',skill)
    .replaceAll('强化版技能获得'+skill,'强化后的'+skill+'获得').replaceAll(skill+'技能',skill)
    .replace(/@([^@]+)@(%?)/g,(_,token,unit)=>{
      const matched=token.match(/^(\w+)(?:\*(-?[\d.]+))?$/);
      const result=matched && number(matched[1].toLowerCase(),Number(matched[2] || 1),unit);
      if(result!=null)return result;
      unresolved=true;return '〔数值待核实〕';
    }).replace(/（随等级成长）%/g,'%（随等级成长）').replaceAll('1+〔数值待核实〕个飞弹','飞弹（数量待核实）');
  return {description:text,...(unresolved?{descriptionNote:'部分数值依赖局内状态，或尚未解析。'}:{})};
}
function buildModeCatalog(sample,sources,mode,registry,strings) {
  const rarity={kSilver:'silver',kGold:'gold',kPrismatic:'prismatic'};
  const entries=new Map(registry.map(row=>[row.id,row])),byId={};
  const assets='https://raw.communitydragon.org/'+sample.patch+'/plugins/rcp-be-lol-game-data/global/default/';
  const sampled=new Map(sample.augments.map(a=>[String(a.id),a]));
  for(const augment of Object.values(mode)){
    if(augment?.__type!=='AugmentData')continue;
    const id=String(augment.AugmentPlatformId), row=entries.get(augment.AugmentPlatformId);
    if(!row || row.augmentNameId!==augment.AugmentNameId || !row.nameTRA?.trim())continue;
    const name=row.nameTRA.trim(), localized=localizedGameString(strings,augment.NameTra);
    const stat=sampled.get(id);
    if((localized && localized.trim()!==name) || (stat && (stat.name!==name || stat.rarity!==rarity[row.rarity])))continue;
    if(byId[id])throw Error('模式强化 ID 重复');
    const path=row.augmentSmallIconPath?.match(/^\/lol-game-data\/assets\/(assets\/[a-z\d_./-]+\.png)$/i)?.[1];
    byId[id]={name,rarity:rarity[row.rarity] || 'unknown',referenceOnly:!stat,
      icon:path && !path.includes('..')?assets+path.toLowerCase():'',
      ...describeModeAugment(augment,mode,strings)};
  }
  if(!Object.keys(byId).length)throw Error('强化模式资料为空');
  return {patch:sample.patch,sampleSeq:sample.seq,fetchedAt:new Date().toISOString(),locale:'zh_CN',sources,byId,
    coverage:{displayed:Object.keys(byId).length,sampled:[...sampled.keys()].filter(id=>byId[id]).length}};
}
async function downloadAugmentCatalog(sample) {
  const base='https://raw.communitydragon.org/'+sample.patch+'/';
  const sources={kiwi:base+'game/maps/modespecificdata/kiwi.bin.json',
    registry:base+'plugins/rcp-be-lol-game-data/global/zh_cn/v1/cherry-augments.json',
    strings:base+'game/zh_cn/data/menu/en_us/lol.stringtable.json'};
  const previous=augmentBook, urls=Object.values(sources), revisions={};
  if(previous.patch===sample.patch && previous.textAvailable &&
    urls.every(url=>previous.revisions?.[url]) && sample.augments.every(a=>currentAugmentDefinition(a))){
    try {
      const unchanged=await Promise.all(urls.map(async url=>{
        const response=await fetch(url,{method:'HEAD',cache:'no-cache',signal:AbortSignal.timeout(12000)});
        return response.ok && catalogRevision(response)===previous.revisions[url];
      }));
      if(unchanged.every(Boolean)){
        if(previous.sampleSeq===sample.seq)return previous;
        const sampled=new Set(sample.augments.map(a=>String(a.id)));
        const byId=Object.fromEntries(Object.entries(previous.byId).map(([id,a])=>[id,{...a,referenceOnly:!sampled.has(id)}]));
        return {...previous,byId,sampleSeq:sample.seq,coverage:{displayed:Object.keys(byId).length,sampled:sampled.size}};
      }
    } catch {}
  }
  const [mode,registry,strings]=await Promise.all([catalogJSON(sources.kiwi,revisions),catalogJSON(sources.registry,revisions),
    catalogJSON(sources.strings,revisions).catch(()=>null)]);
  const result=buildModeCatalog(sample,sources,mode,registry,strings?.entries || {});
  result.revisions=revisions;
  result.textAvailable=Boolean(strings?.entries && Object.keys(strings.entries).length);
  return result;
}
async function refreshGameCatalogs(manual=false) {
  const sample=stats, patch=sample?.patch;
  if(!/^\d+\.\d+$/.test(patch))return;
  selectGameCatalogPatch(patch);
  if(activeCatalogRequest?.patch===patch){
    const pending=activeCatalogRequest;
    if(pending.seq===sample.seq && (!manual || pending.manual))return pending.promise;
    await pending.promise;
    if(stats?.patch!==patch || stats.seq!==sample.seq)return;
    return refreshGameCatalogs(manual);
  }
  if(!manual && Date.now()<retryCatalogAfter)return;
  const newBatch=augmentBook.sampleSeq<sample.seq;
  const jobs=[];
  if(manual || newBatch || !championBook.version?.startsWith(patch+'.') || !sample.heroes.every(h=>championBook.byId?.[h.id]))
    jobs.push(['heroes',downloadHeroCatalog(sample,manual || newBatch)]);
  if(manual || newBatch || augmentBook.patch!==patch || augmentBook.textAvailable===false ||
    (augmentBook.coverage?.sampled ?? 0)<sample.augments.length)
    jobs.push(['augments',downloadAugmentCatalog(sample)]);
  if(!jobs.length)return;
  const request={patch,seq:sample.seq,manual};
  activeCatalogRequest=request;
  request.promise=Promise.allSettled(jobs.map(async ([kind,download])=>{
    const book=await download;
    if(stats?.patch!==patch || stats.seq!==sample.seq || activeCatalogRequest!==request)return;
    if(kind==='heroes'){
      if(book===championBook)return;
      championBook=book;
    }else{
      if(book===augmentBook)return;
      if(!book.textAvailable){
        retryCatalogAfter=Date.now()+60000;
        if(augmentBook.patch===patch && augmentBook.textAvailable!==false)return;
      }
      augmentBook=book;
    }
    storeGameCatalog(kind,book);
    renderList();
    if(typeof sheet!=='undefined' && sheet)renderSheet();
  })).then(results=>{
    if(activeCatalogRequest!==request)return;
    if(results.some(r=>r.status==='rejected'))retryCatalogAfter=Date.now()+60000;
    activeCatalogRequest=null;
  });
  return request.promise;
}
function championMini(hero) {
  const c=championBook.byId?.[hero.id];
  if(!c) return '';
  return '<section class="champion-facts"><div class="roles">'+c.roles.map(r=>'<span>'+esc(r)+'</span>').join('')+'</div>'+
    '<div class="skill-strip">'+c.skills.map(s=>'<button aria-label="'+esc(s.slot+' '+s.name)+'" title="'+esc(s.name)+'" data-champ-info="'+esc(hero.id)+'" data-slot="'+esc(s.slot)+'">'+skillIcon(s)+'<small>'+esc(s.slot)+'</small></button>').join('')+'</div>'+
    '<button class="slink" data-champ-info="'+esc(hero.id)+'">技能说明与基础属性</button></section>';
}
function championFacts(c,heroId=c.id) {
  const values=panelStats.filter(([key])=>c.stats[key]!=null).map(([key,label,growth])=>{
    const inc=growth && c.stats[growth];
    return '<div><dt>'+esc(label)+'</dt><dd>'+esc(c.stats[key])+(inc?' <small>+'+esc(inc)+(key==='attackspeed'?'%':'')+' / 级</small>':'')+'</dd></div>';
  }).join('');
  const skills=c.skills.map(s=>'<section id="skill-'+esc(s.slot)+'" class="ability"><div>'+skillIcon(s)+'</div><div><h3>'+esc(s.slot)+' · '+esc(s.name)+'</h3><p>'+esc(s.description)+'</p>'+skillTraitsLine(heroId,s.slot)+
    (heroId?'<a class="slink" data-skills-for="'+esc(heroId)+'" data-slot="'+s.slot+'" href="'+esc(targetListUrl(heroId,s.slot))+'">查看该技能的强化</a>':'')+'</div></section>').join('');
  return '<p class="context">'+esc(c.title)+' · '+esc(c.roles.join(' / '))+(c.resourceType?' · '+esc(c.resourceType):'')+'</p>'+skills+
    '<h3>基础属性</h3><dl class="attrs">'+values+'</dl><p class="context">'+external(championBook.sourceUrl,'Riot Data Dragon '+championBook.version)+' · 基础面板，模式加成另计。</p>'+
    (typeof augmentSkillBook!=='undefined' && augmentSkillBook.patch!==stats.patch?'<p class="detail-note">本版英雄专属技能强化关联尚待核实。</p>':'');
}
function openChampion(id,slot) {
  const c=championBook.byId?.[id]; if(!c)return;
  showDialog(c.name+' · 英雄资料',championFacts(c,id));
  if(slot) document.getElementById('skill-'+slot)?.scrollIntoView({block:'nearest'});
}
function scopedHero() {return stats.heroes.find(h=>h.id===ui.scopeHero);}
function augmentedRows() {
  const hero=scopedHero();
  if(!hero) {
    if(ui.scopeHero)return [];
    const additional=Object.entries(augmentBook.byId || {}).filter(([id])=>!augmentMap.has(id))
      .map(([id,a])=>({id,name:a.name,rarity:a.rarity,games:null,holdRate:null,referenceOnly:true}));
    return augmentBook.patch===stats.patch || augmentBook.version===stats.patch ? stats.augments.concat(additional) : stats.augments;
  }
  const held=Object.entries(hero.augmentCounts).filter(([,n])=>n>0).map(([id,games])=>({...augmentMap.get(id),id,games,holdRate:100*games/hero.games}));
  if(profile?.section==='targets'){
    for(const id of skillListExtraIds(hero)){
      const a=augmentMap.get(id) || augmentBook.byId?.[id];
      if(a && !hero.augmentCounts[id])held.push({...a,id,games:null,holdRate:null,noHeroSample:true});
    }
  }
  return held;
}
function itemRows() {
  const e=stats.equipment;
  if(!e)return [];
  if(!ui.scopeHero) return e.catalog;
  const held=e.byHero[ui.scopeHero];if(!held)return [];
  return held.rows.map(([id,games,wins])=>({...equipmentById.get(String(id)),id:String(id),games,wins,
    holdRate:held.denominator?games*100/held.denominator:null,winRate:wins==null||!games?null:wins*100/games}));
}
function holderItemRows(id) {
  const out=[];
  for(const hero of stats.heroes){
    const data=stats.equipment.byHero[hero.id];
    const held=data?.rows.find(([key])=>String(key)===id);
    if(held && held[1]>0)out.push({hero,games:held[1],rate:data.denominator?100*held[1]/data.denominator:null});
  }
  return out.sort((a,b)=>(b.rate || 0)-(a.rate || 0));
}
function heroChooser() {
  const options=stats.heroes.slice().sort((a,b)=>a.name.localeCompare(b.name,'zh-CN')).map(h=>
    '<option value="'+esc(h.id)+'" '+(ui.scopeHero===h.id?'selected':'')+'>'+esc(h.name)+'</option>').join('');
  return '<label class="select-label">英雄 <select id="scope-select"><option value="">全部英雄</option>'+options+'</select></label>';
}
function sortShortcuts() {
  const isItem=ui.tab==='items', isHero=ui.tab==='heroes', isAug=ui.tab==='augments';
  const keys=isHero ? [['winRate','胜率榜'],[ggHeroesActive()||ui.denominator==='players'?'pickRate':'appearancesPer100Matches','出场率榜'],['games','出场人次榜']].filter(([k])=>k!=='games'||!ggHeroesActive()||gg.catalog.heroes.some(h=>h.games!=null)) :
    isItem?[['holdRate','持有率榜'],['winRate','胜率榜'],['games','持有人次榜']]:isAug?augmentRanks():[['itemGames','装备样本榜'],['itemWin','装备胜率榜']];
  const buttons=keys.map(([k,name])=>'<button type="button" data-rank="'+k+'" aria-pressed="'+(ui.sort===k)+'" class="'+(ui.sort===k?'on':'')+'">'+name+'</button>').join('');
  const orders=[[-1,'从高到低'],[1,'从低到高']].map(([d,name])=>'<button type="button" data-direction="'+d+'" aria-pressed="'+(ui.direction===d)+'" class="'+(ui.direction===d?'on':'')+'">'+name+'</button>').join('');
  return '<div class="rank-controls" role="group" aria-label="榜单指标">'+buttons+'</div><div class="order-controls" role="group" aria-label="排序方向">'+orders+'</div>';
}
function sampleFilter(){
  return '<label class="select-label">样本 <select id="min-games">'+[[0,'不限'],[100,'至少 100'],[1000,'至少 1,000'],[10000,'至少 10,000']].map(([v,n])=>
    '<option value="'+v+'" '+(ui.minGames===v?'selected':'')+'>'+n+'</option>').join('')+'</select></label>';
}
function itemFilters() {
  const options=[...new Set((stats.equipment?.catalog||[]).map(x=>x.kind))].map(kind=>
    '<option value="'+esc(kind)+'" '+(ui.itemKind===kind?'selected':'')+'>'+esc(itemKinds[kind] || kind)+'</option>').join('');
  return '<label class="select-label">类别 <select id="kind-select"><option value="">全部装备</option>'+options+'</select></label>'+sampleFilter();
}
function entryButton(type,id,title,icon='') {
  return '<button class="entry-link" data-entry="'+type+'" data-entry-id="'+esc(id)+'">'+icon+'<span>'+esc(title)+'</span></button>';
}
function relatedRow(type,r,icon,left,right) {
  return '<div class="statrow"><div>'+entryButton(type,r.id,r.name,icon)+'<small>'+esc(left)+'</small></div><em>'+esc(right)+'</em></div>';
}
function heroAugmentsCard(h) {
  const rows=Object.entries(h.augmentCounts).filter(([,n])=>n>0).sort((a,b)=>b[1]-a[1]);
  const top=rows.slice(0,4).map(([id,n])=>{
    const a=augmentMap.get(id);
    const skill=skillSummary(id,h.id);
    return a?relatedRow('augments',a,augmentIcon(a),(skill?skill+' · ':'')+count(n)+' 持有人次',pct(n/h.games*100)):'';
  }).join('');
  return '<h3>该英雄持有过的海克斯</h3><p class="detail-note">AramHex '+esc(stats.patch)+' · 本批 '+count(h.games)+' 次出场，结算记录中出现 '+rows.length+' 种强化。公开数据未给出该英雄完整的三选一候选池。</p>'+top+
    '<div class="related-actions"><button data-scope="augments" data-for="'+esc(h.id)+'">查看全部 '+rows.length+' 种海克斯</button>'+
    '<button data-skills-for="'+esc(h.id)+'">按技能查看强化</button><button data-scope="items" data-for="'+esc(h.id)+'">查看全部持有装备</button>'+
    '<button data-action="gear">装备搭配</button></div>';
}
function qualityDescription(a) {
  const entry=currentAugmentDefinition(a), desc=entry?.description;
  return subjectNotes('强化符文',a.name)+'<p class="effect">'+esc(desc || '当前资料源尚未提供效果说明。')+'</p>'+
    (entry?.descriptionNote?'<p class="detail-note">'+esc(entry.descriptionNote)+'</p>':'')+
    (a.referenceOnly?'<p class="detail-note">仅玩法资料 · 当前国服统计未收录。'+esc(entry?.sampleNote || '')+'</p>':'')+
    (desc?'<p class="detail-note">强化资料版本 '+esc(augmentBook.patch)+' · '+external(augmentBook.sources?.kiwi,'CommunityDragon 模式文件')+'。</p>':'');
}
function itemDetail(r) {
  const e=stats.equipment, hero=scopedHero();
  const category=itemKinds[r.kind]||'物品';
  const attributes=(r.attributes || []).map(t=>'<li>'+esc(t)+'</li>').join('');
  const h= hero?e.byHero[hero.id]:null;
  const den=hero?h?.denominator:e.denominator;
  const scope=hero?hero.name:'全体英雄';
  const combos=(ids,label)=>{
    if(!Array.isArray(ids)||!ids.length)return '';
    const links=ids.map(id=>{const item=equipmentById.get(String(id));return item?entryButton('items',item.id,item.name,itemIcon(item)):'';}).filter(Boolean);
    return links.length?'<h3>'+label+'</h3><div class="recipe">'+links.join('')+'</div>':'';
  };
  const holders=holderItemRows(r.id);
  return '<span class="eyebrow">装备详情</span><div class="feature">'+itemIcon(r)+'<div><h2>'+esc(r.name)+'</h2><small>'+esc(category)+' · ID '+esc(r.id)+'</small></div></div>'+
    subjectNotes('装备',r.name)+mini('结算持有率',pct(r.holdRate),'持有时胜率',pct(r.winRate))+
    '<p class="detail-note">'+esc(scope)+' · '+count(r.games)+' 持有人次 / '+count(den)+' 装备样本人次'+(r.wins!=null?' · '+count(r.wins)+' 胜':'')+'<br>AramHex · '+metaLine(e)+'</p>'+
    (r.kind==='augmentReward'?'<p class="detail-note">强化关联物品仅展示持有统计。</p>':'')+
    '<h3>属性与效果'+(r.gold!=null?' · '+count(r.gold)+' 金币':'')+'</h3>'+
    (attributes?'<ul class="item-attrs">'+attributes+'</ul>':'')+
    '<p class="effect">'+esc(r.effects || r.description || '当前资料源尚未提供物品说明。')+'</p>'+
    '<p class="detail-note">'+esc((r.types || []).join(' · '))+'<br>装备资料版本 '+esc(e.catalogVersion || e.communityPatch || '未标注')+'</p>'+
    combos(r.from,'合成材料')+combos(r.into,'可合成的装备')+
    '<h3>常持有这件装备的英雄</h3>'+collapse(holders.map(x=>relatedRow('heroes',x.hero,assetFor(x.hero),count(x.games)+' 持有人次',pct(x.rate))),4,'展开全部英雄');
}
function openLibraryEntry(type,id) {
  if(type==='heroes'){openProfile(id);return;}
  if(profile){openProfile(profile.id,type,id);return;}
  if(ui.tab==='heroes' || ui.tab==='builds'){openProfile(ui.id,type,id);return;}
  changeTab(type,id);
  const row=sourceRows().find(r=>r.id===id);
  if(row){ui.query=row.name;$('search').value=row.name;ui.id=id;ui.page=0;renderList();}
  if(matchMedia('(max-width:760px)').matches)$('detail').scrollIntoView({block:'start'});
}
function openScoped(tab,id) {
  openProfile(id,tab);
}
