'use strict';
let championBook = {}, augmentBook = {}, itemIcons = {}, equipmentById = new Map();
let remoteAugmentIcons = {}, activeCatalogRequest = '';
const itemKinds = {complete:'成装',boots:'鞋子',component:'组件',consumable:'消耗品',starter:'出门装',special:'特殊物品',augmentReward:'强化关联物品',other:'其他'};
const panelStats = [
  ['hp','生命值','hpperlevel'],['mp','技能资源','mpperlevel'],['attackdamage','攻击力','attackdamageperlevel'],
  ['attackspeed','攻击速度','attackspeedperlevel'],['armor','护甲','armorperlevel'],['spellblock','魔抗','spellblockperlevel'],
  ['hpregen','生命回复','hpregenperlevel'],['mpregen','资源回复','mpregenperlevel'],['crit','暴击率','critperlevel'],
  ['attackrange','攻击距离'],['movespeed','移动速度']
];
function atlasTile(path,index,cols,rows,style='') {
  if(!Number.isInteger(index) || index<0 || !cols || !rows) return '';
  const x=100*(index%cols)/Math.max(1,cols-1), y=100*Math.floor(index/cols)/Math.max(1,rows-1);
  return '<span aria-hidden="true" class="portrait '+style+'" style="background-image:url('+artPath(path)+');background-size:'+(cols*100)+'% '+(rows*100)+'%;background-position:'+x+'% '+y+'%"></span>';
}
function imageFallback(url,letter) {
  let safe=false;
  try {safe=new URL(url).protocol==='https:';} catch {}
  return safe ? '<img class="portrait" loading="lazy" referrerpolicy="no-referrer" src="'+esc(url)+'" alt="">' :
    '<span class="portrait" aria-hidden="true">'+esc(letter)+'</span>';
}
function itemIcon(item) {
  return (stats.equipment?.catalogVersion===itemIcons.version && atlasTile('/items-atlas.webp',itemIcons.byId?.[item.id],itemIcons.cols,itemIcons.rows)) ||
    imageFallback(item.icon,item.name.slice(0,1));
}
function lookupAugmentIcon(a) {
  if(remoteAugmentIcons[a.id])return imageFallback(remoteAugmentIcons[a.id],a.name.slice(0,1));
  const entry=augmentBook.byId?.[a.id], grid=augmentBook.atlas;
  return grid && entry ? atlasTile('/augment-atlas.webp',entry.iconIndex,grid.columns,grid.rows,'augment-art') : '';
}
function definition(a) {
  const entry=augmentBook.byId?.[a.id];
  return entry?.name===a.name ? entry.description : '';
}
function skillIcon(skill) {
  if(skill.url)return imageFallback(skill.url,skill.slot);
  const s=championBook.sprite;
  return s?atlasTile('/champion-skills.webp',skill.icon,s.cols,s.rows,'skill-icon'):'';
}
// Versioned game files cover newly released heroes and sampled augment icons before the local atlases are rebuilt.
async function refreshGameCatalogs() {
  const patch=stats?.patch;
  if(!/^\d+\.\d+$/.test(patch) || activeCatalogRequest===patch)return;
  const needHeroes=!championBook.version?.startsWith(patch+'.'), needIcons=augmentBook.patch!==patch;
  if(!needHeroes && !needIcons)return;
  activeCatalogRequest=patch;
  const version=stats.equipment?.catalogVersion || patch+'.1';
  const cdn='https://ddragon.leagueoflegends.com/cdn/'+version;
  const assetBase='https://raw.communitydragon.org/'+patch+'/plugins/rcp-be-lol-game-data/global/';
  const jobs=[];
  if(needHeroes)jobs.push((async()=>{
    const source=await read(cdn+'/data/zh_CN/championFull.json');
    if(source.version!==version || !source.data || stats.patch!==patch)throw Error('英雄资料版本不一致');
    const byId={}, roles={Assassin:'刺客',Fighter:'战士',Mage:'法师',Marksman:'射手',Support:'辅助',Tank:'坦克'};
    for(const c of Object.values(source.data)) {
      const skills=[c.passive,...c.spells].map((s,index)=>({
        slot:['P','Q','W','E','R'][index], name:s.name,
        description:s.description.replace(/<(?:br|hr)\s*\/?>/gi,'\n').replace(/<[^>]+>/g,''),
        url:cdn+'/img/'+(index?'spell':'passive')+'/'+encodeURIComponent(s.image.full)
      }));
      if(skills.length!==5 || skills.some(s=>!s.name || !s.description))throw Error('技能资料不完整');
      byId[c.key]={name:c.title,title:c.name,stats:c.stats,resourceType:c.partype,roles:c.tags.map(t=>roles[t] || t),skills};
    }
    if(!stats.heroes.every(h=>byId[h.id]))throw Error('英雄资料不完整');
    championBook={version,byId};
  })());
  if(needIcons)jobs.push((async()=>{
    const registry=await read(assetBase+'zh_cn/v1/cherry-augments.json');
    if(!Array.isArray(registry) || stats.patch!==patch)throw Error('强化图标版本不一致');
    const icons={};
    for(const record of registry) {
      if(record.nameTRA!==augmentMap.get(String(record.id))?.name)continue;
      const path=record.augmentSmallIconPath?.match(/^\/lol-game-data\/assets\/(assets\/[a-z\d_./-]+\.png)$/i)?.[1];
      if(path && !path.includes('..'))icons[record.id]=assetBase+'default/'+path.toLowerCase();
    }
    remoteAugmentIcons=icons;
  })());
  const results=await Promise.allSettled(jobs);
  if(stats.patch!==patch)return;
  if(results.some(r=>r.status==='rejected'))activeCatalogRequest='';
  if(results.some(r=>r.status==='fulfilled'))renderList();
}
function championMini(hero) {
  const c=championBook.byId?.[hero.id];
  if(!c) return '';
  return '<section class="champion-facts"><div class="roles">'+c.roles.map(r=>'<span>'+esc(r)+'</span>').join('')+'</div>'+
    '<div class="skill-strip">'+c.skills.map(s=>'<button aria-label="'+esc(s.slot+' '+s.name)+'" title="'+esc(s.name)+'" data-champ-info="'+esc(hero.id)+'" data-slot="'+esc(s.slot)+'">'+skillIcon(s)+'<small>'+esc(s.slot)+'</small></button>').join('')+'</div>'+
    '<button class="slink" data-champ-info="'+esc(hero.id)+'">技能说明与基础属性</button></section>';
}
function championFacts(c,heroId=c.id) {
  const values=panelStats.filter(([key])=>c.stats[key]!=null).map(([key,label,growth])=>{
    const inc=growth && c.stats[growth];
    return '<div><dt>'+esc(label)+'</dt><dd>'+esc(c.stats[key])+(inc?' <small>+'+esc(inc)+(key==='attackspeed'?'%':'')+' / 级</small>':'')+'</dd></div>';
  }).join('');
  const skills=c.skills.map(s=>'<section id="skill-'+esc(s.slot)+'" class="ability"><div>'+skillIcon(s)+'</div><div><h3>'+esc(s.slot)+' · '+esc(s.name)+'</h3><p>'+esc(s.description)+'</p>'+skillTraitsLine(heroId,s.slot)+
    (heroId?'<a class="slink" data-skills-for="'+esc(heroId)+'" data-slot="'+s.slot+'" href="'+esc(targetListUrl(heroId,s.slot))+'">查看该技能的强化</a>':'')+'</div></section>').join('');
  return '<p class="context">'+esc(c.title)+' · '+esc(c.roles.join(' / '))+(c.resourceType?' · '+esc(c.resourceType):'')+'</p>'+skills+
    '<h3>基础属性</h3><dl class="attrs">'+values+'</dl><p class="context">Riot Data Dragon '+esc(championBook.version)+' · 基础面板，模式加成另计。</p>';
}
function openChampion(id,slot) {
  const c=championBook.byId?.[id]; if(!c)return;
  showDialog(c.name+' · 英雄资料',championFacts(c,id));
  if(slot) document.getElementById('skill-'+slot)?.scrollIntoView({block:'nearest'});
}
function scopedHero() {return stats.heroes.find(h=>h.id===ui.scopeHero);}
function augmentedRows() {
  const hero=scopedHero();
  if(!hero) {
    if(ui.scopeHero)return [];
    const additional=Object.entries(augmentBook.byId || {}).filter(([id])=>!augmentMap.has(id))
      .map(([id,a])=>({id,name:a.name,rarity:a.rarity,games:null,holdRate:null,referenceOnly:true}));
    return augmentBook.patch===stats.patch || augmentBook.version===stats.patch ? stats.augments.concat(additional) : stats.augments;
  }
  const held=Object.entries(hero.augmentCounts).filter(([,n])=>n>0).map(([id,games])=>({...augmentMap.get(id),id,games,holdRate:100*games/hero.games}));
  if(profile?.section==='targets'){
    for(const id of skillListExtraIds(hero)){
      const a=augmentMap.get(id) || augmentBook.byId?.[id];
      if(a && !hero.augmentCounts[id])held.push({...a,id,games:null,holdRate:null,noHeroSample:true});
    }
  }
  return held;
}
function itemRows() {
  const e=stats.equipment;
  if(!e)return [];
  if(!ui.scopeHero) return e.catalog;
  const held=e.byHero[ui.scopeHero];if(!held)return [];
  return held.rows.map(([id,games,wins])=>({...equipmentById.get(String(id)),id:String(id),games,wins,
    holdRate:held.denominator?games*100/held.denominator:null,winRate:wins==null||!games?null:wins*100/games}));
}
function holderItemRows(id) {
  const out=[];
  for(const hero of stats.heroes){
    const data=stats.equipment.byHero[hero.id];
    const held=data?.rows.find(([key])=>String(key)===id);
    if(held && held[1]>0)out.push({hero,games:held[1],rate:data.denominator?100*held[1]/data.denominator:null});
  }
  return out.sort((a,b)=>(b.rate || 0)-(a.rate || 0));
}
function heroChooser() {
  const options=stats.heroes.slice().sort((a,b)=>a.name.localeCompare(b.name,'zh-CN')).map(h=>
    '<option value="'+esc(h.id)+'" '+(ui.scopeHero===h.id?'selected':'')+'>'+esc(h.name)+'</option>').join('');
  return '<label class="select-label">英雄 <select id="scope-select"><option value="">全部英雄</option>'+options+'</select></label>';
}
function sortShortcuts() {
  const isItem=ui.tab==='items', isHero=ui.tab==='heroes', isAug=ui.tab==='augments';
  const keys=isHero ? [['winRate','胜率榜'],[ggHeroesActive()||ui.denominator==='players'?'pickRate':'appearancesPer100Matches','出场率榜'],['games','出场人次榜']].filter(([k])=>k!=='games'||!ggHeroesActive()||gg.catalog.heroes.some(h=>h.games!=null)) :
    isItem?[['holdRate','持有率榜'],['winRate','胜率榜'],['games','持有人次榜']]:isAug?augmentRanks():[['itemGames','装备样本榜'],['itemWin','装备胜率榜']];
  const buttons=keys.map(([k,name])=>'<button type="button" data-rank="'+k+'" aria-pressed="'+(ui.sort===k)+'" class="'+(ui.sort===k?'on':'')+'">'+name+'</button>').join('');
  const orders=[[-1,'从高到低'],[1,'从低到高']].map(([d,name])=>'<button type="button" data-direction="'+d+'" aria-pressed="'+(ui.direction===d)+'" class="'+(ui.direction===d?'on':'')+'">'+name+'</button>').join('');
  return '<div class="rank-controls" role="group" aria-label="榜单指标">'+buttons+'</div><div class="order-controls" role="group" aria-label="排序方向">'+orders+'</div>';
}
function sampleFilter(){
  return '<label class="select-label">样本 <select id="min-games">'+[[0,'不限'],[100,'至少 100'],[1000,'至少 1,000'],[10000,'至少 10,000']].map(([v,n])=>
    '<option value="'+v+'" '+(ui.minGames===v?'selected':'')+'>'+n+'</option>').join('')+'</select></label>';
}
function itemFilters() {
  const options=[...new Set((stats.equipment?.catalog||[]).map(x=>x.kind))].map(kind=>
    '<option value="'+esc(kind)+'" '+(ui.itemKind===kind?'selected':'')+'>'+esc(itemKinds[kind] || kind)+'</option>').join('');
  return '<label class="select-label">类别 <select id="kind-select"><option value="">全部装备</option>'+options+'</select></label>'+sampleFilter();
}
function entryButton(type,id,title,icon='') {
  return '<button class="entry-link" data-entry="'+type+'" data-entry-id="'+esc(id)+'">'+icon+'<span>'+esc(title)+'</span></button>';
}
function relatedRow(type,r,icon,left,right) {
  return '<div class="statrow"><div>'+entryButton(type,r.id,r.name,icon)+'<small>'+esc(left)+'</small></div><em>'+esc(right)+'</em></div>';
}
function heroAugmentsCard(h) {
  const rows=Object.entries(h.augmentCounts).filter(([,n])=>n>0).sort((a,b)=>b[1]-a[1]);
  const top=rows.slice(0,4).map(([id,n])=>{
    const a=augmentMap.get(id);
    const skill=skillSummary(id,h.id);
    return a?relatedRow('augments',a,augmentIcon(a),(skill?skill+' · ':'')+count(n)+' 持有人次',pct(n/h.games*100)):'';
  }).join('');
  return '<h3>该英雄持有过的海克斯</h3><p class="detail-note">AramHex '+esc(stats.patch)+' · 本批 '+count(h.games)+' 次出场，结算记录中出现 '+rows.length+' 种强化。公开数据未给出该英雄完整的三选一候选池。</p>'+top+
    '<div class="related-actions"><button data-scope="augments" data-for="'+esc(h.id)+'">查看全部 '+rows.length+' 种海克斯</button>'+
    '<button data-skills-for="'+esc(h.id)+'">按技能查看强化</button><button data-scope="items" data-for="'+esc(h.id)+'">查看全部持有装备</button>'+
    '<button data-action="gear">装备搭配</button></div>';
}
function qualityDescription(a) {
  const entry=augmentBook.byId?.[a.id], desc=definition(a);
  return '<p class="effect">'+esc(desc || '当前资料源尚未提供效果说明。')+'</p>'+
    (entry?.descriptionNote?'<p class="detail-note">'+esc(entry.descriptionNote)+'</p>':'')+
    (a.referenceOnly?'<p class="detail-note">仅玩法资料 · 当前国服统计未收录。'+esc(entry?.sampleNote || '')+'</p>':'')+
    (desc?'<p class="detail-note">'+(augmentBook.patch!==stats.patch?'上一版效果，当前版本待核对。':'')+'强化资料版本 '+esc(augmentBook.patch)+'。</p>':'');
}
function itemDetail(r) {
  const e=stats.equipment, hero=scopedHero();
  const category=itemKinds[r.kind]||'物品';
  const attributes=(r.attributes || []).map(t=>'<li>'+esc(t)+'</li>').join('');
  const h= hero?e.byHero[hero.id]:null;
  const den=hero?h?.denominator:e.denominator;
  const scope=hero?hero.name:'全体英雄';
  const combos=(ids,label)=>{
    if(!Array.isArray(ids)||!ids.length)return '';
    const links=ids.map(id=>{const item=equipmentById.get(String(id));return item?entryButton('items',item.id,item.name,itemIcon(item)):'';}).filter(Boolean);
    return links.length?'<h3>'+label+'</h3><div class="recipe">'+links.join('')+'</div>':'';
  };
  const holders=holderItemRows(r.id);
  return '<span class="eyebrow">装备详情</span><div class="feature">'+itemIcon(r)+'<div><h2>'+esc(r.name)+'</h2><small>'+esc(category)+' · ID '+esc(r.id)+'</small></div></div>'+
    mini('结算持有率',pct(r.holdRate),'持有时胜率',pct(r.winRate))+
    '<p class="detail-note">'+esc(scope)+' · '+count(r.games)+' 持有人次 / '+count(den)+' 装备样本人次'+(r.wins!=null?' · '+count(r.wins)+' 胜':'')+'<br>AramHex · '+metaLine(e)+'</p>'+
    (r.kind==='augmentReward'?'<p class="detail-note">强化关联物品仅展示持有统计。</p>':'')+
    '<h3>属性与效果'+(r.gold!=null?' · '+count(r.gold)+' 金币':'')+'</h3>'+
    (attributes?'<ul class="item-attrs">'+attributes+'</ul>':'')+
    '<p class="effect">'+esc(r.effects || r.description || '当前资料源尚未提供物品说明。')+'</p>'+
    '<p class="detail-note">'+esc((r.types || []).join(' · '))+'<br>装备资料版本 '+esc(e.catalogVersion || e.communityPatch || '未标注')+'</p>'+
    combos(r.from,'合成材料')+combos(r.into,'可合成的装备')+
    '<h3>常持有这件装备的英雄</h3>'+collapse(holders.map(x=>relatedRow('heroes',x.hero,assetFor(x.hero),count(x.games)+' 持有人次',pct(x.rate))),4,'展开全部英雄');
}
function openLibraryEntry(type,id) {
  if(type==='heroes'){openProfile(id);return;}
  if(profile){openProfile(profile.id,type,id);return;}
  if(ui.tab==='heroes' || ui.tab==='builds'){openProfile(ui.id,type,id);return;}
  changeTab(type,id);
  const row=sourceRows().find(r=>r.id===id);
  if(row){ui.query=row.name;$('search').value=row.name;ui.id=id;ui.page=0;renderList();}
  if(matchMedia('(max-width:760px)').matches)$('detail').scrollIntoView({block:'start'});
}
function openScoped(tab,id) {
  openProfile(id,tab);
}
