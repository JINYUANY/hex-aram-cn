'use strict';
const $ = id => document.getElementById(id);
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const count = value => value == null ? '—' : Number(value).toLocaleString('zh-CN');
const pct = value => value == null ? '—' : (value > 0 && value < 0.01 ? '<0.01%' : value.toFixed(2) + '%');
const dateFmt = new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'});
const date = value => value ? dateFmt.format(new Date(value)) : '上游未提供';
const rarityNames = {silver:'白银',gold:'黄金',prismatic:'棱彩',unknown:'其他'};
const PAGE_SIZE = 20;
let stats, official, portraits = {}, augmentMap = new Map(), busy = false;
let displayedRows=[];
const health = {official:{},stats:{}};
const ui = {tab:'heroes', query:'', rarity:'all', skillFilter:'',skillBasis:'',denominator:'players', page:0, sort:'winRate', direction:-1, id:null,scopeHero:'',itemKind:'',minGames:0};
function assetFor(hero) {
  const n = portraits.byId?.[hero.id];
  if (n == null) return imageFallback(hero.icon,hero.name.slice(0,1));
  const x = n % portraits.cols, y = Math.floor(n / portraits.cols);
  return '<span class="portrait" aria-hidden="true" style="background-image:url('+artPath('/portraits.webp')+');background-size:' +
    (portraits.cols*100) + '% ' + (portraits.rows*100) + '%;background-position:' + (x/(portraits.cols-1)*100) + '% ' + (y/(portraits.rows-1)*100) + '%"></span>';
}
function augmentIcon(a) {
  return lookupAugmentIcon(a) || '<span aria-hidden="true" class="symbol ' + esc(a.rarity) + '">◇</span>';
}
function label(a) {
  return '<span class="rarity ' + esc(a.rarity) + '">' + esc(rarityNames[a.rarity] || '其他') + '</span>';
}
function external(url, title) {
  try { const u = new URL(url); if (u.protocol !== 'https:') return esc(title); }
  catch { return esc(title); }
  return '<a href="' + esc(url) + '" target="_blank" rel="noopener noreferrer">' + esc(title) + '</a>';
}
function setStats(value) {
  stats = value;
  observedHeroCounts=indexAugmentCoverage(stats.heroes);
  equipmentById = new Map((stats.equipment?.catalog || []).map(i=>[String(i.id),i]));
  augmentMap = new Map(stats.augments.map(a => [a.id,a]));
}
function metaLine(meta) {
  return '版本 ' + esc(meta.patch || '待确认') + ' · 截至 ' + esc(date(meta.cutoff)) + '（北京时间）';
}
function mini(a,v,b,w) {
  return '<div class="mini-grid"><div><span>' + a + '</span><strong>' + esc(v) + '</strong></div><div><span>' + b + '</span><strong>' + esc(w) + '</strong></div></div>';
}
function row(title, sub, value) {
  return '<div class="statrow"><div><b>' + esc(title) + '</b><small>' + esc(sub) + '</small></div><em>' + esc(value) + '</em></div>';
}
function collapse(lines, limit, name) {
  if (!lines.length) return '<p class="detail-note">这批样本尚无记录。</p>';
  return lines.slice(0,limit).join('') + (lines.length <= limit ? '' :
    '<details><summary>' + esc(name) + '（' + lines.length + '）</summary>' + lines.slice(limit).join('') + '</details>');
}
function renderStatus() {
  const notes = [];
  const latestPatch=leadingGG()?gg.catalog.patch:stats?.patch;
  if (official && latestPatch && official.samplePatch !== latestPatch)
    notes.push('腾讯已公告 ' + official.patch + '，最新国服英雄样本为 ' + latestPatch + '。各表按采样版本展示。');
  if (health.official.stale) notes.push('腾讯公告暂未刷新，保留最近一次记录。');
  if (health.stats.stale) notes.push('AramHex 暂未刷新，保留已核验样本。');
  if (health.aramgg?.stale) notes.push(browserManifest ? '本页已直接核对 ARAMGG 公开清单，后台同步暂未恢复。' : 'ARAMGG 发布清单暂未刷新，保留此前记录。');
  $('status').textContent = notes.join(' ');
  $('status').hidden = !notes.length;
}
function renderSummary() {
  if (!stats) return;
  $('banner-patch').textContent = official ? 'PATCH ' + official.patch : '样本 ' + stats.patch;
  const useGG=ggHeroesActive();
  $('sample-source').textContent = useGG ? 'ARAMGG 英雄样本' : 'AramHex 样本版本';
  $('sample-patch').textContent = useGG ? gg.catalog.patch : stats.patch;
  $('match-count').textContent = useGG ? '未披露' : count(stats.matches);
  $('region-count').textContent = useGG ? '未披露' : count(stats.regions.length);
  $('region-count').title = useGG ? '国服公开快照' : stats.regions.join('、');
  $('sample-time').textContent = useGG ? '未披露' : date(stats.cutoff);
  sourceStrip();
  renderSyncStatus();
  renderNews();
  renderStatus();
}
function newsBody() {
  if (!official) return '<p>正在读取腾讯国服公告。</p>';
  const o = official;
  let s = '<p>' + external(o.url,o.title) + '</p><p>发布于 ' + date(o.publishedAt) + '（北京时间）。';
  if (o.maintenanceStart) s += '<br>预计维护时间为 ' + date(o.maintenanceStart) + ' 至 ' + date(o.maintenanceEnd) + '。';
  s += '</p><p>腾讯公告版本 ' + esc(o.patch) + ' 对应客户端版本 ' + esc(o.samplePatch) + '。</p>';
  if (o.hotfixes.length) s += '<h3>近期热修公告</h3>' + o.hotfixes.map(h => '<p>' + external(h.url,h.title) + ' · ' + date(h.publishedAt) + '</p>').join('');
  if (!o.hotfixesAvailable) s += '<p>热修列表暂未刷新。</p>';
  return s + '<p>' + external(o.listUrl,'查看腾讯版本公告目录') + '</p>';
}
function renderNews() {
  if (!official) return;
  $('news-card').innerHTML = '<span class="eyebrow">腾讯国服公告</span>' + external(official.url,official.title) +
    '<p>发布时间 ' + date(official.publishedAt) + '</p><p>对应客户端版本 ' + esc(official.samplePatch) + '</p>' +
    (official.hotfixes.length ? '<p>本期另有 ' + official.hotfixes.length + ' 条热修公告。</p>' : '') +
    '<button class="slink news-link" data-action="news">公告详情</button>';
}
function columns() {
  const name=['name','英雄'];
  if (ui.tab==='items') return [['name','装备'],['games','持有人次'],['holdRate','持有率'],['winRate','持有时胜率']];
  if (ui.tab==='augments') {
    const metric={tierShare:'同品质占比',coverage:'覆盖英雄',gap:'偏好差（百分点）',trend:'变化（百分点）'}[ui.sort];
    return [['name','海克斯强化'],['rarity','品质'],['games','持有人次'],metric?[ui.sort,metric]:['holdRate','持有率']];
  }
  if (ui.tab==='builds') return [name,['item','常用成装'],['itemGames','装备样本'],['itemWin','装备胜率']];
  if (ggHeroesActive()) return [name,['games','样本场数'],['pickRate','登场率'],['winRate','胜率']];
  return [name,['games','出场人次'],ui.denominator==='players'?['pickRate','出场占比']:['appearancesPer100Matches','每百场出场'],['winRate','胜率']];
}
function fieldValue(r,k) {
  if(k==='rarity')return {silver:1,gold:2,prismatic:3}[r.rarity] ?? null;
  if(k==='item')return r.items?.[0]?.name;
  if(k==='itemGames')return r.items?.[0]?.games;
  if(k==='itemWin')return r.items?.[0]?.winRate;
  return r[k];
}
function listRows() {
  const q=ui.query.trim().toLocaleLowerCase();
  return sourceRows().filter(r=>{
    if(ui.tab==='augments' && ui.rarity!=='all' && ui.rarity!==r.rarity)return false;
    if(ui.minGames && (r.games ?? 0)<ui.minGames)return false;
    if(ui.tab==='items' && ui.itemKind && ui.itemKind!==r.kind)return false;
    if(ui.tab==='augments')return matchesSkillFilter(r.id) && matchesAugmentText(r,q,ui.scopeHero);
    if(!q)return true;
    const terms=ui.tab==='heroes' || ui.tab==='builds'?heroSearchTerms(r):[r.name,r.title,r.alias,r.id];
    if(ui.tab==='builds') terms.push(...r.items.map(i=>i.name),...r.builds.flatMap(b=>b.items));
    return terms.some(s=>String(s || '').toLocaleLowerCase().includes(q));
  }).sort((a,b)=>{
    const x=fieldValue(a,ui.sort), y=fieldValue(b,ui.sort);
    if((x==null)!==(y==null))return x==null?1:-1;
    if(x==null && y==null)return String(a.id).localeCompare(String(b.id),'en',{numeric:true});
    const diff=typeof x==='string'?x.localeCompare(y,'zh-CN'):x-y;
    return ui.direction*diff || (b.games||0)-(a.games||0) || String(a.id).localeCompare(String(b.id));
  });
}
function controls() {
  let filters=(profile?.section==='targets'?heroTargetControls(scopedHero()):'')+sortShortcuts();
  if(ui.tab==='heroes' && !ggHeroesActive()) {
    filters+='<label class="select-label">出场口径 <select id="denominator-select"><option value="players">玩家人次</option><option value="matches" '+(ui.denominator==='matches'?'selected':'')+'>每百场对局</option></select></label>';
  }
  if(!profile && (ui.tab==='augments' || ui.tab==='items')) filters+=heroChooser();
  if(ui.tab==='augments') filters+='<label class="select-label">品质 <select id="rarity-select"><option value="all">全部品质</option>'+
    ['silver','gold','prismatic'].map(k=>'<option value="'+k+'" '+(ui.rarity===k?'selected':'')+'>'+rarityNames[k]+'</option>').join('')+'</select></label>';
  if(ui.tab==='items')filters+=itemFilters();
  if(ui.tab==='augments' || (ui.tab==='heroes' && !ggHeroesActive()))filters+=sampleFilter();
  if(ui.tab==='augments')filters+=(profile?.section==='targets'?'':skillFilter())+augmentRankNote();
  return filters;
}
function tableCopy() {
  const hero=scopedHero(), eq=stats.equipment;
  if(profile && !hero)return [profileSections[profile.section],'AramHex '+stats.patch+' 尚无该英雄的统计样本',ui.tab==='items'?'搜索装备':'搜索海克斯'];
  if(profile?.section==='pairs')return ['选择第一枚海克斯','点选一枚查看效果、持有统计与出装，再从详情里添加下一枚。','搜索海克斯、技能名或 ID'];
  if(profile?.section==='targets')return [hero.name+'的技能强化','国服 '+stats.patch+' · '+count(hero.games)+' 次英雄出场 · 数据截至 '+date(stats.cutoff)+'（北京时间）','搜索强化、技能或效果条件'];
  if(ui.tab==='items'){
    const scope=hero?eq?.byHero?.[hero.id]:null;
    const summary=hero?hero.name+' · '+count(scope?.rows.length)+' 件有持有记录 · 分母 '+count(scope?.denominator)+' 英雄人次':
      count(eq?.catalog.length)+' 件目录装备 · '+count(eq?.matches)+' 场 · '+count(eq?.denominator)+' 玩家人次';
    return [profile?hero.name+'的装备库':'装备图鉴',(eq?.available?summary:'本批装备统计待发布')+' · AramHex '+(eq?.patch || '版本待确认'),'搜索装备名称或 ID'];
  }
  if(ui.tab==='augments')return [hero?hero.name+'持有过的海克斯':'海克斯图鉴', (hero?augmentedRows().length+' 种有结算记录 · '+count(hero.games)+' 次英雄出场':augmentedRows().length+' 种强化 · '+stats.augments.length+' 种有持有统计')+' · AramHex '+stats.patch+' · 截至 '+date(stats.cutoff)+'（北京时间）', '搜索海克斯、技能名或 ID'];
  if(ui.tab==='builds')return ['英雄装备搭配','常用成装与三件套 · 单件数据 AramHex '+(stats.itemsMeta.patch || '版本待确认'),'搜索英雄或装备'];
  if(ggHeroesActive())return ['英雄排行榜', 'ARAMGG · 腾讯国服 '+gg.catalog.patch+' · '+gg.catalog.heroes.length+' 位英雄 · 样本截止未披露','搜索英雄名称或称号'];
  return ['英雄排行榜',stats.heroes.length+' 位英雄 · AramHex '+stats.patch+' · '+(ui.denominator==='players'?'按玩家人次计算出场占比':'按每百场对局计算出场次数'),'搜索英雄名称或称号'];
}
function tableCell(r,key) {
  if(key==='name') {
    let icon,caption;
    if(ui.tab==='augments') { icon=augmentIcon(r);caption=[r.noHeroSample?'本批未记录持有':r.referenceOnly?'仅玩法资料':'',listSkillLabel(r.id,ui.scopeHero)].filter(Boolean).join(' · '); }
    else if(ui.tab==='items') { icon=itemIcon(r);caption=itemKinds[r.kind] || '装备'; }
    else {icon=assetFor(r);caption=r.title;}
    const contents=icon+'<span><b>'+esc(r.name)+'</b>'+(caption?'<small>'+esc(caption)+'</small>':'')+'</span>';
    if(ui.tab==='heroes')return '<td><a class="hero-cell" href="'+esc(profileUrl(r.id))+'" data-preview-hero="'+esc(r.id)+'"'+(ui.id===r.id?' aria-current="true"':'')+' aria-label="'+esc(r.name)+(ui.id===r.id?'已选，进入海克斯库':'，预览英雄资料')+'">'+contents+'</a></td>';
    return '<td><button class="hero-cell" data-select="'+esc(r.id)+'">'+contents+'</button></td>';
  }
  if(key==='rarity')return '<td>'+label(r)+'</td>';
  const v=fieldValue(r,key);
  if(key==='item') return '<td class="build-name">'+esc(v || '暂无记录')+'</td>';
  if(key==='games' || key==='itemGames')return '<td class="num">'+count(v)+'</td>';
  if(key==='coverage')return '<td class="num">'+count(v)+'</td>';
  if(key==='trend' || key==='gap')return '<td class="num">'+esc(points(v))+'</td>';
  if(key==='appearancesPer100Matches')return '<td class="num">'+(v==null?'—':v.toFixed(2))+'</td>';
  return '<td class="num '+(key==='winRate'||key==='itemWin'?'pct':'')+'">'+esc(pct(v))+'</td>';
}
function renderList() {
  if(!stats)return;
  if(profile && renderProfile())return;
  const [title,desc,placeholder]=tableCopy();
  $('table-title').textContent=title;$('table-desc').textContent=desc;$('search').placeholder=placeholder;
  $('querypane').setAttribute('aria-labelledby',profile?'section-'+profile.section:'tab-'+ui.tab);
  document.querySelectorAll('[data-tab]').forEach(t=>t.setAttribute('aria-selected',String(t.dataset.tab===ui.tab)));
  $('filters').innerHTML=controls();
  const rows=listRows(), pages=Math.max(1,Math.ceil(rows.length/PAGE_SIZE));
  displayedRows=rows;
  ui.page=Math.min(ui.page,pages-1);
  const start=ui.page*PAGE_SIZE, visible=rows.slice(start,start+PAGE_SIZE), cols=columns();
  const selected=visible.find(r=>r.id===ui.id) || visible[0];
  ui.id=selected?.id || null;
  const head=cols.map(([key,name])=>'<th scope="col"'+(ui.sort===key?' class="sorted" aria-sort="'+(ui.direction===-1?'descending':'ascending')+'"':'')+
    '><button data-sort="'+key+'">'+name+(ui.sort===key?(ui.direction<0?' ↓':' ↑'):'')+'</button></th>').join('');
  const body=visible.map((r,i)=>'<tr data-row="'+esc(r.id)+'" class="clickable'+(r.id===ui.id?' selected':'')+'"><td class="rank'+(start+i<3 && ui.direction<0 && fieldValue(r,ui.sort)!=null?' top':'')+'">'+(fieldValue(r,ui.sort)==null?'—':String(start+i+1).padStart(2,'0'))+'</td>'+
    cols.map(([k])=>tableCell(r,k)).join('')+'</tr>').join('');
  $('results').innerHTML='<div class="table-scroll"><table><thead><tr><th scope="col">排名</th>'+head+'</tr></thead><tbody>'+body+'</tbody></table></div>'+
    (!visible.length?'<p class="empty">当前条件下没有记录。'+(profile?.section==='targets'?'<button class="slink" data-reset-targets>查看该英雄全部技能强化</button>':'请调整搜索或筛选条件。')+'</p>':'');
  $('range').textContent=rows.length?(start+1)+'–'+(start+visible.length)+' / '+rows.length+' 项':'0 项';
  $('page-num').textContent=(ui.page+1)+' / '+pages;$('prev').disabled=ui.page===0;$('next').disabled=ui.page+1>=pages;
  $('hero-preview-hint').hidden=ui.tab!=='heroes';
  $('hero-tools').hidden=ui.tab!=='heroes' || !selected;
  if(ui.tab==='heroes' && selected)renderHeroTools(selected,start+visible.indexOf(selected));
  renderDetail(selected);
  if(profile){
    const url=atlasLocation();
    if(url.searchParams.has('entry') && url.searchParams.get('entry')!==ui.id && !document.querySelector('dialog[open]')){
      url.searchParams.delete('entry');setAtlasRoute('replaceState',history.state,'',url);
    }
  }
}
function gearDetail(h) {
  const s = stats;
  const summary = '<h3>常用单件</h3><p class="detail-note">' + metaLine(s.itemsMeta) + '。按持有场次排序，每件列出结算胜率。</p>';
  const single=h.items.map(i=>{
    const item=equipmentById.get(i.id);
    const sub=count(i.games)+' 场'+(i.holdRate==null?'':' · 持有率 '+pct(i.holdRate));
    return item?relatedRow('items',item,itemIcon(item),sub,pct(i.winRate)):row(i.name,sub,pct(i.winRate));
  });
  const hist = s.buildsMeta.patch !== s.patch || s.buildsMeta.cutoff !== s.cutoff;
  const builds=h.builds.map(b=>'<li><div class="recipe">'+b.items.map((name,i)=>{
    const item=equipmentById.get(String(b.itemIds[i]));
    return item?entryButton('items',item.id,name,itemIcon(item)):esc(name);
  }).join(' › ')+'</div><p>'+count(b.games)+' 场 · 胜率 '+esc(pct(b.winRate))+'</p></li>');
  return '<button class="slink" data-scope="items" data-for="'+esc(h.id)+'">查看该英雄的全装备持有榜</button>'+summary + collapse(single,3,'展开全部单件') + '<h3>三件套' + (hist?' · 历史样本':'') + '</h3><p class="' + (hist?'info':'detail-note') + '">' +
    metaLine(s.buildsMeta) + '</p>' + (builds.length ? '<ul class="build-list">' + builds.join('') + '</ul>':'<p class="detail-note">该英雄暂无三件套样本。</p>');
}
function renderHeroTools(hero,index){
  $('hero-tools').innerHTML='<b>'+esc(hero.name)+'</b><span>第 '+(index+1)+' 位</span><button data-preview-jump>看详情</button><a href="'+esc(profileUrl(hero.id))+'" data-profile="'+esc(hero.id)+'">海克斯库</a>';
}
function selectHeroPreview(id,focusRow=false){
  const index=displayedRows.findIndex(h=>h.id===id);
  if(index<0)return;
  ui.id=id;
  const page=Math.floor(index/PAGE_SIZE);
  if(page!==ui.page){ui.page=page;renderList();}
  else{
    for(const tr of $('results').querySelectorAll('tr[data-row]')){
      const active=tr.dataset.row===id, link=tr.querySelector('[data-preview-hero]');
      tr.classList.toggle('selected',active);
      if(!link)continue;
      if(active)link.setAttribute('aria-current','true');else link.removeAttribute('aria-current');
      link.setAttribute('aria-label',link.querySelector('b').textContent+(active?'已选，进入海克斯库':'，预览英雄资料'));
    }
    renderHeroTools(displayedRows[index],index);renderDetail(displayedRows[index]);
  }
  $('preview-status').textContent='已选'+displayedRows[index].name+'，当前列表第 '+(index+1)+' 位。';
  if(focusRow)$('results').querySelector('[aria-current="true"]')?.focus();
}
function heroPreviewNav(hero){
  const at=displayedRows.findIndex(h=>h.id===hero.id);
  return '<div class="preview-nav"><span>当前列表 <b>'+(at+1)+' / '+displayedRows.length+'</b></span><button data-preview-step="-1" '+(at<=0?'disabled':'')+'>上一位</button><button data-preview-step="1" '+(at+1>=displayedRows.length?'disabled':'')+'>下一位</button></div>';
}
function renderDetail(r) {
  const el=$('detail');
  if(!r){el.innerHTML='<p class="empty">选择一条记录查看详情。</p>';return;}
  const back=profile?'<button class="mobile-back slink" data-list-return>返回'+profileSections[profile.section]+'列表</button>':'';
  if(ui.tab==='items') {el.dataset.hero='';el.innerHTML=back+itemDetail(r);return;}
  const a=ui.tab==='augments', b=ui.tab==='builds';
  let body='<span class="eyebrow">'+(a?'海克斯详情':b?'出装详情':'英雄详情')+'</span><div class="feature">'+(a?augmentIcon(r):assetFor(r))+
    '<div><h2>'+esc(r.name)+'</h2><small>'+esc(a?(rarityNames[r.rarity] || '其他')+'强化 · ID '+r.id:r.title)+'</small></div></div>';
  if(a) {
    const h=scopedHero();
    body+=mini(h?h.name+'持有率':'整体持有率',pct(r.holdRate),'持有人次',count(r.games))+
      '<p class="detail-note">AramHex · '+metaLine(stats)+(h?' · '+count(h.games)+' 次英雄出场':' · '+count(stats.heroParticipations)+' 玩家人次')+'</p>'+
      (r.noHeroSample?'<p class="detail-note">该英雄本批缺少此强化的持有样本。</p>':h?'<button class="profile-cta" data-open-augment="'+esc(r.id)+'">查看详细数据与出装</button>':'')+qualityDescription(r)+skillTargetDetail(r.id,h?.id)+augmentBreakdown(r,h)+
      '<p class="detail-note">'+external('https://developer.riotgames.com/docs/lol#game-policy','Riot 开发者政策')+'禁止展示海克斯胜率，包括按英雄筛选的胜率。</p>'+
      '<h3>哪些英雄持有过</h3><p class="detail-note">按持有率排序，每个英雄使用自己的出场人次作分母。</p>';
    const holders=stats.heroes.map(h=>({h,n:h.augmentCounts[r.id] || 0})).filter(x=>x.n>0).sort((a,b)=>b.n/b.h.games-a.n/a.h.games);
    body+=collapse(holders.map(({h,n})=>relatedRow('heroes',h,assetFor(h),count(n)+' 持有人次',pct(n/h.games*100))),5,'展开全部英雄');
    if(profile?.section==='pairs')body+=pairPanel();
  }else if(b)body+=gearDetail(r);
  else {
    const h=ggHeroesActive()?stats.heroes.find(x=>x.id===r.id):r;
    body+=heroPreviewNav(r)+'<button class="preview-return" data-return-hero>返回已选英雄</button>'+mini('英雄胜率',pct(r.winRate),ggHeroesActive()?'国服登场率':'出场占比',pct(r.pickRate));
    if(ggHeroesActive()) body+='<p class="detail-note">ARAMGG · 腾讯国服 '+esc(gg.catalog.patch)+' · 样本场数 '+(r.games==null?'未披露':count(r.games))+'<br>统计日期 '+esc(ggDate(r.date))+' · 数据截止未披露</p>';
    else body+='<p class="detail-note">'+count(r.games)+' 次出场 · '+count(r.wins)+' 胜 / '+count(r.games-r.wins)+' 负<br>每百场出场 '+r.appearancesPer100Matches.toFixed(2)+' 次 · AramHex 国服 '+esc(stats.patch)+'<br>数据截至 '+date(stats.cutoff)+'（北京时间）</p>';
    body+='<a class="profile-cta" href="'+esc(profileUrl(r.id))+'" data-profile="'+esc(r.id)+'">查看'+esc(r.name)+'的海克斯库与完整资料</a>'+championMini(r)+(h?heroAugmentsCard(h):'')+pairPanel();
  }
  const panelHero=(a && profile?.section==='pairs')?profile.id:r.id;
  const pairWasOpen=el.dataset.hero===panelHero && el.querySelector('#hero-pairs')?.open;
  el.innerHTML=back+body;el.dataset.hero=panelHero;
  if(a && scopedHero()){
    if(profile)$('section-pairs').href=profileUrl(profile.id,'pairs');
  }
  if(pairWasOpen && $('hero-pairs'))$('hero-pairs').open=true;
  if(location.hash==='#hero-pairs' && $('hero-pairs'))$('hero-pairs').open=true;
  connectPairPanel(el.dataset.hero);
}
function showDialog(title, body) {
  $('dialog').scrollTop=0;
  $('dialog-title').textContent=title; $('dialog-body').innerHTML=body;
  if (!$('dialog').open) $('dialog').showModal();
}
function showMethod() {
  const where = stats?.regions?.join('、') || '读取中';
  showDialog('统计口径','<p>AramHex 汇总国服普通海克斯大乱斗的已结束对局。本批覆盖 ' + esc(where) + '。</p>' +
  '<p><b>英雄出场占比</b>取该英雄出场人次除以全部玩家人次。每百场出场次数取出场人次除以有效对局数，再乘 100。英雄胜率按该英雄胜场除以出场人次计算。</p>' +
  '<p><b>海克斯持有率</b>按结算时持有该强化的人次计算。全局使用全部玩家人次作分母，英雄详情使用该英雄的出场人次。英雄强化列表收录本期有结算持有记录的条目。三选一供选、重随和获取途径均缺少完整记录。一个玩家可持有多枚强化，上游没有提供强化出现供选的次数。</p>' +
  '<p><b>海克斯搭配场数</b>统计同一名玩家在同一局结算时同时持有指定强化的次数。AramHex 当前发布的单项持有人次无法推算这项数字。强化胜率的展示限制见' +
    external('https://developer.riotgames.com/docs/lol#game-policy','Riot 开发者政策') + '。</p>' +
  '<p>英雄技能和基础属性来自 '+external('https://developer.riotgames.com/docs/lol#data-dragon','Riot Data Dragon')+'。装备及强化的中文游戏资料来自 '+external('https://raw.communitydragon.org/','CommunityDragon 版本档案')+'。资料版本与统计版本分别标注。</p>' +
  '<p><b>双源英雄榜</b>只比较已取得的国服英雄样本。新游戏版本优先；同版本使用有明确数据截止和样本量的 AramHex。ARAMGG 的国服登场率沿用腾讯口径，数据源未披露的场数与截止时间均标为未披露。</p>' +
  '<p><b>ARAMGG 三强化</b>统计匿名客户端样本中同一玩家前四个选择位里的三枚强化，每组至少 151 场。地区和版本按该组记录标注。统计日期和接口发布时间分别展示。</p>' +
  '<p><b>装备持有榜</b>按六个装备栏的结算持有记录统计，分母取装备表自己的玩家人次；英雄筛选改用该英雄的装备样本人次。普通装备持有时胜率取该物品的胜场除以持有人次。小样本可以用场数筛选。</p>' +
  '<p><b>装备搭配</b>展示已完成该装备或组合的样本与胜率。装备样本有单独的筛选条件，比较时应同时看样本量和版本。</p>' +
  '<p><b>更新频率</b>　AramHex 在' + external('https://aramhex.com/#faq','项目官网') + '说明，统计约每周更新一次。' + external('https://aramgg.com/zh-CN/about','ARAMGG') + ' 标注每日更新，实际批次以其发布清单为准。本站打开时核对最新批次，页面可见时每 5 分钟检查一次。数据截止时间取自统计窗口，所有时间按北京时间展示。</p>' +
  '<p>统计来自 ' + external('https://github.com/czgreat/aramhex-data','AramHex 国服统计数据') + '，授权为 ' + external('https://creativecommons.org/licenses/by-nc/4.0/deed.zh-hans','CC BY-NC 4.0') + '。本站计算展示比例，并按出场或持有次数整理装备。游戏图像归 Riot Games 所有。本站为玩家作品，未经 Riot Games 或腾讯背书。</p>');
}
function resetTab(tab, id) {
  ui.tab=tab; ui.query=''; $('search').value=''; ui.rarity='all'; ui.skillFilter='';ui.skillBasis='';ui.scopeHero=''; ui.itemKind=''; ui.minGames=0; ui.page=0; ui.id=id || null;
  ui.sort=['augments','items'].includes(tab)?'holdRate':tab==='builds'?'itemGames':'winRate'; ui.direction=-1;
}
function changeTab(tab, id) {
  resetTab(tab,id);
  if (id && stats) {const at=listRows().findIndex(r=>r.id===id); if(at>=0) ui.page=Math.floor(at/PAGE_SIZE);}
  renderList();renderSummary();
}
document.addEventListener('click', e => {
  const t = e.target.closest('button,a,tr[data-row]'); if (!t) return;
  if(t.tagName==='A' && (e.button!==0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey))return;
  if(t.dataset.profile){e.preventDefault();openProfile(t.dataset.profile);}
  else if(t.dataset.previewHero || (ui.tab==='heroes' && t.dataset.row)){
    e.preventDefault();
    const id=t.dataset.previewHero || t.dataset.row;
    if(ui.id===id)openProfile(id);else selectHeroPreview(id);
  }
  else if(t.dataset.previewStep){
    const step=Number(t.dataset.previewStep), index=displayedRows.findIndex(h=>h.id===ui.id);
    const hero=displayedRows[index+step];
    if(hero){selectHeroPreview(hero.id);const next=$('detail').querySelector('[data-preview-step="'+step+'"]:not(:disabled)') || $('detail').querySelector('[data-preview-step]:not(:disabled)');next?.focus({preventScroll:true});}
  }
  else if(t.hasAttribute('data-preview-jump')){$('detail').focus({preventScroll:true});$('detail').scrollIntoView({block:'start'});}
  else if(t.hasAttribute('data-return-hero')){$('results').querySelector('[aria-current="true"]')?.focus();}
  else if(t.dataset.directoryPage){const el=t.closest('[data-directory]');renderSkillDirectory(el,Number(el.dataset.page)+Number(t.dataset.directoryPage));(el.querySelector('[data-directory-page="'+t.dataset.directoryPage+'"]:not(:disabled)') || el.querySelector('[data-directory-page]:not(:disabled)'))?.focus({preventScroll:true});}
  else if(t.dataset.skillReference){openSkillReference(t.dataset.skillReference,t.dataset.targetAugment);}
  else if(t.dataset.targetHero){openProfile(t.dataset.targetHero,'augments',t.dataset.targetAugment);}
  else if(t.dataset.skillsFor){e.preventDefault();openProfile(t.dataset.skillsFor,'targets');if(t.dataset.slot)selectTargetSlot(t.dataset.slot);}
  else if(t.hasAttribute('data-target-slot'))selectTargetSlot(t.dataset.targetSlot);
  else if(t.hasAttribute('data-reset-targets')){ui.skillBasis='';ui.minGames=0;ui.rarity='all';ui.query='';$('search').value='';selectTargetSlot('');}
  else if(t.dataset.rankInfo)showRankInfo(t.dataset.rankInfo);
  else if(t.dataset.profileSection){e.preventDefault();openProfile(profile.id,t.dataset.profileSection,new URL(t.href).searchParams.get('entry'));}
  else if(t.dataset.openAugment || (t.dataset.mechanic && t.closest('#profile-mechanics'))){
    const id=t.dataset.openAugment || t.dataset.mechanic, h=scopedHero();
    if(h && profile)openAugmentSheet(h.id,id);
    else if(h)openProfile(h.id,'augments',id);
  }
  else if(t.dataset.openSet && profile){
    const [first,...extras]=t.dataset.openSet.split(',');openAugmentSheet(profile.id,first,extras);
  }
  else if(t.hasAttribute('data-back-catalog')){e.preventDefault();returnToCatalog();}
  else if(t.hasAttribute('data-list-return')){
    const row=$('results').querySelector('tr.selected .hero-cell');
    row?.focus({preventScroll:true});row?.scrollIntoView({block:'center'});
  }
  else if(t.dataset.tab){setAtlasRoute('replaceState',null,'','?tab='+t.dataset.tab);changeTab(t.dataset.tab);}
  else if(t.dataset.rank || t.dataset.direction) {
    if(t.dataset.rank)ui.sort=t.dataset.rank;
    if(t.dataset.direction)ui.direction=Number(t.dataset.direction);
    ui.page=0;ui.id=null;renderList();
    $('filters').querySelector(t.dataset.rank?'[data-rank="'+ui.sort+'"]':'[data-direction="'+ui.direction+'"]')?.focus({preventScroll:true});
  }
  else if(t.dataset.entry)openLibraryEntry(t.dataset.entry,t.dataset.entryId);
  else if(t.dataset.scope)openScoped(t.dataset.scope,t.dataset.for);
  else if(t.dataset.champInfo)openChampion(t.dataset.champInfo,t.dataset.slot);
  else if(t.dataset.sort) {const k=t.dataset.sort; ui.direction=ui.sort===k?-ui.direction:(['name','rarity','item'].includes(k)?1:-1);ui.sort=k;ui.page=0;renderList();$('results').querySelector('[data-sort="'+k+'"]')?.focus({preventScroll:true});}
  else if(t.dataset.row || t.dataset.select) {
    const id=t.dataset.row || t.dataset.select;
    ui.id=id;
    if(ui.tab==='augments' && scopedHero()){
      if(!(scopedHero().augmentCounts[id]>0)){openSkillReference(scopedHero().id,id);return;}
      if(!profile){openProfile(scopedHero().id,'augments',id);return;}
      $('results').querySelectorAll('[data-row]').forEach(tr=>tr.classList.toggle('selected',tr.dataset.row===id));
      renderDetail(sourceRows().find(r=>r.id===id));openAugmentSheet(profile.id,id);return;
    }
    if(profile)setAtlasRoute('replaceState',history.state,'',profileUrl(profile.id,profile.section,id));
    $('results').querySelectorAll('[data-row]').forEach(tr=>tr.classList.toggle('selected',tr.dataset.row===ui.id));
    renderDetail(sourceRows().find(r=>r.id===ui.id));
    if(matchMedia('(max-width:760px)').matches) $('detail').scrollIntoView({block:'start'});
  } else if(t.id==='prev' || t.id==='next') {ui.page+=t.id==='next'?1:-1;renderList();}
  else if(t.dataset.action==='gear') openProfile(ui.id,'builds');
  else if(t.id==='open-news' || t.dataset.action==='news') {e.preventDefault();showDialog('版本公告',newsBody());}
  else if(t.id==='method') showMethod();
  else if(t.id==='close') $('dialog').close();
  else if(t.id==='refresh' || t.id==='check-sources') refresh(true);
});
$('filters').addEventListener('change',e=>{
  const v=e.target.value, key=e.target.id;
  if(key==='scope-select'){
    ui.scopeHero=v;
    if(!v && !['','linked'].includes(ui.skillFilter))ui.skillFilter='';
    if(ui.sort==='coverage' && v)ui.sort='gap';
    if(ui.sort==='gap' && !v)ui.sort='coverage';
  }
  else if(key==='kind-select')ui.itemKind=v;
  else if(key==='skill-filter')ui.skillFilter=v;
  else if(key==='skill-basis'){ui.skillBasis=v;if(['pending','external'].includes(v))ui.skillFilter='linked';updateTargetLocation();}
  else if(key==='rarity-select')ui.rarity=v;
  else if(key==='min-games')ui.minGames=Number(v);
  else if(key==='denominator-select'){
    ui.denominator=v;
    if(['pickRate','appearancesPer100Matches'].includes(ui.sort))ui.sort=v==='players'?'pickRate':'appearancesPer100Matches';
  }else return;
  ui.page=0;ui.id=null;renderList();$(key)?.focus({preventScroll:true});
});
$('search').addEventListener('input', e=>{ui.query=e.target.value;ui.page=0;renderList();});
$('results').addEventListener('keydown',e=>{
  const link=e.target.closest('[data-preview-hero]');
  if(!link || !['ArrowUp','ArrowDown'].includes(e.key) || e.altKey || e.metaKey || e.ctrlKey)return;
  e.preventDefault();
  const at=displayedRows.findIndex(h=>h.id===link.dataset.previewHero);
  const next=displayedRows[at+(e.key==='ArrowDown'?1:-1)];
  if(next)selectHeroPreview(next.id,true);
});
$('dialog').addEventListener('click',e=>{if(e.target===$('dialog')){const r=$('dialog').getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)$('dialog').close();}});
async function read(path) {
  if(globalThis.offlineAtlas && path.startsWith('/'))return offlineAtlas.read(path);
  const response=await fetch(path,{cache:'no-store',signal:AbortSignal.timeout(70000)});
  if(!response.ok) throw new Error(String(response.status));
  return response.json();
}
async function refresh(manual=false) {
  if(busy) return;
  busy=true; $('check-sources').disabled=true;$('check-sources').textContent='正在检查';$('refresh').disabled=true; $('refresh').querySelector('b').textContent='同步中';
  try {
    if(!stats) {
      const [boot]=await Promise.all([read('/api/bootstrap'),localCatalogs]);
      setStats(boot.stats.value);official=boot.official.value;gg=boot.aramgg?.value || null;for(const kind of ['stats','official','aramgg'])if(boot[kind])health[kind]={checked:boot[kind].checked,stale:boot[kind].stale};
      restoreLocation();
      if(location.hash==='#sync-status')$('sync-status').scrollIntoView();
    }
    await Promise.all(['official','stats','aramgg'].map(async kind=>{
      try {
        const data=await read('/api/'+kind+(kind==='stats'?'?seq='+stats.seq:''));
        health[kind]={checked:data.checked,stale:data.stale};
        if(kind==='stats' && data.value && data.value.seq>stats.seq) {
          const selection=sheet;
          setStats(data.value);renderList();
          if(selection){
            const hero=stats.heroes.find(h=>h.id===selection.heroId);
            if(hero?.augmentCounts[selection.ids[0]]>0)openAugmentSheet(hero.id,selection.ids[0],selection.ids.slice(1),selection.active,false);
            else dismissSheet();
          }
        }
        if(kind==='stats')void refreshGameCatalogs();
        if(kind==='official' && data.value) official=data.value;
        if(kind==='aramgg' && data.value) {
          const wasGG=ggHeroesActive(), previous=gg;gg=data.value;
          if(wasGG!==ggHeroesActive() && ui.tab==='heroes') {ui.sort='winRate';ui.direction=-1;ui.minGames=0;}
          if(previous?.status!==gg.status || previous?.catalog?.version!==gg.catalog?.version || previous?.config?.version!==gg.config?.version)renderList();
        }
      } catch {health[kind]={...health[kind],stale:true};}
      if(kind==='aramgg') {
        if(health.aramgg.stale) await checkPublicManifest();
        else browserManifest=null;
      }
      renderSummary();
    }));
    syncPairView(manual);
    refreshSheetTrios();
    if(manual && $('status').hidden) {$('status').textContent='已核对腾讯公告及两家数据源的发布状态。';$('status').hidden=false;}
  } catch {
    $('status').textContent='查询数据暂未载入，请点击「同步数据」重试。';$('status').hidden=false;
  } finally {busy=false;$('check-sources').disabled=false;$('check-sources').textContent='检查更新';$('refresh').disabled=false;$('refresh').querySelector('b').textContent='同步数据';}
}
function openSyncAnchor(){if(location.hash==='#sync-status')$('sync-status').open=true;}
openSyncAnchor();
window.addEventListener('hashchange',openSyncAnchor);
$('sheet-trios').addEventListener('toggle',refreshSheetTrios);
bindAugmentSheet();
bindSkillDirectory();
const localCatalogs=Promise.allSettled([
  read('/portraits.json').then(v=>portraits=v),read('/item-icons.json').then(v=>itemIcons=v),
  read('/champion-catalog.json').then(v=>championBook=v),read('/augment-catalog.json').then(v=>augmentBook=v),
  read('/augment-skill-targets.json').then(v=>augmentSkillBook=unpackSkillBook(v)),
  read('/champion-spell-traits.json').then(v=>spellTraitsBook=v)
]);
refresh();
setInterval(()=>{if(!document.hidden)refresh();},300000);
document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh();});
