'use strict';
const balanceModes={mayhem:'海克斯大乱斗',aram:'极地大乱斗'};
let selectedBalanceMode='mayhem';

function heroBalanceEntries(name,title,mode){
  const names=[name,title].filter(Boolean);
  const archive=official?.balanceNotices?.documents || [];
  return archive.flatMap(doc=>doc.entries.filter(entry=>entry.mode===mode && names.includes(entry.name)).map(entry=>({doc,entry})));
}
function balanceMetricTone(metric){
  if(metric.value===metric.baseline)return 'neutral';
  const stronger=(metric.value>metric.baseline)===(metric.favorable==='higher');
  return stronger?'buff':'nerf';
}
function metricNumber(value){return Number(value.toFixed(3)).toLocaleString('zh-CN',{maximumFractionDigits:3});}
function balancePanelContents(id,name,title,mode){
  const label=balanceModes[mode],snapshot=official?.championBalance;
  const compatible=snapshot && snapshot.patch===official?.samplePatch;
  const data=compatible?snapshot.modes[mode]:null;
  const row=data?.byHero?.[id];
  const metrics=row?.metrics || [];
  const history=heroBalanceEntries(name,title,mode);
  const tabs=Object.entries(balanceModes).map(([key,text])=>'<button type="button" data-balance-mode="'+key+'" aria-pressed="'+(mode===key)+'">'+text+'</button>').join('');
  const tones={buff:'增强',nerf:'削弱',neutral:'基准值'};
  const sources=new Map();
  const values=metrics.map(m=>{
    const source=m.source || row.source || data.source;
    if(source?.url && !sources.has(source.url))sources.set(source.url,{source,num:sources.size+1});
    const n=sources.get(source?.url)?.num;
    return '<div><dt>'+esc(m.label)+'</dt><dd><strong>'+esc(metricNumber(m.value)+m.unit)+'</strong><span class="balance-tone '+balanceMetricTone(m)+'">'+tones[balanceMetricTone(m)]+'</span></dd><small>基准 '+esc(metricNumber(m.baseline)+m.unit)+(n?' · '+(/wiki/i.test(source.url)?'社区资料':'腾讯公告')+' '+n:'')+'</small></div>';
  }).join('');
  const links=[...sources.values()].map(({source,num})=>'<li>'+num+' · '+external(source.url,source.name)+' · '+esc(source.patch)+' · '+esc(date(source.publishedAt))+'</li>').join('');
  const notices=history.map(({doc,entry})=>'<li><div><b>'+esc(doc.patch)+' · '+esc(patchKinds[entry.kind] || '调整')+'</b><small>'+esc(date(doc.publishedAt))+' · '+external(doc.url,doc.hotfix?'腾讯热修':'腾讯公告')+'</small></div>'+entry.details.map(line=>'<p>'+esc(line)+'</p>').join('')+'</li>').join('');
  const recent=history.find(({doc})=>doc.patch===official?.patch);
  const headline=recent?'<p class="balance-latest"><b>本版'+esc(patchKinds[recent.entry.kind] || '调整')+'</b> '+esc(recent.entry.details[0])+' · '+external(recent.doc.url,'腾讯原文')+'</p>':'';
  const dataState=data?.status==='cached'?' · 最近核验副本':'';
  const sourceInfo=links?'<ol class="balance-sources">'+links+'</ol>':'';
  const wikiCredit=[...sources.values()].some(({source})=>/wiki/i.test(source.url))?' · '+external('https://creativecommons.org/licenses/by-sa/3.0/','Wiki 数据许可 CC BY-SA 3.0'):'';
  const notesText=notices?'<ol class="balance-history">'+notices+'</ol>':'<p>已收录的腾讯公告中暂无这位英雄在该玩法的具名调整。</p>';
  const intro=metrics.length?'<dl class="balance-metrics">'+values+'</dl>':'<p class="balance-missing">本版尚无'+esc(name)+'在'+label+'可核实的数值。未列出的属性仍待核实。</p>';
  return '<div class="balance-heading"><h3>大乱斗平衡</h3><small>国服 '+esc(official?.patch || '待同步')+' · 客户端 '+esc(official?.samplePatch || '待同步')+dataState+'</small></div>'+
    '<div class="balance-tabs" role="group" aria-label="查看哪种大乱斗平衡">'+tabs+'</div>'+headline+intro+
    '<details class="balance-evidence"><summary>来源与腾讯改动'+(history.length?'（'+history.length+' 条）':'')+'</summary>'+
    (sourceInfo?'<h4>本版数值来源</h4>'+sourceInfo+'<p>只列有版本证据的指标。'+wikiCredit+'</p>':'')+
    '<h4>'+label+' · 腾讯公告记录</h4>'+notesText+'</details>';
}
function heroBalance(hero){
  return '<section class="hero-balance" data-balance-hero="'+esc(hero.id)+'" data-balance-name="'+esc(hero.name)+'" data-balance-title="'+esc(hero.title || '')+'" aria-label="'+esc(hero.name)+'的大乱斗平衡">'+
    balancePanelContents(hero.id,hero.name,hero.title,selectedBalanceMode)+'</section>';
}
function refreshHeroBalances(){
  for(const panel of document.querySelectorAll('[data-balance-hero]')){
    const details=panel.querySelector('details');
    const focused=panel.contains(document.activeElement);
    const button=focused?document.activeElement.closest('[data-balance-mode]')?.dataset.balanceMode:null;
    const summaryFocused=focused && document.activeElement.tagName==='SUMMARY';
    const isOpen=details?.open;
    const html=balancePanelContents(panel.dataset.balanceHero,panel.dataset.balanceName,panel.dataset.balanceTitle,selectedBalanceMode);
    const temp=document.createElement('template');temp.innerHTML=html;
    if(isOpen)temp.content.querySelector('details').open=true;
    if(panel.innerHTML===temp.innerHTML)continue;
    panel.replaceChildren(temp.content);
    if(button)panel.querySelector('[data-balance-mode="'+button+'"]')?.focus({preventScroll:true});
    if(summaryFocused)panel.querySelector('summary')?.focus({preventScroll:true});
  }
}
document.addEventListener('click',event=>{
  const button=event.target.closest('[data-balance-mode]');
  if(!button || !Object.hasOwn(balanceModes,button.dataset.balanceMode))return;
  selectedBalanceMode=button.dataset.balanceMode;
  refreshHeroBalances();
});
