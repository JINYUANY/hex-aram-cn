'use strict';
const balanceModes={mayhem:'海克斯大乱斗',aram:'极地大乱斗'};
const balanceViews={...balanceModes,compare:'两种模式对照'};
function heroQuery(params){
  if(selectedBalanceMode!=='mayhem')params.set('balance',selectedBalanceMode);
  else params.delete('balance');
  return '?'+params;
}
let selectedBalanceMode='mayhem';

function heroBalanceEntries(name,title,mode){
  const names=[name,title].filter(Boolean);
  const archive=official?.balanceNotices?.documents || [];
  return archive.flatMap(doc=>doc.entries.filter(entry=>entry.mode===mode && names.includes(entry.name)).map(entry=>({doc,entry})));
}
function balanceMetricTone(metric){
  if(metric.value===metric.baseline)return 'neutral';
  const stronger=(metric.value>metric.baseline)===(metric.favorable==='higher');
  return stronger?'buff':'nerf';
}
function metricNumber(value){return Number(value.toFixed(3)).toLocaleString('zh-CN',{maximumFractionDigits:3});}
function shortBalanceSource(source){
  return /wiki/i.test(source.url)?'社区资料':'腾讯公告';
}
function balanceInterpretation(m){
  if(m.value===m.baseline)return '与基准相同';
  const diff=metricNumber(Math.abs(m.value-m.baseline)),up=m.value>m.baseline;
  return m.baseline===100?(up?'增加 ':'减少 ')+diff+'%':(up?'增加 ':'减少 ')+diff+m.unit;
}
function comparisonBody(id,name,snapshot){
  const rows=Object.keys(balanceModes).map(mode=>snapshot?.modes[mode]?.byHero[id]);
  const keys=new Set(rows.flatMap(row=>row?.metrics.map(m=>m.key) || []));
  const cells=[...keys].map(key=>{
    const pair=rows.map(row=>row?.metrics.find(m=>m.key===key));
    const metric=pair.find(Boolean);
    const values=pair.map((m,i)=>{
      if(!m)return '<td class="balance-unknown">待核实</td>';
      const src=m.source || rows[i].source;
      return '<td><b>'+esc(metricNumber(m.value)+m.unit)+'</b><small>'+esc(balanceInterpretation(m))+'</small>'+
        external(src.url,shortBalanceSource(src))+'</td>';
    });
    return '<tr><th scope="row">'+esc(metric.label)+'<small>基准 '+esc(metricNumber(metric.baseline)+metric.unit)+'</small></th>'+values.join('')+'</tr>';
  }).join('');
  if(!cells)return '<p class="balance-missing">本版尚无'+esc(name)+'在这两种玩法的通用属性修正记录。</p>';
  return '<table class="balance-compare"><caption class="sr-only">'+esc(name)+'两种大乱斗通用属性对照</caption><thead><tr><th scope="col">通用属性</th>'+
    '<th scope="col">海克斯大乱斗</th><th scope="col">极地大乱斗</th></tr></thead><tbody>'+cells+'</tbody></table>';
}
function balanceSkillSection(id,mode,data){
  const skills=data?.skillsByHero?.[id];
  if(!skills?.length || !data.source)return '';
  const source=data.source;
  const book=championBook.version?.startsWith(official.samplePatch+'.')?championBook.byId?.[id]:null;
  const entries=skills.map(skill=>{
    const slot=skill.slot;
    const ability=skill.name || book?.skills?.find(s=>s.slot===slot)?.name || '';
    const title=[slot==='all'?'通用技能规则':slot==='P'?'被动':slot,ability].filter(Boolean).join(' · ') || '技能调整';
    return '<li><strong>'+esc(title)+'</strong><ul>'+skill.details.map(d=>'<li lang="'+(d.lang==='en'?'en':'zh-CN')+'">'+
      (d.lang==='en'?'<small lang="zh-CN">来源原文</small> ':'')+esc(d.text)+'</li>').join('')+'</ul></li>';
  }).join('');
  return '<section class="balance-skills"><h4>'+balanceModes[mode]+' · 专属技能修正</h4><ul>'+entries+'</ul><small>'+
    external(source.url,source.name)+' · '+esc(source.patch)+' · '+esc(date(source.publishedAt))+' · '+external('https://creativecommons.org/licenses/by-sa/3.0/','CC BY-SA 3.0')+'</small></section>';
}
function balanceHistory(history){
  return history.map(({doc,entry})=>'<li><div><b>'+esc(doc.patch)+' · '+esc(patchKinds[entry.kind] || '调整')+'</b><small>'+esc(date(doc.publishedAt))+' · '+external(doc.url,doc.hotfix?'腾讯热修':'腾讯公告')+'</small></div>'+entry.details.map(line=>'<p>'+esc(line)+'</p>').join('')+'</li>').join('');
}
function balancePanelContents(id,name,title,mode){
  const label=balanceModes[mode],snapshot=official?.championBalance;
  const compatible=snapshot && snapshot.patch===official?.samplePatch;
  const data=compatible?snapshot.modes[mode]:null;
  const row=data?.byHero?.[id];
  const metrics=row?.metrics || [];
  const history=heroBalanceEntries(name,title,mode);
  const tabs=Object.entries(balanceViews).map(([key,text])=>'<button type="button" data-balance-mode="'+key+'" aria-pressed="'+(mode===key)+'">'+text+'</button>').join('');
  const head='<div class="balance-heading"><h3>大乱斗平衡</h3><small>国服 '+esc(official?.patch || '待同步')+' · 客户端 '+esc(official?.samplePatch || '待同步')+(data?.status==='cached'?' · 最近核验副本':'')+'</small></div>'+
    '<div class="balance-tabs" role="group" aria-label="查看哪种大乱斗平衡">'+tabs+'</div>';
  if(mode==='compare'){
    const sections=Object.entries(balanceModes).map(([key,titleText])=>{
      const entries=heroBalanceEntries(name,title,key);
      const modeData=compatible?snapshot.modes[key]:null,record=modeData?.byHero[id];
      const sources=new Map((record?.metrics || []).map(m=>{const src=m.source || record.source;return [src.url,src];}));
      const revisions=[...sources.values()].map(src=>'<li>'+external(src.url,src.name)+' · '+esc(src.patch)+' · '+esc(date(src.publishedAt))+'</li>').join('');
      return '<h4>'+titleText+'</h4>'+(revisions?'<ul class="balance-sources">'+revisions+'</ul>':'')+(entries.length?'<ol class="balance-history">'+balanceHistory(entries)+'</ol>':'<p>已收录的腾讯公告中暂无具名调整。</p>');
    }).join('');
    const skills=Object.keys(balanceModes).map(key=>balanceSkillSection(id,key,compatible?snapshot.modes[key]:null)).join('');
    return head+comparisonBody(id,name,compatible?snapshot:null)+skills+
      '<details class="balance-evidence"><summary>两种模式的腾讯改动与来源</summary>'+sections+
      '<p>各数值旁的链接指向对应原文。'+external('https://creativecommons.org/licenses/by-sa/3.0/','Wiki 数据许可 CC BY-SA 3.0')+'</p></details>';
  }
  const tones={buff:'增强',nerf:'削弱',neutral:'基准值'};
  const sources=new Map();
  const values=metrics.map(m=>{
    const source=m.source || row.source || data.source;
    if(source?.url && !sources.has(source.url))sources.set(source.url,{source,num:sources.size+1});
    const n=sources.get(source?.url)?.num;
    return '<div><dt>'+esc(m.label)+'</dt><dd><strong>'+esc(metricNumber(m.value)+m.unit)+'</strong><span class="balance-tone '+balanceMetricTone(m)+'">'+tones[balanceMetricTone(m)]+'</span></dd><small>基准 '+esc(metricNumber(m.baseline)+m.unit)+(n?' · '+shortBalanceSource(source)+' '+n:'')+'</small></div>';
  }).join('');
  const links=[...sources.values()].map(({source,num})=>'<li>'+num+' · '+external(source.url,source.name)+' · '+esc(source.patch)+' · '+esc(date(source.publishedAt))+'</li>').join('');
  const notices=balanceHistory(history);
  const recent=history.find(({doc})=>doc.patch===official?.patch);
  const headline=recent?'<p class="balance-latest"><b>本版'+esc(patchKinds[recent.entry.kind] || '调整')+'</b> '+esc(recent.entry.details[0])+' · '+external(recent.doc.url,'腾讯原文')+'</p>':'';
  const sourceInfo=links?'<ol class="balance-sources">'+links+'</ol>':'';
  const wikiCredit=[...sources.values()].some(({source})=>/wiki/i.test(source.url))?' · '+external('https://creativecommons.org/licenses/by-sa/3.0/','Wiki 数据许可 CC BY-SA 3.0'):'';
  const notesText=notices?'<ol class="balance-history">'+notices+'</ol>':'<p>已收录的腾讯公告中暂无这位英雄在该玩法的具名调整。</p>';
  const intro=metrics.length?'<dl class="balance-metrics">'+values+'</dl>':'<p class="balance-missing">本版尚无'+esc(name)+'在'+label+'可核实的通用属性修正。</p>';
  return head+headline+intro+balanceSkillSection(id,mode,data)+
    '<details class="balance-evidence"><summary>来源与腾讯改动'+(history.length?'（'+history.length+' 条）':'')+'</summary>'+
    (sourceInfo?'<h4>本版数值来源</h4>'+sourceInfo+'<p>只列有版本证据的指标。'+wikiCredit+'</p>':'')+
    '<h4>'+label+' · 腾讯公告记录</h4>'+notesText+'</details>';
}
function heroBalance(hero){
  return '<section class="hero-balance" data-balance-hero="'+esc(hero.id)+'" data-balance-name="'+esc(hero.name)+'" data-balance-title="'+esc(hero.title || '')+'" aria-label="'+esc(hero.name)+'的大乱斗平衡">'+
    balancePanelContents(hero.id,hero.name,hero.title,selectedBalanceMode)+'</section>';
}
function replaceHeroContent(el,html){
  const current=el.querySelector('[data-balance-hero]'),heroId=current?.dataset.balanceHero;
  const wasOpen=current?.querySelector('.balance-evidence')?.open;
  const active=document.activeElement,focused=current?.contains(active);
  el.innerHTML=html;
  const next=el.querySelector('[data-balance-hero]');
  if(!next || next.dataset.balanceHero!==heroId)return;
  if(wasOpen)next.querySelector('.balance-evidence').open=true;
  if(focused){
    const target=active.dataset.balanceMode?next.querySelector('[data-balance-mode="'+active.dataset.balanceMode+'"]'):
      active.tagName==='SUMMARY'?next.querySelector('summary'):[...next.querySelectorAll('a')].find(a=>a.href===active.href);
    target?.focus({preventScroll:true});
  }
}
function refreshHeroBalances(){
  for(const panel of document.querySelectorAll('[data-balance-hero]')){
    const details=panel.querySelector('details');
    const focused=panel.contains(document.activeElement);
    const button=focused?document.activeElement.closest('[data-balance-mode]')?.dataset.balanceMode:null;
    const summaryFocused=focused && document.activeElement.tagName==='SUMMARY';
    const isOpen=details?.open;
    const html=balancePanelContents(panel.dataset.balanceHero,panel.dataset.balanceName,panel.dataset.balanceTitle,selectedBalanceMode);
    const temp=document.createElement('template');temp.innerHTML=html;
    if(isOpen)temp.content.querySelector('details').open=true;
    if(panel.innerHTML===temp.innerHTML)continue;
    panel.replaceChildren(temp.content);
    if(button)panel.querySelector('[data-balance-mode="'+button+'"]')?.focus({preventScroll:true});
    if(summaryFocused)panel.querySelector('summary')?.focus({preventScroll:true});
  }
}
document.addEventListener('click',event=>{
  const button=event.target.closest('[data-balance-mode]');
  if(!button || !Object.hasOwn(balanceViews,button.dataset.balanceMode))return;
  selectedBalanceMode=button.dataset.balanceMode;
  if(profile)setAtlasRoute('replaceState',history.state,'',heroQuery(atlasLocation().searchParams));
  for(const link of document.querySelectorAll('a[data-profile],a[data-profile-section],a[data-preview-hero]')){
    const params=new URL(link.href).searchParams;
    if(params.has('hero'))link.setAttribute('href',heroQuery(params));
  }
  refreshHeroBalances();
});
