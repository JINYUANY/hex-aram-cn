'use strict';
function artPath(path){return globalThis.offlineAtlas?.images[path] || path;}
function atlasLocation(){
  const url=new URL(location.href);
  if(globalThis.offlineAtlas && url.hash.startsWith('#?')){url.search=url.hash.slice(1);url.hash='';}
  return url;
}
function setAtlasRoute(method,state,title,input){
  if(!globalThis.offlineAtlas){history[method](state,title,input);return;}
  const url=new URL(input,location.href);
  const query=url.hash.startsWith('#?')?url.hash.slice(1):url.search;
  history[method](state,title,query?'#'+query:(url.hash || '#top'));
}
let gg = null;
let browserManifest = null;
let browserManifestChecked = 0;
const trioReads = new Map();
const ggStateText = {
  'needs-key':'等待配置免费 API Key',
  mirror:'已同步授权国服英雄榜',
  credentials:'密钥未通过验证',
  quota:'接口额度或请求频率受限，稍后重试',
  unavailable:'统计接口暂不可用',
  ready:'已取得国服英雄样本'
};
function comparePatch(left,right) {
  const a=left.split('.').map(Number), b=right.split('.').map(Number);
  return a[0]-b[0] || a[1]-b[1];
}
function leadingGG() {
  const catalog=gg?.catalog;
  return Boolean(stats && catalog?.heroes?.length && comparePatch(catalog.patch,stats.patch)>0);
}
function ggHeroesActive() {return ui.tab==='heroes' && leadingGG();}
function sourceRows() {
  if (ui.tab==='augments') return augmentRankRows(augmentedRows(),scopedHero());
  if (ui.tab==='items') return itemRows();
  return ggHeroesActive() ? gg.catalog.heroes : stats.heroes;
}
function ggDate(s) {
  if (!s) return '未披露';
  return /^\d{4}-\d{2}-\d{2}$/.test(s) ? s : date(s)+'（北京时间）';
}
async function checkPublicManifest() {
  // This CORS-enabled resource is public. Protected statistics are requested only by the server.
  try {
    const response=await fetch('https://data.dtodo.cn/api/v1/zh-CN/config.json',{
      credentials:'omit',redirect:'error',referrerPolicy:'no-referrer',signal:AbortSignal.timeout(9000)
    });
    if(!response.ok) throw new Error('Unavailable');
    const m=await response.json();
    if(m.service!=='aramgg-data-api' || m.schemaVersion!==1 || m.locale!=='zh-CN' ||
      !/^\d{1,2}\.\d{1,2}$/.test(m.gamePatch) || !Number.isSafeInteger(m.apiRelease) ||
      m.apiRelease<0 || m.dataVersion!==m.gamePatch+'.'+m.apiRelease) throw new Error('Unknown manifest');
    const current=gg?.config;
    if(current && (comparePatch(m.gamePatch,current.patch)<0 || (m.gamePatch===current.patch && m.apiRelease<current.release)))
      throw new Error('Earlier release');
    browserManifest={version:m.dataVersion,patch:m.gamePatch,release:m.apiRelease,
      publishedAt:m.publishedAt && Number.isFinite(Date.parse(m.publishedAt))?m.publishedAt:null};
    browserManifestChecked=Date.now();
  } catch {browserManifest=null;browserManifestChecked=0;}
}
function sourceStrip() {
  if(!stats) return;
  const ah='<article><b>AramHex</b><span>国服 '+esc(stats.patch)+' · '+ count(stats.matches)+' 场</span>' +
    '<small>数据截止 '+esc(date(stats.cutoff))+'（北京时间）</small></article>';
  let detail='<small>正在读取发布清单…</small>';
  if(gg) {
    const cat=gg.catalog, config=browserManifest || gg.config;
    detail='<span>公开批次 '+esc(config.version)+'</span><small>'+(cat?'已取得英雄榜 '+esc(cat.version)+' · 统计日期 '+esc(ggDate(cat.date))+' · 样本截止未披露':'国服英雄榜尚未取得')+
      ' · '+esc(ggStateText[gg.status] || '状态待核实')+'</small>';

  }
  $('source-strip').innerHTML=ah+'<article><b>ARAMGG</b>'+detail+'</article>';
}
function renderSyncStatus() {
  const latest=leadingGG()?gg.catalog.patch:stats.patch;
  $('sync-summary').textContent=official?.samplePatch===latest?'国服英雄样本已对齐公告版本':
    official?'公告对应 '+official.samplePatch+' · 英雄样本 '+latest:'查看来源与更新时间';
  const checked=kind=>{
    const state=health[kind] || {};
    const last=state.checked?'最近成功核对 '+date(state.checked):'暂无成功核对时间';
    return state.stale?'本次检查未成功 · '+last:last;
  };
  const grid=(name,url,lines)=>'<article><h3>'+external(url,name)+'</h3><dl>'+lines.map(([key,value])=>
    '<div><dt>'+esc(key)+'</dt><dd>'+esc(value)+'</dd></div>').join('')+'</dl></article>';
  const entries=[];
  if(official)entries.push(grid('腾讯国服公告',official.url,[
    ['游戏版本',official.patch+' · 客户端 '+official.samplePatch],['公告发布',date(official.publishedAt)],['公告检查',checked('official')]
  ]));
  entries.push(grid('AramHex 普通模式','https://github.com/czgreat/aramhex-data/blob/data-v'+stats.seq+'/latest.json',[
    ['样本版本',stats.patch+' · '+count(stats.matches)+' 场'],['样本截止',date(stats.cutoff)],['批次检查',checked('stats')]
  ]));
  const config=browserManifest || gg?.config;
  if(config){
    const fields=[['公开批次',config.version],['接口发布',config.publishedAt?date(config.publishedAt):'未披露'],
      ['清单检查',checked('aramgg')]];
    if(browserManifest)fields.push(['浏览器核对',date(browserManifestChecked)]);
    fields.push(['统计接口',ggStateText[gg?.status] || '尚未取得状态']);
    if(gg?.catalog)fields.push(['已取得英雄榜',gg.catalog.version+' · 统计日期 '+ggDate(gg.catalog.date)+' · 样本截止未披露']);
    entries.push(grid('ARAMGG 发布清单','https://data.dtodo.cn/api/v1/zh-CN/config.json',fields));
  }
  const el=$('sync-sources'),html=entries.join('');
  if(el.innerHTML!==html)el.innerHTML=html;
  renderCoverage();
}
function trioStatusText(target,result,record,status,localCount){
  if(result?.status==='ready')return localCount?'国服 '+target+' · '+localCount+' 组实测场数':'已查询 · 本批未返回国服 '+target+' 的三枚组合';
  const state=result?.status || status;
  if(state==='ready')return record?.pending?'正在查询三枚组合':'展开查询国服 '+target+' 三枚组合';
  return '尚未取得场数 · '+(ggStateText[state] || '正在核对来源');
}
function pairPanel() {
  return '<details class="pair-query" id="hero-pairs"><summary>三强化组合 · ARAMGG<small data-pair-status></small></summary>' +
    '<div data-pair-body></div></details>';
}
function matchingTrioRows(rows,ids){
  return rows.filter(r=>ids.every(id=>r.augmentIds?.includes(id)));
}
function renderTrioPanel(panel,id,target,selected,record){
  const result=record?.value;
  const rows=matchingTrioRows(result?.rows || [],selected);
  const local=rows.filter(r=>r.region==='CN' && r.patch===target);
  const other=rows.filter(r=>!local.includes(r));
  const showRows=list=>'<ul class="trio-list">'+list.map(r=>{
    const region=r.region==='CN'?'国服':r.region==='WORLD'?'跨区汇总':'地区未披露';
    const faces=r.names.map((name,i)=>{
      const aid=r.augmentIds?.[i],a=augmentMap.get(aid) || augmentBook.byId?.[aid];
      return '<span class="trio-face">'+(a?augmentIcon({...a,id:aid}):'')+esc(name)+'</span>';
    }).join('<span aria-hidden="true"> ＋ </span>');
    return '<li><b>'+faces+'</b><strong>'+count(r.games)+' 场</strong>'+
      '<small>'+region+' · '+(r.patch?'版本 '+esc(r.patch):'组合版本未披露')+' · 统计日期 '+esc(ggDate(r.date))+' · 截止时间未披露</small></li>';
  }).join('')+'</ul>';
  let heading=trioStatusText(target,result,record,gg?.status,local.length);
  if(selected.length && result?.status==='ready' && !local.length)heading='已查询 · 本批无符合已选条件的国服三枚组合';
  panel.querySelector('[data-pair-status]').textContent=heading;
  let body='<p>查询国服 '+esc(target)+(selected.length?' · 已选 '+selected.map(id=>esc(pairName(id))).join('、'):'')+'。</p>';
  if(result?.status==='ready'){
    body+='<p>ARAMGG 客户端批次 '+esc(result.version)+'。场数按同一玩家前四个选择位中出现三枚强化统计。</p>';
    if(local.length)body+=showRows(local);
    else body+='<p>本批已返回的组合中没有匹配记录。</p>';
    if(other.length && !selected.length)body+='<details class="other-trios"><summary>其他地区、历史或版本未确认的组合（'+other.length+'）</summary>'+showRows(other)+'</details>';
    if(result.unverified)body+='<p>另有 '+count(result.unverified)+' 条原始记录缺少可核验的场数、组合或来源。</p>';
    body+='<p>每位英雄最多收录 5 组。每行场数仅适用于完整的三枚组合。</p>';
  }else{
    const state=result?.status || gg?.status;
    body+='<p>'+esc(state==='ready'?'正在查询该英雄的三枚组合。':ggStateText[state] || '正在核对发布信息。')+'</p>';
  }
  panel.querySelector('[data-pair-body]').innerHTML=body+'<p>'+external('https://aramgg.com/zh-CN/champion-stats/'+encodeURIComponent(id),'ARAMGG 英雄原表')+'</p>';
}
function readTrioRecord(id,version){
  const key=version+'/'+id,old=trioReads.get(key);
  if(old && (old.pending || old.until>Date.now()))return old;
  const record={pending:true};
  trioReads.set(key,record);
  record.promise=read('/api/aramgg/trios/'+id).then(value=>{
    if(value.version && value.version!==version){trioReads.delete(key);return;}
    record.value=value;record.until=Date.now()+(value.status==='ready'?3600000:300000);
  }).catch(()=>{record.value={status:'unavailable'};record.until=Date.now()+60000;})
    .finally(()=>{record.pending=false;});
  return record;
}
function checkTrioPanel(panel,id,target,ids=[]){
  const version=gg?.config?.version;
  const key=version+'/'+id;
  panel.dataset.trioKey=key;
  const enabled=gg?.status==='ready' && version;
  const record=enabled?(panel.open?readTrioRecord(id,version):trioReads.get(key)):null;
  renderTrioPanel(panel,id,target,ids,record);
  if(record?.pending)record.promise.then(()=>{
    if(!panel.isConnected || panel.dataset.trioKey!==key || gg?.config?.version!==version || gg?.status!=='ready')return;
    const selection=panel.id==='sheet-trios'?sheet?.ids:[];
    if(selection && !panel.hidden)renderTrioPanel(panel,id,target,selection,record);
  });
}
function connectPairPanel(id){
  const panel=$('hero-pairs');
  if(!panel)return;
  const check=()=>checkTrioPanel(panel,id,leadingGG()?gg.catalog.patch:stats.patch);
  panel.addEventListener('toggle',check);
  check();
}
function refreshSheetTrios(){
  const panel=$('sheet-trios');
  if(!sheet || !panel)return;
  panel.hidden=sheet.ids.length>3;
  if(!panel.hidden)checkTrioPanel(panel,sheet.heroId,sheet.patch,sheet.ids);
}
