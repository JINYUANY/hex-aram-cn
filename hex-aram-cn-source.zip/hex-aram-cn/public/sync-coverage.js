'use strict';
function syncCoverageRows(){
  if(!stats)return [];
  const target=official?.samplePatch;
  const eq=stats.equipment || {};
  const checked=kind=>health[kind]?.stale?'本次未核实':'';
  const windowLabel=meta=>meta?.patch?meta.patch+(meta.cutoff?' · 截至 '+date(meta.cutoff):''):'尚无版本记录';
  const windowState=meta=>!meta?.patch?'待来源发布':target && target!==meta.patch?'历史样本':'已载入';
  const currentBook=(version,flag)=>flag==='pending'?'等待重试':!version?'待资料源':target && version!==target && !version.startsWith(target+'.')?'历史资料':flag==='ready'?'已核对':'已载入';
  const roster=Object.keys(championBook.byId || {}).length;
  const augments=Object.keys(augmentBook.byId || {}).length;
  const rules=Object.keys(official?.heroPool?.heroes || {}).length;
  const notices=official?.balanceNotices?.documents || [];
  const snapshot=official?.championBalance;
  const enrich=stats.enrichment || {};
  const rows=[
    ['腾讯公告与热修',checked('official') || (official?.notesPending?'正文待重试':official?.mayhem?'已载入':'等待正文'),official?official.patch+' · 海克斯改动 '+(official.mayhem?.entries?.length ?? 0)+' 条 · 热修索引 '+(official.hotfixes?.length ?? 0)+' 篇':'等待腾讯公告'],
    ['英雄胜率、出场与海克斯持有',checked('stats') || windowState(stats),windowLabel(stats)+' · '+count(stats.matches)+' 场'],
    ['普通装备结算统计',eq.available?windowState(eq):'待装备统计',windowLabel(eq)+' · '+count(eq.matches)+' 场'],
    ['英雄成装',windowState(stats.itemsMeta),windowLabel(stats.itemsMeta)],
    ['三件套',windowState(stats.buildsMeta),windowLabel(stats.buildsMeta)],
    ['限定海克斯的出装',windowState(stats.augmentGear),stats.augmentGear?windowLabel(stats.augmentGear)+' · '+(augmentMap.get(String(stats.augmentGear.augmentId))?.name || '强化 '+stats.augmentGear.augmentId):'等待有对应条件和场数的样本'],
    ['英雄技能与属性',currentBook(championBook.version,catalogChecks.heroes),(championBook.version || '版本待同步')+' · '+roster+' 位英雄 · Riot Data Dragon'],
    ['海克斯图鉴',currentBook(augmentBook.patch,catalogChecks.augments || (augmentBook.textAvailable===false?'pending':'')),(augmentBook.patch || '版本待同步')+' · '+augments+' 枚 · CommunityDragon'],
    ['装备图标与属性',enrich.dragonItems==='pending' || enrich.communityItems==='pending'?'等待重试':currentBook(eq.catalogVersion),(eq.catalog?.length || 0)+' 件 · Data Dragon '+(eq.catalogVersion || '版本待补')+' · CommunityDragon '+(eq.communityPatch || '版本待补')],
    ['上批持有率对照',enrich.previousHoldings==='pending'?'等待重试':stats.holdingBaseline?'已载入':'待可比样本',stats.holdingBaseline?windowLabel(stats.holdingBaseline):enrich.previousHoldings==='not-comparable'?'两批统计口径不同':'暂未取得可对照的上批数据'],
    ['技能强化对应关系',augmentSkillBook?.patch===target && spellTraitsBook?.patch===target?'已载入':'待同版核实','关系表 '+(augmentSkillBook?.patch || '待补')+' · 技能标签 '+(spellTraitsBook?.patch || '待补')],
    ['两种大乱斗的英雄平衡',official?.balancePending || Object.values(snapshot?.modes || {}).some(m=>m.status!=='ready')?'等待重试':snapshot?'按英雄查证据':'等待同版资料','客户端 '+(target || '待确认')+' · 腾讯英雄平衡公告 '+notices.length+' 篇 · 海克斯 '+Object.keys(snapshot?.modes?.mayhem?.byHero || {}).length+' 位，极地 '+Object.keys(snapshot?.modes?.aram?.byHero || {}).length+' 位有数值'],
    ['逐英雄供选规则',rules?'已载入':'待规则源',rules?rules+' 位英雄有具名来源 · '+official.heroPool.patch:'已取得的实战持有记录可在英雄页查看'],
    ['ARAMGG 国服英雄榜',gg?.catalog?windowState(gg.catalog):'等待授权样本',gg?.catalog?gg.catalog.version:'公开清单 '+(browserManifest?.version || gg?.config?.version || '待核对')+' · 尚未取得英雄榜'],
    ['海克斯同局场数','按英雄查询','详情页逐次核对版本、地区、组合和场数']
  ];
  return rows;
}
function renderCoverage(){
  const list=$('coverage-list');
  if(!list)return;
  const html=syncCoverageRows().map(([name,status,detail])=>'<div><dt>'+esc(name)+'</dt><dd><b>'+esc(status)+'</b><small>'+esc(detail)+'</small></dd></div>').join('');
  if(list.innerHTML!==html)list.innerHTML=html;
}
function showSyncReceipt(){
  const el=$('game-sync-receipt');
  const rows=syncCoverageRows();
  const issues=rows.filter(([,status])=>/重试|未核实|等待正文/.test(status));
  const historical=rows.filter(([,status])=>status==='历史样本');
  const msg=navigator.onLine===false?'当前离线，已保留可查资料。':
    '本次检查 '+date(Date.now())+' · 国服公告 '+(official?.patch || '待取得')+' · 英雄样本 '+stats.patch+'（批次 '+stats.seq+'）。';
  el.innerHTML=esc(msg)+(issues.length?' '+esc(issues.map(r=>r[0]).join('、'))+'需重试。':'')+
    (historical.length?' '+esc(historical.map(r=>r[0]).join('、'))+'仍为历史样本。':'')+' <a href="#sync-status" data-coverage-link>查看逐项结果 ↓</a>';
  el.hidden=false;
}
document.addEventListener('click',event=>{
  if(event.target.closest('[data-coverage-link]')){
    event.preventDefault();
    const panel=$('sync-status');panel.open=true;panel.scrollIntoView({block:'start'});panel.querySelector('summary')?.focus({preventScroll:true});
  }
});
