'use strict';
const patchKinds={all:'全部',buff:'增强',nerf:'削弱',adjust:'调整',new:'新增',fix:'修复',other:'其他'};
const patchView={filter:'all',query:'',page:0,version:''};
const poolView={hero:'',tab:'',query:'',rarity:'all',page:0};
function poolParams(id){
  const params=new URLSearchParams({hero:id,view:'pool'});
  if(poolView.hero!==id)return params;
  if(poolView.tab)params.set('group',poolView.tab);
  if(poolView.query)params.set('q',poolView.query);
  if(poolView.rarity!=='all')params.set('tier',poolView.rarity);
  if(poolView.page)params.set('page',String(poolView.page+1));
  return params;
}
function restorePool(id,params){
  const group=params.get('group'),tier=params.get('tier'),page=Number(params.get('page'));
  Object.assign(poolView,{hero:id,tab:['held','allowed','blocked','notices','interactions'].includes(group)?group:'',
    query:(params.get('q') || '').slice(0,100),rarity:['silver','gold','prismatic'].includes(tier)?tier:'all',
    page:Number.isSafeInteger(page) && page>0?page-1:0});
}
function savePoolLocation(){
  setAtlasRoute('replaceState',history.state,'',heroQuery(poolParams(profile.id)));
}
function pageButtons(page,total,key){
  const max=Math.max(1,Math.ceil(total/PAGE_SIZE));
  return '<div class="game-pages"><span>'+count(total)+' 项 · 每页 20 项</span><button type="button" data-'+key+'="-1" '+(page===0?'disabled':'')+'>上一页</button><span>'+(page+1)+' / '+max+'</span><button type="button" data-'+key+'="1" '+(page+1>=max?'disabled':'')+'>下一页</button></div>';
}
function patchEntries(o) {
  const notes=o?.mayhem;
  if(!notes || notes.patch!==o.patch || notes.samplePatch!==o.samplePatch || notes.url!==o.url)return [];
  const rows=notes.entries.map(entry=>({...entry,url:o.url,publishedAt:o.publishedAt,hotfix:false}));
  for(const doc of notes.hotfixDetails || []){
    if(o.hotfixes.some(h=>h.url===doc.url))rows.push(...doc.entries.map(entry=>({...entry,url:doc.url,publishedAt:doc.publishedAt,hotfix:true})));
  }
  return rows;
}
function searchText(s){return String(s ?? '').normalize('NFKC').toLocaleLowerCase().replace(/\s+/gu,'');}
function filterPatchEntries(rows,kind,query) {
  const terms=query.trim().split(/\s+/u).filter(Boolean).map(searchText);
  return rows.filter(e=>{
    if(kind!=='all' && kind!==e.kind)return false;
    const fields=[e.name,e.category,...e.details,e.hotfix?'热修':'主公告'].map(searchText);
    return terms.every(term=>fields.some(s=>s.includes(term)));
  });
}
function patchSubjectBody(category,name){
  if(!official || !name)return '';
  const key=searchText(name);
  const matches=patchEntries(official).filter(e=>{
    if(searchText(e.name)!==key)return false;
    if(e.category===category)return true;
    if(!/修复/i.test(e.category))return false;
    const groups=[
      ['英雄',stats.heroes],['装备',stats.equipment?.catalog || []],
      ['强化符文',Object.values(augmentBook.byId || {}).concat(stats.augments)]
    ].filter(([,group])=>group.some(x=>searchText(x.name)===key));
    return groups.length===1 && groups[0][0]===category;
  });
  return matches.length?'<div class="subject-patch"><h3>国服 '+esc(official.patch)+' · '+esc(name)+'改动</h3>'+
    matches.map(e=>'<div><b>'+esc(patchKinds[e.kind])+'</b> '+e.details.map(esc).join('<br>')+'<small>'+
      external(e.url,e.hotfix?'腾讯热修原文':'腾讯版本公告')+' · '+esc(date(e.publishedAt))+'（北京时间）</small></div>').join('')+'</div>':'';
}
function subjectNotes(category,name){
  return '<div data-note-category="'+esc(category)+'" data-note-name="'+esc(name)+'">'+patchSubjectBody(category,name)+'</div>';
}
function refreshSubjectNotes(){
  document.querySelectorAll('[data-note-category]').forEach(el=>{
    const body=patchSubjectBody(el.dataset.noteCategory,el.dataset.noteName);
    if(el.innerHTML!==body)el.innerHTML=body;
  });
}
function renderGameNotes(){
  if(!official || !stats)return;
  const o=official, entries=patchEntries(o);
  if(patchView.version!==o.patch){patchView.version=o.patch;patchView.page=0;}
  $('game-patch-title').textContent=o.patch+' 海克斯大乱斗更新';
  const status=health.official.stale?'本次公告未能核实最新状态。':'';
  const samplePatch=leadingGG()?gg.catalog.patch:stats.patch;
  const sampleLabel=samplePatch===o.samplePatch?'国服英雄榜已对齐':'新版英雄样本待发布，当前英雄榜 '+samplePatch;
  $('game-patch-meta').textContent='腾讯国服 · '+date(o.publishedAt)+' 发布 · 客户端 '+o.samplePatch+' · '+sampleLabel;
  const direct=o.newsChannel==='direct';
  const info=direct?'本机最近直连核对腾讯目录 · '+date(o.directoryAt):o.newsChannel==='mirror'?'本次未能直连腾讯目录，使用公告镜像':o.newsChannel==='directory-behind'?'腾讯目录较早，保留已核实公告':'腾讯国服公告';
  const details=o.detailCheckedAt===undefined?o.checkedAt:o.detailCheckedAt;
  $('game-patch-check').textContent=status+info+' · 改动明细采集 '+(details?date(details):'等待正文')+' · AramHex 对局样本 '+stats.patch+'，截至 '+date(stats.cutoff)+'（北京时间）';
  if(o.directoryPending){
    const a=document.createElement('a');a.href=o.directoryPending.url;a.target='_blank';a.rel='noopener';
    a.textContent=o.directoryPending.title+' · '+date(o.directoryPending.publishedAt)+' 发布，版本号待正文确认';
    $('game-patch-check').prepend(a,' ｜ ');
  }
  const chips=$('patch-filters');
  const badges=Object.entries(patchKinds).map(([key,name])=>{
    const total=key==='all'?entries.length:entries.filter(e=>e.kind===key).length;
    return total || key===patchView.filter?'<button type="button" class="patch-chip '+key+'" data-patch-filter="'+key+'" aria-pressed="'+(patchView.filter===key)+'">'+name+' <b>'+total+'</b></button>':'';
  }).join('');
  if(chips.innerHTML!==badges)chips.innerHTML=badges;
  const filtered=filterPatchEntries(entries,patchView.filter,patchView.query);
  patchView.page=Math.max(0,Math.min(patchView.page,Math.ceil(filtered.length/PAGE_SIZE)-1));
  const rows=filtered.slice(patchView.page*PAGE_SIZE,(patchView.page+1)*PAGE_SIZE).map(e=>'<li><span class="patch-class '+esc(e.kind)+'">'+esc(patchKinds[e.kind])+'</span><div><strong>'+esc(e.name)+'</strong> <small>'+esc(e.category)+'</small>'+e.details.map(s=>'<p>'+esc(s)+'</p>').join('')+'<small>分类依据 · '+esc(e.basis)+(e.hotfix?' · '+external(e.url,'腾讯热修')+' · '+esc(date(e.publishedAt)):'')+'</small></div></li>').join('');
  $('patch-count').textContent='查到 '+filtered.length+' 条，共 '+entries.length+' 条';
  $('patch-reset').hidden=!patchView.query && patchView.filter==='all';
  let body=o.notesPending?(o.detailCheckedAt===null?'<p>已发现新版公告，可直接打开腾讯原文。海克斯改动明细将在采集后补齐。</p>':'<p>本次正文解析未完成，可查看腾讯原文。</p>'):'';
  if(o.hotfixesAvailable===false)body+='<p>热修目录本次未能核实。下次同步会重试。</p>';
  if(o.mayhem?.pendingHotfixes?.length)body+='<p>'+o.mayhem.pendingHotfixes.length+' 篇热修正文待核实。可展开下方原文查看。</p>';
  if(rows)body+='<ul class="patch-list">'+rows+'</ul>'+pageButtons(patchView.page,filtered.length,'patch-page');
  else body+='<p>'+(!entries.length?'本版暂未取得可核实的模式改动条目，可查阅腾讯原文。':'没有匹配的改动。可更换关键词，或清除筛选查看本版全部改动。')+'</p>';
  if(o.hotfixes?.length)body+='<details class="hotfix-sources"><summary>本期国服热修原文（'+o.hotfixes.length+' 篇）</summary>'+o.hotfixes.map(h=>'<p>'+external(h.url,h.title)+' · '+esc(date(h.publishedAt))+(o.mayhem?.pendingHotfixes?.includes(h.url)?' · 正文待重试':'')+'</p>').join('')+'</details>';
  const target=$('game-note-list');if(target.innerHTML!==body)target.innerHTML=body;
  $('game-note-toggle').textContent='查看改动详情'+(entries.length?'（'+entries.length+' 条）':'');
  $('game-original').href=o.url;
}
// Tencent has used abbreviated names and alternate spellings in dated articles.
const noticeHeroIds={'努努':'20','烈娜塔':'888','卡莉斯塔':'429','奥瑞利安·索尔':'136','塔姆·肯奇':'223'};
function offerNoticeRows(hero,field='offerChanges'){
  return (official?.history || []).flatMap(doc=>(doc[field] || []).filter(r=>r.hero===hero.name || noticeHeroIds[r.hero]===hero.id)
    .map(r=>({...r,patch:doc.patch,publishedAt:doc.publishedAt,url:doc.url})));
}
function samePatchOfferRules(feed,heroPool,notices){
  const latest=new Map();
  function add(rule,at){
    const time=Date.parse(at), old=latest.get(rule.augmentId);
    if(!Number.isFinite(time) || (old && old.time>time))return;
    if(old?.time===time && old.rule?.state!==rule.state){latest.set(rule.augmentId,{time,rule:null});return;}
    latest.set(rule.augmentId,{time,rule});
  }
  for(const rule of heroPool?.rows || [])add({...rule,publishedAt:feed.publishedAt},feed.publishedAt);
  if(augmentBook.patch===official?.samplePatch){
    const names=new Map();
    for(const [id,a] of Object.entries(augmentBook.byId || {}))names.set(a.name,names.has(a.name)?null:id);
    for(const note of notices){
      const id=names.get(note.augment);
      if(!id || note.patch!==official.patch || note.skill)continue;
      add({augmentId:id,name:note.augment,state:note.state==='added'?'allowed':'blocked',detail:offerRuleText(note),
        source:{name:'腾讯供选公告',url:note.url},publishedAt:note.publishedAt},note.publishedAt);
    }
  }
  return [...latest.values()].map(v=>v.rule).filter(Boolean);
}
function offerRuleText(r){
  return (r.skill?r.hero+' · '+r.skill:r.hero+'（英雄整体）')+' · '+(r.state==='removed'?'移出供选':'加入供选');
}
function noticeSkillLabel(hero,r){
  if(r.patch!==official?.patch || !championBook.version?.startsWith(official.samplePatch+'.'))return r.skill;
  const skill=championBook.byId?.[hero.id]?.skills?.find(s=>s.slot===r.skill || s.name===r.skill || s.name.split(' / ').includes(r.skill));
  return skill?skill.slot+' · '+skill.name:r.skill;
}
function noticePool(hero,notices,tabs,interactions=false){
  const q=searchText(poolView.query);
  const rows=notices.filter(r=>[r.augment,r.patch,interactions?noticeSkillLabel(hero,r):offerRuleText(r),r.line].some(s=>normalizedAugmentQuery(searchText(s)).includes(normalizedAugmentQuery(q))));
  poolView.page=Math.max(0,Math.min(poolView.page,Math.ceil(rows.length/PAGE_SIZE)-1));
  const entries=rows.slice(poolView.page*PAGE_SIZE,(poolView.page+1)*PAGE_SIZE).map(r=>{
    const same=r.patch===official.patch && augmentBook.patch===official.samplePatch;
    const a=same && Object.entries(augmentBook.byId || {}).find(([,v])=>v.name===r.augment);
    return '<li>'+(a?augmentIcon({...a[1],id:a[0]}):'')+'<div><strong>'+esc(r.augment)+'</strong><p>'+(interactions?esc(noticeSkillLabel(hero,r))+'</p><p>'+esc(r.line):esc(offerRuleText(r)))+'</p><small>'+
      (r.patch===official.patch?'本版公告':'历史公告')+' · 国服 '+esc(r.patch)+' · '+esc(date(r.publishedAt))+'（北京时间） · '+external(r.url,'腾讯原文')+'</small></div></li>';
  }).join('');
  return tabs+'<p class="pool-meta">国服 '+esc(official.patch)+(interactions?' · 腾讯公告记载的技能交互与修复。':' · 腾讯逐条说明的供选变更。')+
    (notices.some(r=>r.patch===official.patch)?'':'该英雄暂无本版具名记录。')+'历史条目保留公告当时的键位、形态或技能段数。</p>'+
    '<label class="pool-search">搜索公告记录 <input type="search" id="pool-search" value="'+esc(poolView.query)+'" placeholder="强化名、键位或版本" maxlength="100"></label>'+
    '<div id="pool-results">'+(entries?'<ul class="pool-list">'+entries+'</ul>':'<p>没有匹配的公告记录。</p>')+pageButtons(poolView.page,rows.length,'pool-page')+'</div>';
}
function renderPool(hero,sample){
  const patch=official?.samplePatch, feed=official?.heroPool?.patch===patch?official.heroPool:null;
  const pool=feed?.heroes?.[hero.id];
  const notices=offerNoticeRows(hero), rules=samePatchOfferRules(feed,pool,notices);
  const allowed=rules.filter(r=>r.state==='allowed'),blocked=rules.filter(r=>r.state==='blocked');
  const holds=Object.entries(sample?.augmentCounts || {}).filter(([,n])=>n>0).sort((a,b)=>b[1]-a[1]);
  if(poolView.hero!==hero.id)restorePool(hero.id,new URLSearchParams());
  if(!poolView.tab)poolView.tab=allowed.length?'allowed':'held';
  const interactions=offerNoticeRows(hero,'skillInteractions');
  const tabs={interactions:['腾讯技能交互',interactions.length],notices:['腾讯供选变更',notices.length],allowed:['已证实可选',allowed.length],held:['结算持有记录',holds.length],blocked:['明确禁选',blocked.length]};
  const tab=poolView.tab;
  const caption=pool?.complete?'来源已发布该英雄的完整供选表。':pool?'来源已发布部分逐条规则，其余强化供选状态待核实。':'本版尚无该英雄的完整供选表。具名的公告调整可在「腾讯供选变更」查看。';
  const summary='<div class="pool-caption"><strong>国服 '+esc(official?.patch)+' · 客户端 '+esc(patch)+'</strong><p>'+caption+'</p>'+
    (official?.poolPending?'<p>本次规则更新未通过核验，保留同版本已取得的记录。</p>':'')+
    (feed?'<small>'+external(feed.source.url,feed.source.name)+' · '+date(feed.publishedAt)+'</small>':'')+
    (pool?.coverageSource?'<p>'+external(pool.coverageSource.url,pool.coverageSource.name)+'</p>':'')+'</div>';
  const tabBar='<div class="pool-tabs">'+Object.entries(tabs).map(([key,[name,total]])=>'<button type="button" data-pool-tab="'+key+'" aria-pressed="'+(tab===key)+'">'+name+(key==='held' || total?' '+count(total):'')+'</button>').join('')+'</div>';
  const disabled=Object.entries(augmentBook.byId || {}).filter(([,a])=>a.modeDisabled);
  const modeNote=disabled.length?'<details class="pool-caption"><summary>模式文件标记停用 · '+esc(augmentBook.patch)+'（'+disabled.length+' 枚）</summary><p>'+
    disabled.map(([id,a])=>augmentIcon({...a,id})+' '+esc(a.name)).join('、')+'</p><small>'+external(augmentBook.sources?.kiwi,'CommunityDragon 对应版本模式文件')+
    ' · 此项适用于模式资料，国服逐英雄规则请查腾讯公告。</small></details>':'';
  if(tab==='interactions')return summary+noticePool(hero,interactions,tabBar,true)+modeNote;
  if(tab==='notices')return summary+noticePool(hero,notices,tabBar)+modeNote;
  const rows=tab==='held'?holds.map(([id,n])=>({id,n})): (tab==='allowed'?allowed:blocked).map(rule=>({id:rule.augmentId,rule}));
  const sameBook=tab==='held' || augmentBook.patch===patch;
  const prepared=rows.map(r=>{const a=augmentBook.byId?.[r.id] || augmentMap.get(r.id) || {};
    const skill=sameBook?poolSkillSummary(r.id,hero.id):'';
    return {...r,skill,a:{...a,id:r.id,name:r.rule?.name || a.name || '强化 '+r.id,rarity:a.rarity || 'unknown'}};})
     .filter(r=>(poolView.rarity==='all' || r.a.rarity===poolView.rarity) &&
      [r.a.name,r.id,r.rule?.detail,r.skill].some(s=>normalizedAugmentQuery(searchText(s)).includes(normalizedAugmentQuery(searchText(poolView.query)))));
  poolView.page=Math.max(0,Math.min(poolView.page,Math.ceil(prepared.length/PAGE_SIZE)-1));
  const cards=prepared.slice(poolView.page*PAGE_SIZE,(poolView.page+1)*PAGE_SIZE).map(({id,n,a,rule,skill})=>
    '<li>'+(rule?.icon?imageFallback(rule.icon,a.name.slice(0,1)):augmentIcon(a))+'<div><strong>'+esc(a.name)+'</strong> '+(a.rarity!=='unknown'?label(a):'')+
    (rule?'<p>'+esc(rule.detail)+'</p>'+(!sameBook && !rule.name?'<small>名称参考 '+esc(stats.patch)+' 图鉴 · ID '+esc(id)+'</small><br>':'')+'<small>'+external(rule.source.url,rule.source.name)+' · '+esc(date(rule.publishedAt))+'（北京时间）</small>':'<p>'+count(n)+' 持有人次 · 英雄持有率 '+pct(n/sample.games*100)+'</p>')+
    (skill?'<small>'+esc(skill)+'</small>':'')+'</div>'+(n?'<button type="button" data-open-augment="'+id+'">强化详情</button>':'')+'</li>').join('');
  const empty=poolView.query || poolView.rarity!=='all'?'没有匹配的强化。':tab==='held'?'这个样本中尚无该英雄的结算持有记录。':tab==='allowed'?'尚无可列出的已证实可选条目。':'尚无来源明确指出本版禁选的条目。';
  return summary+tabBar+
    '<p class="pool-meta">'+(tab==='held'?'AramHex 国服普通模式 · '+metaLine(stats)+' · '+esc(hero.name)+'出场 '+count(sample?.games)+' 人次。结算持有包括转化、赠予等获取方式。':('供选规则按客户端 '+esc(patch)+' 核对。'))+'</p>'+
    '<label class="pool-search">搜索本栏强化 <input type="search" id="pool-search" value="'+esc(poolView.query)+'" maxlength="100" placeholder="强化名、技能名或 ID"></label><label class="pool-tier">品质 <select id="pool-rarity">'+
    Object.entries({all:'全部品质',silver:'白银',gold:'黄金',prismatic:'棱彩'}).map(([k,v])=>'<option value="'+k+'" '+(poolView.rarity===k?'selected':'')+'>'+v+'</option>').join('')+'</select></label>'+
    '<div id="pool-results">'+(cards?'<ul class="pool-list">'+cards+'</ul>':'<p class="pool-empty">'+empty+'</p>')+pageButtons(poolView.page,prepared.length,'pool-page')+'</div>'+
    '<p class="pool-link"><a href="?tab=augments" data-global-augments>查看全局海克斯图鉴 →</a></p>'+modeNote;
}
document.addEventListener('click',e=>{
  const t=e.target.closest('button,a');if(!t || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey)return;
  if(t.id==='game-sync'){void refresh(true);return;}
  if(t.id==='patch-reset'){
    patchView.query='';patchView.filter='all';patchView.page=0;$('patch-search').value='';renderGameNotes();$('patch-search').focus();
  }
  if(t.dataset.patchFilter || t.dataset.patchPage){
    if(t.dataset.patchFilter){patchView.filter=t.dataset.patchFilter;patchView.page=0;}else patchView.page+=Number(t.dataset.patchPage);
    $('game-note-details').open=true;renderGameNotes();
    if(t.dataset.patchPage)$('patch-count').focus();
    else $('patch-filters').querySelector('[aria-pressed="true"]')?.focus({preventScroll:true});
  }
  if(t.dataset.poolTab || t.dataset.poolPage){
    if(t.dataset.poolTab){poolView.tab=t.dataset.poolTab;poolView.page=0;poolView.query='';poolView.rarity='all';}else poolView.page+=Number(t.dataset.poolPage);
    renderProfile();savePoolLocation();$('detail').querySelector('[data-pool-tab="'+poolView.tab+'"]')?.focus({preventScroll:true});
  }
  if(t.hasAttribute('data-global-augments')){
    e.preventDefault();setAtlasRoute('pushState',null,'','?tab=augments');restoreLocation();
  }
});
document.addEventListener('input',e=>{
  if(e.target.id==='patch-search'){patchView.query=e.target.value;patchView.page=0;renderGameNotes();return;}
  if(e.target.id!=='pool-search')return;
  poolView.query=e.target.value;poolView.page=0;
  const {hero,sample}=heroRecord(profile.id);
  const template=document.createElement('template');
  template.innerHTML=renderPool(hero,sample);
  $('pool-results').replaceChildren(...template.content.querySelector('#pool-results').childNodes);
  savePoolLocation();
});

document.addEventListener('change',e=>{
  if(e.target.id!=='pool-rarity')return;
  poolView.rarity=e.target.value;poolView.page=0;renderProfile();savePoolLocation();$('pool-rarity').focus({preventScroll:true});
});

let newsPage=0;
function openPatchArchive(page=0,article='',entryPage=0){
  if(!official)return showDialog('国服版本公告','<p>正在读取公告。</p>');
  const docs=official.history || [];
  newsPage=Math.max(0,Math.min(page,Math.ceil(docs.length/PAGE_SIZE)-1));
  const doc=docs.find(d=>d.url===article);
  if(doc){
    const entries=[...(doc.entries || []),...(doc.offerChanges || []).map(r=>({name:r.augment,category:'供选变更',details:[offerRuleText(r)]}))];
    entryPage=Math.max(0,Math.min(entryPage,Math.ceil(entries.length/PAGE_SIZE)-1));
    const rows=entries.slice(entryPage*PAGE_SIZE,(entryPage+1)*PAGE_SIZE).map(e=>'<li><b>'+esc(e.name)+'</b> · '+esc(patchKinds[e.kind] || e.category)+e.details.map(x=>'<p>'+esc(x)+'</p>').join('')+'</li>').join('');
    showDialog(doc.title,'<div data-article-url="'+esc(doc.url)+'" data-entry-page="'+entryPage+'"><button type="button" data-news-back>返回公告列表</button><p>腾讯国服 '+esc(doc.patch)+' · '+esc(date(doc.publishedAt))+' 发布（北京时间） · '+external(doc.url,'腾讯原文')+'</p>'+
      (rows?'<h3>海克斯大乱斗改动</h3><ul class="archive-entries">'+rows+'</ul>'+pageButtons(entryPage,entries.length,'entry-page'):'<p>本地暂无可列出的海克斯分项改动，可查看腾讯原文。</p>')+'</div>');
    return;
  }
  const rows=docs.slice(newsPage*PAGE_SIZE,(newsPage+1)*PAGE_SIZE).map(d=>'<li><button type="button" data-news-url="'+esc(d.url)+'"><b>'+esc(d.patch)+(d.hotfix?' · 热修':'')+'</b><span>'+esc(d.title)+'</span><small>'+esc(date(d.publishedAt))+'</small></button></li>').join('');
  showDialog('腾讯国服版本公告',newsBody()+'<h3>历史公告 · 北京时间</h3><ul class="archive-docs">'+rows+'</ul>'+pageButtons(newsPage,docs.length,'news-page'));
}
document.addEventListener('click',e=>{
  const b=e.target.closest('#dialog button');
  if(!b)return;
  if(b.dataset.newsUrl)openPatchArchive(newsPage,b.dataset.newsUrl);
  else if(b.hasAttribute('data-news-back'))openPatchArchive(newsPage);
  else if(b.dataset.newsPage)openPatchArchive(newsPage+Number(b.dataset.newsPage));
  else if(b.dataset.entryPage){const d=b.closest('[data-article-url]').dataset;openPatchArchive(newsPage,d.articleUrl,Number(d.entryPage)+Number(b.dataset.entryPage));}
});
