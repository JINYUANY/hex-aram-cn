'use strict';
const patchKinds={all:'全部',buff:'增强',nerf:'削弱',adjust:'调整',new:'新增',fix:'修复',other:'其他'};
const patchView={filter:'all',query:'',page:0,version:''};
const poolView={hero:'',tab:'',query:'',rarity:'all',page:0};
function poolParams(id){
  const params=new URLSearchParams({hero:id,view:'pool'});
  if(poolView.hero!==id)return params;
  if(poolView.tab)params.set('group',poolView.tab);
  if(poolView.query)params.set('q',poolView.query);
  if(poolView.rarity!=='all')params.set('tier',poolView.rarity);
  if(poolView.page)params.set('page',String(poolView.page+1));
  return params;
}
function restorePool(id,params){
  const group=params.get('group'),tier=params.get('tier'),page=Number(params.get('page'));
  Object.assign(poolView,{hero:id,tab:['held','allowed','blocked'].includes(group)?group:'',
    query:(params.get('q') || '').slice(0,100),rarity:['silver','gold','prismatic'].includes(tier)?tier:'all',
    page:Number.isSafeInteger(page) && page>0?page-1:0});
}
function savePoolLocation(){
  setAtlasRoute('replaceState',history.state,'',heroQuery(poolParams(profile.id)));
}
function pageButtons(page,total,key){
  const max=Math.max(1,Math.ceil(total/PAGE_SIZE));
  return '<div class="game-pages"><span>'+count(total)+' 项 · 每页 20 项</span><button type="button" data-'+key+'="-1" '+(page===0?'disabled':'')+'>上一页</button><span>'+(page+1)+' / '+max+'</span><button type="button" data-'+key+'="1" '+(page+1>=max?'disabled':'')+'>下一页</button></div>';
}
function patchEntries(o) {
  const notes=o?.mayhem;
  if(!notes || notes.patch!==o.patch || notes.samplePatch!==o.samplePatch || notes.url!==o.url)return [];
  const rows=notes.entries.map(entry=>({...entry,url:o.url,publishedAt:o.publishedAt,hotfix:false}));
  for(const doc of notes.hotfixDetails || []){
    if(o.hotfixes.some(h=>h.url===doc.url))rows.push(...doc.entries.map(entry=>({...entry,url:doc.url,publishedAt:doc.publishedAt,hotfix:true})));
  }
  return rows;
}
function searchText(s){return String(s ?? '').normalize('NFKC').toLocaleLowerCase().replace(/\s+/gu,'');}
function filterPatchEntries(rows,kind,query) {
  const terms=query.trim().split(/\s+/u).filter(Boolean).map(searchText);
  return rows.filter(e=>{
    if(kind!=='all' && kind!==e.kind)return false;
    const fields=[e.name,e.category,...e.details,e.hotfix?'热修':'主公告'].map(searchText);
    return terms.every(term=>fields.some(s=>s.includes(term)));
  });
}
function patchSubjectBody(category,name){
  if(!official || !name)return '';
  const key=searchText(name);
  const matches=patchEntries(official).filter(e=>{
    if(searchText(e.name)!==key)return false;
    if(e.category===category)return true;
    if(!/修复/i.test(e.category))return false;
    const groups=[
      ['英雄',stats.heroes],['装备',stats.equipment?.catalog || []],
      ['强化符文',Object.values(augmentBook.byId || {}).concat(stats.augments)]
    ].filter(([,group])=>group.some(x=>searchText(x.name)===key));
    return groups.length===1 && groups[0][0]===category;
  });
  return matches.length?'<div class="subject-patch"><h3>国服 '+esc(official.patch)+' · '+esc(name)+'改动</h3>'+
    matches.map(e=>'<div><b>'+esc(patchKinds[e.kind])+'</b> '+e.details.map(esc).join('<br>')+'<small>'+
      external(e.url,e.hotfix?'腾讯热修原文':'腾讯版本公告')+' · '+esc(date(e.publishedAt))+'（北京时间）</small></div>').join('')+'</div>':'';
}
function subjectNotes(category,name){
  return '<div data-note-category="'+esc(category)+'" data-note-name="'+esc(name)+'">'+patchSubjectBody(category,name)+'</div>';
}
function refreshSubjectNotes(){
  document.querySelectorAll('[data-note-category]').forEach(el=>{
    const body=patchSubjectBody(el.dataset.noteCategory,el.dataset.noteName);
    if(el.innerHTML!==body)el.innerHTML=body;
  });
}
function renderGameNotes(){
  if(!official || !stats)return;
  const o=official, entries=patchEntries(o);
  if(patchView.version!==o.patch){patchView.version=o.patch;patchView.page=0;}
  $('game-patch-title').textContent=o.patch+' 海克斯大乱斗更新';
  const status=health.official.stale?'本次公告未能核实最新状态。':'';
  const samplePatch=leadingGG()?gg.catalog.patch:stats.patch;
  const sampleLabel=samplePatch===o.samplePatch?'国服英雄榜已对齐':'当前英雄榜 '+samplePatch;
  $('game-patch-meta').textContent='腾讯国服 · '+date(o.publishedAt)+' 发布 · 客户端 '+o.samplePatch+' · '+sampleLabel;
  $('game-patch-check').textContent=status+' 腾讯公告最近成功采集 '+(o.checkedAt?date(o.checkedAt):'尚无记录')+'（北京时间）';
  const chips=$('patch-filters');
  const badges=Object.entries(patchKinds).map(([key,name])=>{
    const total=key==='all'?entries.length:entries.filter(e=>e.kind===key).length;
    return total || key===patchView.filter?'<button type="button" class="patch-chip '+key+'" data-patch-filter="'+key+'" aria-pressed="'+(patchView.filter===key)+'">'+name+' <b>'+total+'</b></button>':'';
  }).join('');
  if(chips.innerHTML!==badges)chips.innerHTML=badges;
  const filtered=filterPatchEntries(entries,patchView.filter,patchView.query);
  patchView.page=Math.max(0,Math.min(patchView.page,Math.ceil(filtered.length/PAGE_SIZE)-1));
  const rows=filtered.slice(patchView.page*PAGE_SIZE,(patchView.page+1)*PAGE_SIZE).map(e=>'<li><span class="patch-class '+esc(e.kind)+'">'+esc(patchKinds[e.kind])+'</span><div><strong>'+esc(e.name)+'</strong> <small>'+esc(e.category)+'</small>'+e.details.map(s=>'<p>'+esc(s)+'</p>').join('')+'<small>分类依据 · '+esc(e.basis)+(e.hotfix?' · '+external(e.url,'腾讯热修')+' · '+esc(date(e.publishedAt)):'')+'</small></div></li>').join('');
  $('patch-count').textContent='查到 '+filtered.length+' 条，共 '+entries.length+' 条';
  $('patch-reset').hidden=!patchView.query && patchView.filter==='all';
  let body=o.notesPending?'<p>本次正文解析未完成，可查看腾讯原文。</p>':'';
  if(o.hotfixesAvailable===false)body+='<p>热修目录本次未能核实。下次同步会重试。</p>';
  if(o.mayhem?.pendingHotfixes?.length)body+='<p>'+o.mayhem.pendingHotfixes.length+' 篇热修正文待核实。可展开下方原文查看。</p>';
  if(rows)body+='<ul class="patch-list">'+rows+'</ul>'+pageButtons(patchView.page,filtered.length,'patch-page');
  else body+='<p>'+(!entries.length?'本版暂未取得可核实的模式改动条目，可查阅腾讯原文。':'没有匹配的改动。可更换关键词，或清除筛选查看本版全部改动。')+'</p>';
  if(o.hotfixes?.length)body+='<details class="hotfix-sources"><summary>本期国服热修原文（'+o.hotfixes.length+' 篇）</summary>'+o.hotfixes.map(h=>'<p>'+external(h.url,h.title)+' · '+esc(date(h.publishedAt))+(o.mayhem?.pendingHotfixes?.includes(h.url)?' · 正文待重试':'')+'</p>').join('')+'</details>';
  const target=$('game-note-list');if(target.innerHTML!==body)target.innerHTML=body;
  $('game-note-toggle').textContent='查看改动详情'+(entries.length?'（'+entries.length+' 条）':'');
  $('game-original').href=o.url;
}
function renderPool(hero,sample){
  const patch=official?.samplePatch, feed=official?.heroPool?.patch===patch?official.heroPool:null;
  const pool=feed?.heroes?.[hero.id];
  const allowed=pool?.rows.filter(r=>r.state==='allowed') || [],blocked=pool?.rows.filter(r=>r.state==='blocked') || [];
  const holds=Object.entries(sample?.augmentCounts || {}).filter(([,n])=>n>0).sort((a,b)=>b[1]-a[1]);
  if(poolView.hero!==hero.id)restorePool(hero.id,new URLSearchParams());
  if(!poolView.tab)poolView.tab=allowed.length?'allowed':'held';
  const tabs={allowed:['已证实可选',allowed.length],held:['结算持有记录',holds.length],blocked:['明确禁选',blocked.length]};
  const tab=poolView.tab;
  const caption=pool?.complete?'来源已发布该英雄的完整供选表。':pool?'来源已发布部分逐条规则，其余强化供选状态待核实。':'本版尚无该英雄的完整供选表，也未取得逐条供选规则。';
  const summary='<div class="pool-caption"><strong>国服 '+esc(official?.patch)+' · 客户端 '+esc(patch)+'</strong><p>'+caption+'</p>'+
    (official?.poolPending?'<p>本次规则更新未通过核验，保留同版本已取得的记录。</p>':'')+
    (feed?'<small>'+external(feed.source.url,feed.source.name)+' · '+date(feed.publishedAt)+'</small>':'')+
    (pool?.coverageSource?'<p>'+external(pool.coverageSource.url,pool.coverageSource.name)+'</p>':'')+'</div>';
  const rows=tab==='held'?holds.map(([id,n])=>({id,n})): (tab==='allowed'?allowed:blocked).map(rule=>({id:rule.augmentId,rule}));
  const sameBook=tab==='held' || augmentBook.patch===patch;
  const prepared=rows.map(r=>{const a=augmentBook.byId?.[r.id] || augmentMap.get(r.id) || {};
    return {...r,a:{...a,id:r.id,name:r.rule?.name || a.name || '强化 '+r.id,rarity:a.rarity || 'unknown'}};})
     .filter(r=>(poolView.rarity==='all' || r.a.rarity===poolView.rarity) &&
      [r.a.name,r.id,r.rule?.detail].some(s=>searchText(s).includes(searchText(poolView.query))));
  poolView.page=Math.max(0,Math.min(poolView.page,Math.ceil(prepared.length/PAGE_SIZE)-1));
  const cards=prepared.slice(poolView.page*PAGE_SIZE,(poolView.page+1)*PAGE_SIZE).map(({id,n,a,rule})=>
    '<li>'+(rule?.icon?imageFallback(rule.icon,a.name.slice(0,1)):augmentIcon(a))+'<div><strong>'+esc(a.name)+'</strong> '+(a.rarity!=='unknown'?label(a):'')+
    (rule?'<p>'+esc(rule.detail)+'</p>'+(!sameBook && !rule.name?'<small>名称参考 '+esc(stats.patch)+' 图鉴 · ID '+esc(id)+'</small><br>':'')+'<small>'+external(rule.source.url,rule.source.name)+'</small>':'<p>'+count(n)+' 持有人次 · 英雄持有率 '+pct(n/sample.games*100)+'</p>')+
    '</div>'+(n?'<button type="button" data-open-augment="'+id+'">强化详情</button>':'')+'</li>').join('');
  const empty=poolView.query || poolView.rarity!=='all'?'没有匹配的强化。':tab==='held'?'这个样本中尚无该英雄的结算持有记录。':tab==='allowed'?'尚无可列出的已证实可选条目。':'尚无来源明确指出本版禁选的条目。';
  return summary+'<div class="pool-tabs">'+Object.entries(tabs).map(([key,[name,total]])=>'<button type="button" data-pool-tab="'+key+'" aria-pressed="'+(tab===key)+'">'+name+(key==='held' || total?' '+count(total):'')+'</button>').join('')+'</div>'+
    '<p class="pool-meta">'+(tab==='held'?'AramHex 国服普通模式 · '+metaLine(stats)+' · '+esc(hero.name)+'出场 '+count(sample?.games)+' 人次。结算持有包括转化、赠予等获取方式。':('供选规则按客户端 '+esc(patch)+' 核对。'))+'</p>'+
    '<label class="pool-search">搜索本栏强化 <input type="search" id="pool-search" value="'+esc(poolView.query)+'" maxlength="100" placeholder="名称或 ID"></label><label class="pool-tier">品质 <select id="pool-rarity">'+
    Object.entries({all:'全部品质',silver:'白银',gold:'黄金',prismatic:'棱彩'}).map(([k,v])=>'<option value="'+k+'" '+(poolView.rarity===k?'selected':'')+'>'+v+'</option>').join('')+'</select></label>'+
    '<div id="pool-results">'+(cards?'<ul class="pool-list">'+cards+'</ul>':'<p class="pool-empty">'+empty+'</p>')+pageButtons(poolView.page,prepared.length,'pool-page')+'</div>'+
    '<p class="pool-link"><a href="?tab=augments" data-global-augments>查看全局海克斯图鉴 →</a></p>';
}
document.addEventListener('click',e=>{
  const t=e.target.closest('button,a');if(!t || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey)return;
  if(t.id==='game-sync'){void refresh(true);return;}
  if(t.id==='patch-reset'){
    patchView.query='';patchView.filter='all';patchView.page=0;$('patch-search').value='';renderGameNotes();$('patch-search').focus();
  }
  if(t.dataset.patchFilter || t.dataset.patchPage){
    if(t.dataset.patchFilter){patchView.filter=t.dataset.patchFilter;patchView.page=0;}else patchView.page+=Number(t.dataset.patchPage);
    $('game-note-details').open=true;renderGameNotes();
    if(t.dataset.patchPage)$('patch-count').focus();
    else $('patch-filters').querySelector('[aria-pressed="true"]')?.focus({preventScroll:true});
  }
  if(t.dataset.poolTab || t.dataset.poolPage){
    if(t.dataset.poolTab){poolView.tab=t.dataset.poolTab;poolView.page=0;poolView.query='';poolView.rarity='all';}else poolView.page+=Number(t.dataset.poolPage);
    renderProfile();savePoolLocation();$('detail').querySelector('[data-pool-tab="'+poolView.tab+'"]')?.focus({preventScroll:true});
  }
  if(t.hasAttribute('data-global-augments')){
    e.preventDefault();setAtlasRoute('pushState',null,'','?tab=augments');restoreLocation();
  }
});
document.addEventListener('input',e=>{
  if(e.target.id==='patch-search'){patchView.query=e.target.value;patchView.page=0;renderGameNotes();return;}
  if(e.target.id!=='pool-search')return;
  poolView.query=e.target.value;poolView.page=0;
  const {hero,sample}=heroRecord(profile.id);
  const template=document.createElement('template');
  template.innerHTML=renderPool(hero,sample);
  $('pool-results').replaceChildren(...template.content.querySelector('#pool-results').childNodes);
  savePoolLocation();
});

document.addEventListener('change',e=>{
  if(e.target.id!=='pool-rarity')return;
  poolView.rarity=e.target.value;poolView.page=0;renderProfile();savePoolLocation();$('pool-rarity').focus({preventScroll:true});
});
