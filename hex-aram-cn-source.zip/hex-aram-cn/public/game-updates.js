'use strict';
const patchKinds={all:'全部',buff:'增强',nerf:'削弱',adjust:'调整',new:'新增',fix:'修复',other:'其他'};
const patchView={filter:'all',page:0,version:''};
const poolView={hero:'',tab:'',query:'',page:0};
function pageButtons(page,total,key){
  const max=Math.max(1,Math.ceil(total/PAGE_SIZE));
  return '<div class="game-pages"><span>'+count(total)+' 项 · 每页 20 项</span><button type="button" data-'+key+'="-1" '+(page===0?'disabled':'')+'>上一页</button><span>'+(page+1)+' / '+max+'</span><button type="button" data-'+key+'="1" '+(page+1>=max?'disabled':'')+'>下一页</button></div>';
}
function renderGameNotes(){
  if(!official || !stats)return;
  const o=official,notes=o.mayhem?.url===o.url && o.mayhem?.patch===o.patch?o.mayhem:null;
  if(patchView.version!==o.patch){patchView.version=o.patch;patchView.filter='all';patchView.page=0;}
  const entries=notes?.entries || [];
  $('game-patch-title').textContent=o.patch+' 海克斯大乱斗更新';
  const status=health.official.stale?'本次公告未能核实最新状态。':'';
  const samplePatch=leadingGG()?gg.catalog.patch:stats.patch;
  const sampleLabel=samplePatch===o.samplePatch?'国服英雄榜已对齐':'当前英雄榜 '+samplePatch;
  $('game-patch-meta').textContent='腾讯国服 · '+date(o.publishedAt)+' 发布 · 客户端 '+o.samplePatch+' · '+sampleLabel;
  $('game-patch-check').textContent=status+' 腾讯公告最近成功采集 '+(o.checkedAt?date(o.checkedAt):'尚无记录')+'（北京时间）';
  const quick=['buff','nerf','adjust','new','fix','other'].map(k=>[k,entries.filter(e=>e.kind===k).length]).filter(([,n])=>n);
  const badges=quick.map(([k,n])=>'<button type="button" class="patch-chip '+k+'" data-patch-filter="'+k+'" aria-pressed="'+(patchView.filter===k)+'">'+patchKinds[k]+' <b>'+n+'</b></button>').join('');
  const chips=$('patch-filters');
  if(chips.innerHTML!==badges)chips.innerHTML=badges;
  const filtered=entries.filter(e=>patchView.filter==='all' || e.kind===patchView.filter);
  patchView.page=Math.max(0,Math.min(patchView.page,Math.ceil(filtered.length/PAGE_SIZE)-1));
  const rows=filtered.slice(patchView.page*PAGE_SIZE,(patchView.page+1)*PAGE_SIZE).map(e=>'<li><span class="patch-class '+esc(e.kind)+'">'+patchKinds[e.kind]+'</span><div><strong>'+esc(e.name)+'</strong> <small>'+esc(e.category)+'</small>'+e.details.map(s=>'<p>'+esc(s)+'</p>').join('')+'<small>分类依据 · '+esc(e.basis)+'</small></div></li>').join('');
  let body=(o.notesPending?'<p>本次正文解析未完成，可查看腾讯原文。</p>':'')+(entries.length?
    '<div class="patch-list-heading"><b>'+patchKinds[patchView.filter]+' · '+filtered.length+' 条</b><button type="button" data-patch-filter="all">查看全部</button></div><ul class="patch-list">'+rows+'</ul>'+pageButtons(patchView.page,filtered.length,'patch-page'):
    '<p>本版暂未取得可核实的模式改动条目。你可以直接查阅腾讯公告。</p>');
  if(o.hotfixes?.length)body+='<h3>同期国服热修公告</h3>'+o.hotfixes.map(h=>'<p>'+external(h.url,h.title)+' · '+esc(date(h.publishedAt))+'</p>'+((notes?.hotfixDetails || []).find(item=>item.url===h.url)?.entries || []).map(e=>'<div class="hotfix-entry"><strong>'+esc(patchKinds[e.kind] || '调整')+' · '+esc(e.name)+'</strong><p>'+e.details.map(esc).join('<br>')+'</p></div>').join('')).join('');
  const target=$('game-note-list');if(target.innerHTML!==body)target.innerHTML=body;
  $('game-note-toggle').textContent='查看改动详情'+(entries.length?'（'+entries.length+' 条）':'');
  $('game-original').href=o.url;
}
function renderPool(hero,sample){
  const patch=official?.samplePatch, feed=official?.heroPool?.patch===patch?official.heroPool:null;
  const pool=feed?.heroes?.[hero.id];
  const allowed=pool?.rows.filter(r=>r.state==='allowed') || [],blocked=pool?.rows.filter(r=>r.state==='blocked') || [];
  const holds=Object.entries(sample?.augmentCounts || {}).filter(([,n])=>n>0).sort((a,b)=>b[1]-a[1]);
  if(poolView.hero!==hero.id){Object.assign(poolView,{hero:hero.id,query:'',page:0,tab:allowed.length?'allowed':'held'});}
  const tabs={allowed:['已证实可选',allowed.length],held:['结算持有记录',holds.length],blocked:['明确禁选',blocked.length]};
  const tab=poolView.tab;
  const caption=pool?.complete?'来源已发布该英雄的完整供选表。':pool?'来源已发布部分逐条规则，其余强化供选状态待核实。':'本版尚无该英雄的完整供选表，也未取得逐条供选规则。';
  const summary='<div class="pool-caption"><strong>国服 '+esc(official?.patch)+' · 客户端 '+esc(patch)+'</strong><p>'+caption+'</p>'+
    (official?.poolPending?'<p>本次规则更新未通过核验，保留同版本已取得的记录。</p>':'')+
    (feed?'<small>'+external(feed.source.url,feed.source.name)+' · '+date(feed.publishedAt)+'</small>':'')+
    (pool?.coverageSource?'<p>'+external(pool.coverageSource.url,pool.coverageSource.name)+'</p>':'')+'</div>';
  const rows=tab==='held'?holds.map(([id,n])=>({id,n})): (tab==='allowed'?allowed:blocked).map(rule=>({id:rule.augmentId,rule}));
  const sameBook=tab==='held' || augmentBook.patch===patch;
  const prepared=rows.map(r=>{const a=augmentBook.byId?.[r.id] || augmentMap.get(r.id) || {};
    return {...r,a:{...a,id:r.id,name:r.rule?.name || a.name || '强化 '+r.id,rarity:a.rarity || 'unknown'}};})
    .filter(r=>(r.a.name+' '+r.id+' '+(r.rule?.detail || '')).toLowerCase().includes(poolView.query.trim().toLowerCase()));
  poolView.page=Math.max(0,Math.min(poolView.page,Math.ceil(prepared.length/PAGE_SIZE)-1));
  const cards=prepared.slice(poolView.page*PAGE_SIZE,(poolView.page+1)*PAGE_SIZE).map(({id,n,a,rule})=>
    '<li>'+(rule?.icon?imageFallback(rule.icon,a.name.slice(0,1)):augmentIcon(a))+'<div><strong>'+esc(a.name)+'</strong> '+(a.rarity!=='unknown'?label(a):'')+
    (rule?'<p>'+esc(rule.detail)+'</p>'+(!sameBook && !rule.name?'<small>名称参考 '+esc(stats.patch)+' 图鉴 · ID '+esc(id)+'</small><br>':'')+'<small>'+external(rule.source.url,rule.source.name)+'</small>':'<p>'+count(n)+' 持有人次 · 英雄持有率 '+pct(n/sample.games*100)+'</p>')+
    '</div>'+(n?'<button type="button" data-open-augment="'+id+'">强化详情</button>':'')+'</li>').join('');
  const empty=poolView.query?'没有匹配的强化。':tab==='held'?'这个样本中尚无该英雄的结算持有记录。':tab==='allowed'?'尚无可列出的已证实可选条目。':'尚无来源明确指出本版禁选的条目。';
  return summary+'<div class="pool-tabs">'+Object.entries(tabs).map(([key,[name,total]])=>'<button type="button" data-pool-tab="'+key+'" aria-pressed="'+(tab===key)+'">'+name+(key==='held' || total?' '+count(total):'')+'</button>').join('')+'</div>'+
    '<p class="pool-meta">'+(tab==='held'?'AramHex 国服普通模式 · '+metaLine(stats)+' · '+esc(hero.name)+'出场 '+count(sample?.games)+' 人次。结算持有包括转化、赠予等获取方式。':('供选规则按客户端 '+esc(patch)+' 核对。'))+'</p>'+
    '<label class="pool-search">搜索本栏强化 <input type="search" id="pool-search" value="'+esc(poolView.query)+'" placeholder="名称或 ID"></label>'+
    '<div id="pool-results">'+(cards?'<ul class="pool-list">'+cards+'</ul>':'<p class="pool-empty">'+empty+'</p>')+pageButtons(poolView.page,prepared.length,'pool-page')+'</div>'+
    '<p class="pool-link"><a href="?tab=augments" data-global-augments>查看全局海克斯图鉴 →</a></p>';
}
document.addEventListener('click',e=>{
  const t=e.target.closest('button,a');if(!t || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey)return;
  if(t.id==='game-sync'){void refresh(true);return;}
  if(t.dataset.patchFilter || t.dataset.patchPage){
    if(t.dataset.patchFilter){patchView.filter=t.dataset.patchFilter;patchView.page=0;}else patchView.page+=Number(t.dataset.patchPage);
    $('game-note-details').open=true;renderGameNotes();
    if(t.dataset.patchPage)$('game-note-toggle').focus();
  }
  if(t.dataset.poolTab || t.dataset.poolPage){
    if(t.dataset.poolTab){poolView.tab=t.dataset.poolTab;poolView.page=0;poolView.query='';}else poolView.page+=Number(t.dataset.poolPage);
    renderProfile();$('detail').querySelector('[data-pool-tab="'+poolView.tab+'"]')?.focus({preventScroll:true});
  }
  if(t.hasAttribute('data-global-augments')){
    e.preventDefault();setAtlasRoute('pushState',null,'','?tab=augments');restoreLocation();
  }
});
document.addEventListener('input',e=>{
  if(e.target.id!=='pool-search')return;
  poolView.query=e.target.value;poolView.page=0;
  const {hero,sample}=heroRecord(profile.id);
  const template=document.createElement('template');
  template.innerHTML=renderPool(hero,sample);
  $('pool-results').replaceChildren(...template.content.querySelector('#pool-results').childNodes);
});
