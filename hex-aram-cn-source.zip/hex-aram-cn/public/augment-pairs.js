'use strict';
const pairBatches=new Map();
function pairName(id){return augmentMap.get(id)?.name || augmentBook.byId?.[id]?.name || '强化 '+id;}
function augmentFace(id){
  const a=augmentMap.get(id) || {...augmentBook.byId?.[id],id,name:pairName(id)};
  return augmentIcon(a)+'<span>'+esc(a.name)+'</span>';
}
function getPairBatch(heroId,patch,force=false){
  const key=patch+'/'+heroId, old=pairBatches.get(key);
  if(old?.pending || (!force && old?.until>Date.now()))return old.promise;
  const entry={pending:true};
  entry.promise=read('/api/augment-pairs/'+key+(force?'?check=1':'')).then(b=>{
    if(b.heroId!==heroId || b.patch!==patch || b.region!=='CN' || !Array.isArray(b.rows) ||
       !['ready','unpublished','unavailable'].includes(b.status))throw Error('搭配来源不符');
    return b;
  }).catch(()=>({status:'unavailable',rows:[]})).then(b=>{
    entry.pending=false;entry.until=Date.now()+(b.status==='unavailable'?30000:300000);
    if(pairBatches.size>200)for(const [k,v] of pairBatches)if(k!==key&&!v.pending){pairBatches.delete(k);break;}
    return b;
  });
  pairBatches.set(key,entry);return entry.promise;
}
function syncPairView(force=false){
  if(!sheet)return;
  const current=sheet;
  getPairBatch(current.heroId,current.patch,force).then(batch=>{
    if(sheet!==current || sheet.batch===batch)return;
    sheet.batch=batch;renderSheetEvidence();
  });
}
