'use strict';

function heroSearchTerms(h){
  const catalog=championBook.byId?.[h.id];
  return [h.name,h.title,h.alias,h.id,catalog?.key,...(catalog?.keywords || [])];
}
function slotTraits(heroId,slot){
  return spellTraitsBook.patch===stats.patch?spellTraitsBook.byHero?.[heroId]?.slots?.[slot] || []:[];
}
function skillTraitsLine(heroId,slot){
  const values=slotTraits(heroId,slot);
  const meta=spellTraitsBook.patch===stats.patch?spellTraitsBook.byHero?.[heroId]?.slotMeta?.[slot]:null;
  const labels=values.length?'<p class="skill-traits"><b>游戏技能标签</b> '+esc(values.join('、'))+'</p>':
    '<p class="sheet-note">'+(meta?.status==='untranslated'?'该技能的原始标签尚无核实的中文释义。':'本版资料暂无该键位可展示的游戏标签。')+'</p>';
  return labels+(meta?.missileConfigured?'<p class="sheet-note">该键位的主法术有飞弹配置。</p>':'');
}
function targetListUrl(heroId,slot='',basis=''){
  const params=new URLSearchParams({hero:heroId,view:'targets'});
  if(skillKeys.includes(slot))params.set('slot',slot);
  if(Object.hasOwn(bindingTypes,basis))params.set('basis',basis);
  return heroQuery(params);
}
function targetSlot(){return skillKeys.includes(ui.skillFilter)?ui.skillFilter:'';}
function selectTargetSlot(slot){
  ui.skillFilter=skillKeys.includes(slot)?slot:'linked';
  if(slot && ['pending','external'].includes(ui.skillBasis))ui.skillBasis='';
  ui.page=0;ui.id=null;updateTargetLocation();renderList();
  $('filters').querySelector('[data-target-slot="'+slot+'"]')?.focus({preventScroll:true});
}
function updateTargetLocation(){
  if(profile?.section==='targets' && !sheet)setAtlasRoute('replaceState',history.state,'',targetListUrl(profile.id,targetSlot(),ui.skillBasis));
}
function skillListExtraIds(hero){
  return Object.entries(augmentSkillBook.patch===stats.patch?augmentSkillBook.byId:{}).filter(([,t])=>
    t.byHero?.[hero.id] || t.historyByHero?.[hero.id] || t.textByHero?.[hero.id] || t.excludedByHero?.[hero.id]).map(([id])=>id);
}
function heroTargetControls(h){
  if(!h)return '';
  if(augmentSkillBook.patch!==stats.patch)return '<p class="metric-note">国服 '+esc(stats.patch)+' 的技能强化明细尚待资料更新。</p>';
  const ids=[...new Set([...Object.keys(h.augmentCounts).filter(id=>h.augmentCounts[id]>0),...skillListExtraIds(h)])].filter(id=>{
    const a=augmentMap.get(id) || augmentBook.byId?.[id];
    return skillTarget(id) && a && (!ui.minGames || (h.augmentCounts[id] || 0)>=ui.minGames) &&
      (ui.rarity==='all' || a.rarity===ui.rarity) && matchesAugmentText({...a,id},ui.query,h.id);
  });
  const slot=targetSlot(), skills=currentSkills(h.id);
  const card=(s,text,n,icon='')=>'<button type="button" class="skill-key" data-target-slot="'+s+'" aria-pressed="'+(s===slot)+'">'+icon+'<span><b>'+esc(text)+'</b><small>'+n+' 项</small></span></button>';
  const cards=card('','全部技能',ids.filter(id=>matchBinding(skillTarget(id),h.id,'',ui.skillBasis)).length)+skills.map(s=>
    card(s.slot,s.slot+' · '+s.name,ids.filter(id=>matchBinding(skillTarget(id),h.id,s.slot,ui.skillBasis,true)).length,skillIcon(s))).join('');
  const active=skills.find(s=>s.slot===slot);
  const traitHero=spellTraitsBook.patch===stats.patch?spellTraitsBook.byHero?.[h.id]:null;
  const keys=Object.entries(bindingTypes);
  return '<section class="skill-explorer" aria-label="按英雄技能查强化"><div class="skill-keys">'+cards+'</div>'+
    (active?'<div class="slot-description"><p>'+esc(active.description)+'</p>'+skillTraitsLine(h.id,slot)+(traitHero?.note?'<p class="sheet-note">'+esc(traitHero.note)+'</p>':'')+(traitHero?.source?external(traitHero.source,'本版技能文件'):'')+'</div>':'')+
    '<label class="select-label">关联依据 <select id="skill-basis"><option value="">全部依据</option>'+keys.map(([k,v])=>'<option value="'+k+'" '+(ui.skillBasis===k?'selected':'')+'>'+v+'</option>').join('')+'</select></label></section>';
}
function skillDirectoryMarkup(id){
  return '<details class="hero-target-index" data-directory="'+esc(id)+'"><summary>按英雄查具体技能</summary><div class="directory-tools"><input type="search" data-directory-search aria-label="搜索对应英雄或技能" placeholder="英雄名、简称、拼音或技能"><select aria-label="筛选技能资料" data-directory-basis><option value="">全部记录</option>'+Object.entries(bindingTypes).map(([k,v])=>'<option value="'+k+'">'+v+'</option>').join('')+'</select></div><div data-directory-results></div></details>';
}
function renderSkillDirectory(el,page=0){
  const id=el.dataset.directory,t=skillTarget(id);
  if(!t)return;
  const basis=el.querySelector('[data-directory-basis]').value,query=normalizedAugmentQuery(el.querySelector('input').value);
  const rows=[];
  const heroes=new Map(stats.heroes.map(h=>[h.id,h]));
  const heroIds=new Set([...heroes.keys(),...Object.keys(t.byHero||{}),...Object.keys(t.textByHero||{}),...Object.keys(t.historyByHero||{}),...Object.keys(t.excludedByHero||{})]);
  for(const heroId of heroIds){
    const h=heroes.get(heroId) || championBook.byId?.[heroId];
    if(!h)continue;
    const n=h.augmentCounts?.[id] || 0, direct=t.byHero?.[heroId], text=t.textByHero?.[heroId],historic=t.historyByHero?.[heroId],excluded=t.excludedByHero?.[heroId];
    if(!n && !direct && !text && !historic && !excluded)continue;
    if(!matchBinding(t,heroId,'',basis))continue;
    const parts=skillRelations(t,heroId);
    const shown=evidenceListLabel(id,heroId,'',basis);
    const terms=[...heroSearchTerms(h),shown];
    if(query && !terms.some(term=>normalizedAugmentQuery(term).includes(query)))continue;
    rows.push({h,n,shown,priority:direct?0:text?1:parts.length?2:3});
  }
  rows.sort((a,b)=>a.priority-b.priority || b.n-a.n || a.h.name.localeCompare(b.h.name,'zh-CN'));
  const pages=Math.max(1,Math.ceil(rows.length/PAGE_SIZE));
  page=Math.max(0,Math.min(page,pages-1));el.dataset.page=String(page);
  el.querySelector('[data-directory-results]').innerHTML=(rows.length?'<ul class="directory-rows">'+rows.slice(page*PAGE_SIZE,(page+1)*PAGE_SIZE).map(({h,n,shown})=>{
    const action=n?'data-target-hero="'+h.id+'"':'data-skill-reference="'+h.id+'"';
    return '<li><button type="button" '+action+' data-target-augment="'+id+'">'+assetFor(h)+'<span><b>'+esc(h.name)+'</b><small>'+esc(shown)+'</small></span></button><span>'+esc(n?count(n)+' 人次':'本批未记录')+'</span></li>';
  }).join('')+'</ul>':'<p class="sheet-note">当前条件下没有匹配的英雄。</p>')+
    '<div class="directory-pages"><span>'+rows.length+' 位英雄 · '+(page+1)+' / '+pages+' 页</span><button data-directory-page="-1" '+(!page?'disabled':'')+'>上一页</button><button data-directory-page="1" '+(page+1>=pages?'disabled':'')+'>下一页</button></div>';
}
function openSkillReference(heroId,id){
  const h=championBook.byId?.[heroId],a=augmentMap.get(id) || augmentBook.byId?.[id];
  if(!a || !h)return;
  showDialog(h.name+' · '+a.name,'<p>AramHex 国服 '+esc(stats.patch)+' 本批未记录这位英雄持有该强化。对局统计与技能资料分别列示。</p>'+skillTargetDetail(id,heroId));
}
function bindSkillDirectory(){
  document.addEventListener('toggle',e=>{if(e.target.matches?.('[data-directory]') && e.target.open)renderSkillDirectory(e.target);},true);
  document.addEventListener('input',e=>{
    if(e.target.matches('[data-directory-search]'))renderSkillDirectory(e.target.closest('[data-directory]'));
  });
  document.addEventListener('change',e=>{
    if(e.target.matches('[data-directory-basis]'))renderSkillDirectory(e.target.closest('[data-directory]'));
  });
}
