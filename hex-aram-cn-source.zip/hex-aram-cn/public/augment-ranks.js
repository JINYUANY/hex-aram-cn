'use strict';

let observedHeroCounts=new Map();
function indexAugmentCoverage(heroes){
  const coverage=new Map();
  for(const hero of heroes){
    for(const [id,n] of Object.entries(hero.augmentCounts)){
      if(n>0)coverage.set(id,(coverage.get(id) || 0)+1);
    }
  }
  return coverage;
}
function augmentRankRows(rows,hero){
  const baseline=stats.holdingBaseline, historical=hero?baseline?.byHero[hero.id]:null;
  const previousCounts=hero?historical?.held:baseline?.totals;
  const previousPlayers=hero?historical?.games:baseline?.players;
  const tiers=new Map();
  for(const row of rows){
    if(row.games!=null)tiers.set(row.rarity,(tiers.get(row.rarity) || 0)+row.games);
  }
  return rows.map(row=>{
    if(row.games==null)return row;
    const previousGames=previousCounts?.[row.id];
    const previousRate=previousGames!=null && previousPlayers>0?100*previousGames/previousPlayers:null;
    const otherPlayers=hero?stats.heroParticipations-hero.games:0;
    const otherRate=otherPlayers>0?100*(augmentMap.get(row.id).games-row.games)/otherPlayers:null;
    const tierTotal=tiers.get(row.rarity);
    return {...row,tierTotal,tierShare:tierTotal && row.rarity!=='unknown'?100*row.games/tierTotal:null,
      coverage:observedHeroCounts.get(row.id) || 0,otherRate,gap:otherRate==null?null:row.holdRate-otherRate,
      previousGames,previousPlayers,previousRate,trend:previousRate==null?null:row.holdRate-previousRate};
  });
}
const augmentMetricNames={holdRate:'持有率',games:'持有人次',tierShare:'同品质占比',coverage:'覆盖英雄数',gap:'英雄偏好',trend:'版本变化'};
function augmentRanks(){
  return ['holdRate','games','tierShare',ui.scopeHero?'gap':'coverage','trend'].map(k=>[k,augmentMetricNames[k]+'榜']);
}
function points(v){
  if(v==null)return '—';
  const magnitude=Math.abs(v);
  return (v>0?'+':v<0?'−':'')+(magnitude>0 && magnitude<0.005?'<0.01':magnitude.toFixed(2));
}
function augmentRankNote(){
  const hero=scopedHero(), past=stats.holdingBaseline;
  const context=hero?hero.name:'全体英雄';
  const notes={
    holdRate:context+'的结算持有人次 ÷ '+(hero?'该英雄':'全部玩家')+'出场人次，每人每局每枚计一次。',
    games:'统计玩家在结算时持有该强化的人次，同一玩家在不同对局分别计数。',
    tierShare:'在'+context+'的同品质强化持有记录中，这一枚占多少。一名玩家可以贡献多枚记录。',
    coverage:'统计本批 '+count(stats.heroes.length)+' 位有出场样本的英雄中，有多少位在结算时持有过这枚强化。',
    gap:'该英雄的持有率减去其他英雄合计持有率，以百分点计。正数表示该英雄更常持有。',
    trend:past?'本版持有率减去 '+past.patch+' 版持有率，以百分点计。两版各用自己的出场人次计算。历史样本截至 '+date(past.cutoff)+'（北京时间），共 '+count(past.matches)+' 场。':'暂无可核验的同口径历史窗口。'
  };
  return '<div class="metric-note"><p>'+esc(notes[ui.sort] || '可通过榜单或表头选择排序指标。')+'</p><div><button type="button" data-rank-info="pick">选取率 · 数据说明</button><button type="button" data-rank-info="win">强化胜率 · 展示规则</button></div></div>';
}
function showRankInfo(kind){
  const hero=scopedHero(), source=external(gameSource(),'AramHex 本批原始数据');
  if(kind==='pick'){
    showDialog('三选一选取率 · 本版缺少样本','<p>选取率衡量某枚强化出现在候选中时，玩家有多少次选择了它。</p><dl class="rank-definition"><dt>计算方式</dt><dd>实际点选次数 ÷ 该强化供选次数</dd><dt>国服样本</dt><dd>'+esc((hero?hero.name:'全体英雄')+' · '+stats.patch)+'</dd><dt>供选次数与实际点选次数</dt><dd>来源未披露</dd></dl><p>当前可查结算持有率。重随机会、任务奖励和强化转换都会影响两种指标的关系。</p><p>'+source+' · '+metaLine(stats)+'</p>');
  }else{
    showDialog('强化胜率 · 展示规则','<p>Riot 的《英雄联盟》开发者政策禁止网站、应用和游戏覆盖层展示强化胜率。该规则也适用于按英雄筛选的强化和多枚组合。</p><p>英雄榜可查询英雄本身的胜率，装备库可查询有合规样本的普通装备持有时胜率。</p><p>'+external('https://developer.riotgames.com/docs/lol#game-policy','查看 Riot 游戏政策')+'</p>');
  }
}
function augmentBreakdown(r,hero){
  if(r?.games==null)return '';
  const p=stats.holdingBaseline;
  const rows=[['同品质占比',pct(r.tierShare),count(r.games)+' / '+count(r.tierTotal)+' 条同品质持有记录'],
    ['有持有记录的英雄',count(r.coverage)+' / '+count(stats.heroes.length)+' 位','当前国服样本']];
  if(hero && r.gap!=null)rows.push(['相对其他英雄',points(r.gap)+' 个百分点','其他英雄合计持有率 '+pct(r.otherRate)]);
  if(p)rows.push([p.patch+' 版持有率',pct(r.previousRate),r.previousRate==null?'缺少同英雄范围的对应记录':count(r.previousGames)+' / '+count(r.previousPlayers)+' 出场人次'],
    ['跨版本变化',r.trend==null?'—':points(r.trend)+' 个百分点','历史样本截至 '+date(p.cutoff)+'（北京时间）']);
  return '<details class="rank-breakdown"><summary>查看指标明细与分母</summary>'+rows.map(([name,value,sub])=>row(name,sub,value)).join('')+'</details>';
}
