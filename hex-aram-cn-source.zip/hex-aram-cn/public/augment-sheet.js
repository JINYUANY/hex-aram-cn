'use strict';

let sheet=null;
const patchNotes23='https://www.leagueoflegends.com/en-us/news/game-updates/league-of-legends-patch-26-23-notes/';
const numberNames=['一','二','三','四','五','六'];
function currentHero(){return stats.heroes.find(h=>h.id===sheet.heroId);}
function gameSource(){return 'https://github.com/czgreat/aramhex-data/tree/data-v'+stats.seq+'/patches/'+stats.patch+'/normal';}
function sheetUrl(){
  const params=profile?.section==='pool'?poolParams(sheet.heroId):new URLSearchParams({hero:sheet.heroId,view:['targets','pairs'].includes(profile?.section)?profile.section:'augments'});
  params.set('entry',sheet.ids[0]);
  if(profile?.section==='targets'){if(targetSlot())params.set('slot',targetSlot());if(ui.skillBasis)params.set('basis',ui.skillBasis);}
  if(sheet.ids.length>1)params.set('with',sheet.ids.slice(1).join(','));
  if(sheet.active!==sheet.ids[0])params.set('inspect',sheet.active);
  return heroQuery(params);
}
function openAugmentSheet(heroId,first,extras=[],inspect=null,push=true){
  const h=stats.heroes.find(x=>x.id===heroId);
  if(!h || !augmentMap.has(first) || !(h.augmentCounts[first]>0))return;
  const ids=[...new Set([first,...extras.filter(id=>augmentMap.has(id) && h.augmentCounts[id]>0)])].slice(0,6);
  sheet={heroId,patch:stats.patch,ids,active:ids.includes(inspect)?inspect:first,picking:false,query:'',rarity:'all',page:0,heroPage:0,gearPage:0,pairPage:0,batch:null};
  if(push){
    const saved={...history.state,heroList:{...ui},poolReturn:profile?.section==='pool'?first:null,listY:window.scrollY};
    setAtlasRoute('replaceState',saved,'',profile?.section==='targets'?targetListUrl(heroId,targetSlot(),ui.skillBasis):profileUrl(heroId,profile?.section || 'augments'));
    setAtlasRoute('pushState',{...history.state,sheetOpen:true},'',sheetUrl());
  }else setAtlasRoute('replaceState',history.state,'',sheetUrl());
  $('sheet-trios').open=false;
  if(!$('augment-sheet').open)$('augment-sheet').showModal();
  $('augment-sheet').querySelector('.sheet-scroll').scrollTop=0;
  renderSheet();syncPairView();
}
function dismissSheet(navigate=true){
  if(!sheet)return;
  const state=history.state,hero=sheet.heroId,first=sheet.ids[0];
  sheet=null;if($('augment-sheet').open)$('augment-sheet').close();
  if(!navigate)return;
  if(state?.sheetOpen){history.back();return;}
  setAtlasRoute('replaceState',state,'',profile?.section==='targets'?targetListUrl(hero,targetSlot(),ui.skillBasis):profileUrl(hero,profile?.section || 'augments'));
  const focus=profile?.section==='pool'?$('detail').querySelector('[data-open-augment="'+first+'"]') || $('pool-search'):$('results').querySelector('tr.selected .hero-cell');
  focus?.focus({preventScroll:true});
}
function persistSheet(){setAtlasRoute('replaceState',history.state,'',sheetUrl());}
function sheetStat(label,value,sub=''){
  return '<div><dt>'+esc(label)+'</dt><dd>'+esc(value)+'</dd><small>'+esc(sub)+'</small></div>';
}
function iconButton(id,attr){
  return '<button type="button" class="aug-chip" '+attr+'>'+augmentFace(id)+'</button>';
}
function cardRank(pool,games){return 1+pool.filter(n=>n>games).length;}
function renderSheet(){
  if(!sheet)return;
  const h=currentHero(), id=sheet.active, a=augmentMap.get(id), games=h.augmentCounts[id], share=100*games/h.games;
  const entries=Object.entries(h.augmentCounts).filter(([,n])=>n>0),tier=entries.filter(([k])=>augmentMap.get(k)?.rarity===a.rarity);
  const diff=share-a.holdRate;
  $('sheet-context').textContent=h.name+' · 国服 '+sheet.patch+' · 强化详情';
  $('sheet-main').innerHTML='<div class="sheet-feature">'+augmentIcon(a)+'<div>'+label(a)+'<h2 id="sheet-title">'+esc(a.name)+'</h2></div></div>'+
    qualityDescription(a)+skillTargetDetail(id,h.id)+'<dl class="sheet-metrics">'+sheetStat(h.name+'持有率',pct(share),count(games)+' / '+count(h.games)+' 次英雄出场')+
    sheetStat('全体英雄持有率',pct(a.holdRate),count(a.games)+' / '+count(stats.heroParticipations)+' 玩家人次')+
    sheetStat('与全体相差',(diff>=0?'+':'')+diff.toFixed(2)+' 个百分点','同一批国服样本')+
    sheetStat('该英雄持有率排名','第 '+cardRank(entries.map(([,n])=>n),games)+' / '+entries.length,(rarityNames[a.rarity] || '')+'品质内第 '+cardRank(tier.map(([,n])=>n),games)+' / '+tier.length)+'</dl>'+
    '<p class="sheet-note">按结算时持有计算。上游未提供三选一出现次数，无法计算出现后被选中的比例。</p>'+
    '<p class="sheet-note">'+external(gameSource(),'AramHex')+' · '+metaLine(stats)+'</p>'+
    augmentBreakdown(augmentRankRows(augmentedRows(),h).find(r=>r.id===id),h)+
    (sheet.ids.length>1?'<details><summary>仅看「'+esc(a.name)+'」时的出装资料</summary>'+cohortEquipment(h,[id],null)+'</details>':'');
  renderSheetEvidence();renderPicker();renderMore();
}
function equipmentList(rows){
  return '<div class="gear-rows"><div class="gear-line head"><span>装备</span><span>样本</span><span>装备胜率</span></div>'+
    rows.map(r=>{const i=equipmentById.get(r.id);return i?'<div class="gear-line"><span>'+itemIcon(i)+esc(i.name)+'</span><span>'+count(r.games)+'</span><strong>'+esc(pct(r.winRate))+'</strong></div>':'';}).join('')+'</div>';
}
function cohortEquipment(h,ids,row){
  if(ids.length===1){
    const panels=[['全部玩家',stats.augmentGear],['前 5% 玩家',stats.highAugmentGear]].filter(([,g])=>g?.augmentId===ids[0] && g.byHero[h.id]?.length)
      .map(([group,g])=>{
        const threshold=[g.minimumSeconds!=null?'对局至少 '+g.minimumSeconds+' 秒':'',g.minimumGames!=null?'单件至少 '+count(g.minimumGames)+' 场':'',g.minimumShare!=null?'占比至少 '+Number((100*g.minimumShare).toFixed(2))+'%':''].filter(Boolean).join('，');
        return '<h4>'+group+'</h4><p class="sheet-note">'+(g.patch!==sheet.patch?'历史样本 · ':'')+metaLine(g)+' · '+
          external(g.source || gameSource()+'/hero_augment_items.json','AramHex 条件装备表')+'</p>'+equipmentList(g.byHero[h.id])+
          '<p class="sheet-note">取样本中的首件传说装备，最多 3 件。'+esc(threshold)+'。每件胜率以该行装备场数为分母。</p>';
      });
    if(panels.length)return '<h3>持有「'+esc(pairName(ids[0]))+'」时的首件传说装备</h3>'+panels.join('');
  }
  if(row?.items?.length)return '<h3>这组强化的结算装备</h3>'+equipmentList(row.items)+'<p class="sheet-note">装备与组合使用同一来源和样本窗口，胜率分母为该行装备的样本。</p>';
  return '<h3>'+esc(ids.length===1?'这枚强化的专属出装':'这组强化的专属出装')+'</h3><p class="sheet-note">国服 '+esc(sheet.patch)+' · 暂无该英雄在此条件下可核验的装备场数和胜率，样本截止时间未披露。</p>';
}
function sameSet(row,ids){return row.augmentIds.length===ids.length && ids.every(id=>row.augmentIds.includes(id));}
function renderSheetEvidence(){
  if(!sheet)return;
  const {ids,active,batch}=sheet, h=currentHero(), records=batch?.status==='ready'?batch.rows:[];
  const exact=records.find(r=>sameSet(r,ids));
  const choices=ids.map((id,index)=>'<span class="chosen">'+iconButton(id,'data-inspect="'+id+'" aria-pressed="'+(active===id)+'" aria-label="查看第'+numberNames[index]+'枚 '+esc(pairName(id))+'"')+
    (index>0?'<button class="remove-choice" data-remove="'+id+'" aria-label="移除'+esc(pairName(id))+'">×</button>':'')+'</span>').join('');
  let body='<h3>已选海克斯</h3><div class="chosen-list">'+choices+(ids.length<6?'<button class="add-choice" data-pick-more aria-expanded="'+sheet.picking+'">添加第'+numberNames[ids.length]+'枚</button>':'')+'</div>';
  if(ids.length>1){
    body+='<h3>'+ids.length+' 枚同时持有</h3>';
    if(exact) body+='<p class="set-count">'+count(exact.games)+' 场</p>';
    else body+='<p class="sheet-note">'+(!batch?'正在核对这组强化…':batch.status==='unavailable'?'暂时无法读取组合样本。':'本版暂无这组强化的实测场数。')+'</p>';
  }
  if(ids.length<6){
    body+='<h3>'+(ids.length===1?'和「'+esc(pairName(ids[0]))+'」同局持有的第二枚':'常见后续搭配')+'</h3>';
    const next=records.filter(r=>r.augmentIds.length===ids.length+1 && ids.every(id=>r.augmentIds.includes(id)));
    if(next.length){
      const pages=Math.ceil(next.length/PAGE_SIZE);
      sheet.pairPage=Math.min(sheet.pairPage,pages-1);
      body+='<p class="sheet-note">'+(batch.coverage==='partial'?'来源仅公布部分组合。':'')+'按同局持有场数排序。第一枚为查询条件，实际选择先后未披露。</p><ol class="pair-ranking" start="'+(1+sheet.pairPage*PAGE_SIZE)+'">'+
        next.slice(sheet.pairPage*PAGE_SIZE,(sheet.pairPage+1)*PAGE_SIZE).map(r=>{
          const id=r.augmentIds.find(x=>!ids.includes(x));
          const face=augmentMap.has(id) && h.augmentCounts[id]>0?iconButton(id,'data-append="'+id+'"'):'<span class="aug-chip">'+augmentFace(id)+'</span>';
          return '<li>'+face+'<strong>'+count(r.games)+' 场</strong></li>';
        }).join('')+'</ol>'+(pages>1?sheetPager('pairs',sheet.pairPage,pages,next.length):'');
    }else body+='<p class="sheet-note">'+(!batch?'正在读取组合样本…':batch.status==='unavailable'?'暂时无法核实本版搭配样本。':'本版暂无可据实排名的后续搭配。')+'</p>';
  }
  if(batch?.status==='ready')body+='<p class="sheet-note">'+external(batch.source.url,batch.source.name)+' · '+metaLine(batch)+(batch.heroGames?' · '+count(batch.heroGames)+' 场英雄样本':'')+(batch.stale?' · 本次未核实，沿用最近记录':'')+'</p>';
  else if(batch){
    body+='<p class="sheet-note">国服 '+esc(sheet.patch)+' · 同局组合样本截止时间待来源发布。</p>'+
      '<details><summary>为什么没有双枚场数？</summary><p>AramHex 第 '+count(stats.seq)+' 批可查每枚分别有多少人持有；双枚需要同一个玩家在同一局同时持有两枚的计数。'+external(gameSource(),'查看本批发布文件')+'</p>'+
      '<p>公开组合目录列举编辑整理的玩法，缺少同局场数。'+external('https://arammayhem.com/data/v1/latest/combos.json','查看原表字段')+'</p></details>';
    const old=batch.historical;
    if(old && ids.length<=2){
      const rows=old.rows.filter(r=>ids.every(id=>r.augmentIds.includes(id)));
      if(rows.length){
        const pages=Math.ceil(rows.length/PAGE_SIZE);sheet.pairPage=Math.min(sheet.pairPage,pages-1);
        body+='<h4>历史双枚样本 · '+esc(old.patch)+'</h4><p class="sheet-note">'+external(old.source.url,old.source.name)+' · '+metaLine(old)+'</p><ul>'+
          rows.slice(sheet.pairPage*PAGE_SIZE,(sheet.pairPage+1)*PAGE_SIZE).map(r=>'<li>'+r.augmentIds.map(id=>esc(pairName(id))+' (#'+esc(id)+')').join(' ＋ ')+' · '+count(r.games)+' 场</li>').join('')+'</ul>'+
          (pages>1?sheetPager('pairs',sheet.pairPage,pages,rows.length):'');
      }
    }
  }
  if(batch)body+='<button class="slink" data-refresh-combo>重新核对组合数据</button>';
  body+=cohortEquipment(h,ids,exact);
  $('sheet-combo').innerHTML=body;
  refreshSheetTrios();
}
function renderPicker(){
  const el=$('sheet-picker');el.hidden=!sheet?.picking;
  if(el.hidden){el.innerHTML='';return;}
  if(!el.querySelector('input')){
    el.innerHTML='<h3>选择下一枚海克斯</h3><div class="picker-tools"><input type="search" id="augment-find" aria-label="搜索候选强化" placeholder="搜索强化、技能名或编号"><select id="augment-tier" aria-label="品质"><option value="all">全部品质</option>'+Object.entries(rarityNames).filter(([k])=>k!=='unknown').map(([k,v])=>'<option value="'+k+'">'+v+'</option>').join('')+'</select><button data-picker-close>收起</button></div><div id="picker-rows"></div>';
  }
  const h=currentHero(), q=sheet.query.trim().toLowerCase();
  const rows=Object.entries(h.augmentCounts).filter(([id,n])=>n>0 && !sheet.ids.includes(id) && augmentMap.has(id) &&
    matchesAugmentText(augmentMap.get(id),q,h.id) && (sheet.rarity==='all'||augmentMap.get(id).rarity===sheet.rarity)).sort((a,b)=>b[1]-a[1]);
  const pages=Math.max(1,Math.ceil(rows.length/PAGE_SIZE));sheet.page=Math.min(sheet.page,pages-1);
  $('picker-rows').innerHTML='<p class="sheet-note">该英雄有持有记录的候选，按单枚持有场数排列。组合样本另行核对。</p><div class="picker-grid">'+
    rows.slice(sheet.page*PAGE_SIZE,(sheet.page+1)*PAGE_SIZE).map(([id])=>iconButton(id,'data-append="'+id+'"')).join('')+'</div>'+
    (rows.length?sheetPager('pick',sheet.page,pages,rows.length):'<p>没有匹配的强化。</p>');
}
function sheetPager(tag,page,pages,total){
  return '<div class="sheet-pager"><span>'+count(total)+' 项 · 第 '+(page+1)+' / '+pages+' 页</span><button aria-label="上一页" data-page-'+tag+'="-1" '+(!page?'disabled':'')+'>上一页</button><button aria-label="下一页" data-page-'+tag+'="1" '+(page+1>=pages?'disabled':'')+'>下一页</button></div>';
}
function mechanicCards(h){
  if(stats.patch!=='16.23' || augmentBook.patch!==stats.patch || !championBook.version?.startsWith(stats.patch+'.'))return '';
  const source=championBook.byId[h.id]?.skills?.[0];
  if(!source)return '';
  const cards=[];
  if(['157','777','23'].includes(h.id)){
    if(h.augmentCounts['1077'])cards.push(['1077','暴击伤害转为治疗',h.name+'的被动能提高暴击几率。「灵魂虹吸」按暴击伤害的 12% 治疗自己，并提供 25% 暴击几率。']);
    if(h.augmentCounts['1080'])cards.push(['1080','暴击几率也能用于防御','「会心防御」提供 25% 暴击几率，并使用暴击几率判定减伤。触发概率上限为 50%，继续堆暴击有不同收益。']);
  }
  if(h.id==='157' && h.augmentCounts['3078'])cards.push(['3078','施法后的普攻获得额外伤害','亚索可以用 E 突进后接普攻，衔接强化的额外魔法伤害和移速。26.23 已下调这次额外伤害。']);
  if(h.id==='122' && h.augmentCounts['1092'])cards.push(['1092','流血获得暴击条件','德莱厄斯的被动会施加持续流血，「易损」让持续伤害可以暴击并提供暴击几率。']);
  const fixes={'34':['1113','已修复的异常：Q 可无冷却施放','此前艾尼维亚的 Q 搭配老练狙神时可能没有冷却，26.23 已修复。'],
    '134':['1113','E 的远程命中联动已修复','26.23 修复了辛德拉的 E 无法与老练狙神联动的问题。'],
    '240':['1019','过量急速已修复','此前克烈从全凭身法得到的技能急速超过预期，26.23 已修复。'],
    '203':['1344','终极技能护盾已修复','26.23 修复了千珏无法获得最终形态护盾的问题。'],
    '76':['2072','形态异常已修复','此前奈德丽在美洲狮形态下可能使用标枪投掷，26.23 已修复。'],
    '9':['1325','永久草间人已修复','此前费德提克拥有玻璃大炮时，草间人可能永久存在，26.23 已修复。']};
  const fix=fixes[h.id];if(fix && h.augmentCounts[fix[0]])cards.push(fix);
  if(!cards.length)return '';
  return cards.map(([id,title,body])=>'<div class="mechanic-card">'+iconButton(id,'data-mechanic="'+id+'"'+(sheet && !sheet.ids.includes(id)?' title="加入当前搭配并查看"'+(sheet.ids.length>=6?' disabled':''):''))+'<div><b>'+esc(title)+'</b><p>'+esc(body)+'</p></div></div>').join('')+
    '<p class="sheet-note">资料出处　'+external(championBook.sourceUrl || 'https://developer.riotgames.com/docs/lol#data-dragon','英雄技能')+' · '+external(augmentBook.sources?.kiwi || 'https://raw.communitydragon.org/','模式强化资料')+' · '+external(patchNotes23,'26.23 版本改动')+'。</p>';
}
function heroHoldingGaps(h){
  const otherPlayers=stats.heroParticipations-h.games;
  if(!h.games || otherPlayers<=0)return '';
  const standout=[];
  for(const [id,games] of Object.entries(h.augmentCounts)){
    const augment=augmentMap.get(id);
    if(!augment || games<100)continue;
    const heroRate=100*games/h.games, otherRate=100*(augment.games-games)/otherPlayers;
    const gap=heroRate-otherRate;
    if(gap>=5)standout.push({id,games,heroRate,otherRate,gap});
  }
  standout.sort((a,b)=>b.gap-a.gap || b.games-a.games);
  const cards=standout.slice(0,5).map(r=>'<div class="mechanic-card">'+iconButton(r.id,'data-open-augment="'+r.id+'"')+
    '<div><b>高 '+r.gap.toFixed(2)+' 个百分点</b><p>'+esc(h.name)+' '+pct(r.heroRate)+'（'+count(r.games)+' / '+count(h.games)+' 人次），其他英雄合计 '+pct(r.otherRate)+'。</p></div></div>').join('');
  return '<details class="holding-gaps"><summary>哪些强化在'+esc(h.name)+'身上格外常见？</summary>'+
    '<p class="sheet-note">比较同一批次的结算持有率。至少持有 100 人次、比其他英雄高 5 个百分点时，列出差距最大的 5 枚。</p>'+
    (cards || '<p class="sheet-note">本批没有达到该条件的单枚强化。</p>')+'<p class="sheet-note">'+external(gameSource(),'AramHex 国服样本')+' · '+metaLine(stats)+'</p></details>';
}
function showMechanicSets(h){
  const target=$('mechanic-sets');if(!target || !h)return;
  const patch=stats.patch;
  getPairBatch(h.id,patch).then(batch=>{
    if(!target.isConnected || profile?.id!==h.id || profile.section!=='pairs')return;
    const candidates=patch==='16.23' && ['157','777','23'].includes(h.id)?[
      [['1077','1080'],'同一项暴击投入关联治疗和减伤，防御触发概率有上限。'],
      [['1077','1328'],'暴击伤害带来治疗，暴击普攻还能叠加攻击速度。'],
      [['1077','1080','1328'],'治疗、减伤判定和普攻攻速叠层分别使用暴击机制。']
    ]:[];
    const cards=[];
    for(const [ids,description] of candidates){
      const row=batch.rows.find(r=>sameSet(r,ids));
      if(!row || ids.some(id=>!h.augmentCounts[id]))continue;
      cards.push('<div class="mechanic-card"><button class="aug-chip set-link" data-open-set="'+ids.join(',')+'">'+ids.map(augmentFace).join(' ＋ ')+'</button><div><b>'+count(row.games)+' 场同时持有</b><p>'+esc(description)+'</p></div></div>');
    }
    target.innerHTML='<h3>双枚与三枚联动</h3>'+(cards.length?cards.join('')+'<p class="sheet-note">'+external(batch.source.url,batch.source.name)+' · '+metaLine(batch)+'</p>':
      '<p class="sheet-note">'+(batch.status==='unavailable'?'组合场数暂时无法核对。':'本批暂无同时具备机制依据和国服实测场数的条目。')+'</p>');
  });
}
function renderMore(){
  const h=currentHero(), id=sheet.active;
  const e=stats.equipment;
  const known=mechanicCards(h);
  $('sheet-more').innerHTML='<h3>'+esc(h.name)+'的机制联动</h3>'+(known || '<p class="sheet-note">当前目录还没有为该英雄核实的专属机制条目。</p>')+
    '<p class="sheet-note">机制说明依据技能和强化文本。'+external('https://developer.riotgames.com/docs/lol#game-policy','Riot 游戏政策')+'禁止展示强化胜率，单枚和组合均不提供胜率排名。</p>'+
    '<details><summary>'+esc(h.name)+'的成装明细 · 不限强化</summary><p class="sheet-note">按该英雄的结算持有场数排列。AramHex · '+metaLine(e || {})+'。</p><div id="sheet-general-gear"></div></details>'+
    '<details id="sheet-heroes"><summary>其他使用「'+esc(pairName(id))+'」的英雄</summary><div id="hero-comparison"></div></details>'+
    '<details><summary>样本窗口与统计口径</summary><p>国服普通海克斯大乱斗 · '+esc(stats.patch)+'。'+esc(date(stats.start))+' 至 '+esc(date(stats.cutoff))+'（北京时间）。'+count(stats.matches)+' 场有效对局，覆盖 '+esc(stats.regions.join('、'))+'。</p><p>单枚统计按玩家结算持有计数，同一玩家同一枚强化只计一次。组合需要同一名玩家在同一局结算同时持有全部指定强化。不同来源和窗口单独标注。</p></details>';
  renderComparison();renderGeneralGear();
}
function renderGeneralGear(){
  const data=stats.equipment?.byHero?.[sheet.heroId];
  const rows=(data?.rows || []).filter(([id,,wins])=>equipmentById.get(String(id))?.kind==='complete' && wins!=null)
    .map(([id,games,wins])=>({id:String(id),games,winRate:100*wins/games}));
  const pages=Math.max(1,Math.ceil(rows.length/PAGE_SIZE));sheet.gearPage=Math.min(sheet.gearPage,pages-1);
  $('sheet-general-gear').innerHTML=equipmentList(rows.slice(sheet.gearPage*PAGE_SIZE,(sheet.gearPage+1)*PAGE_SIZE))+sheetPager('gear',sheet.gearPage,pages,rows.length);
}
function renderComparison(){
  const id=sheet.active;
  const rows=stats.heroes.filter(h=>h.id!==sheet.heroId && h.augmentCounts[id]>0).sort((a,b)=>b.augmentCounts[id]/b.games-a.augmentCounts[id]/a.games);
  const pages=Math.max(1,Math.ceil(rows.length/PAGE_SIZE));sheet.heroPage=Math.min(sheet.heroPage,pages-1);
  $('hero-comparison').innerHTML=rows.slice(sheet.heroPage*PAGE_SIZE,(sheet.heroPage+1)*PAGE_SIZE).map(h=>'<div class="gear-line"><span>'+assetFor(h)+esc(h.name)+'</span><span>'+count(h.augmentCounts[id])+' 人次</span><strong>'+esc(pct(100*h.augmentCounts[id]/h.games))+'</strong></div>').join('')+sheetPager('heroes',sheet.heroPage,pages,rows.length);
}
function appendChoice(id){
  if(sheet.ids.includes(id) || sheet.ids.length>=6 || !(currentHero().augmentCounts[id]>0))return;
  sheet.ids.push(id);sheet.pairPage=0;sheet.active=id;sheet.picking=false;sheet.heroPage=0;persistSheet();renderSheet();
  $('augment-sheet').querySelector('.sheet-scroll').scrollTop=0;
}
function bindAugmentSheet(){
$('augment-sheet').addEventListener('click',e=>{
  const b=e.target.closest('button'), d=b?.dataset;
  if(!sheet)return;
  if(!b){if(e.target===$('augment-sheet')){const r=e.target.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dismissSheet();}return;}
  if(b.hasAttribute('data-sheet-close'))dismissSheet();
  else if(b.hasAttribute('data-pick-more')){
    sheet.picking=true;sheet.query='';sheet.rarity='all';sheet.page=0;renderSheetEvidence();$('sheet-picker').innerHTML='';renderPicker();$('augment-find').focus();
  }else if(b.hasAttribute('data-picker-close')){sheet.picking=false;renderPicker();renderSheetEvidence();$('sheet-combo').querySelector('[data-pick-more]')?.focus();}
  else if(d.append)appendChoice(d.append);
  else if(d.inspect){sheet.active=d.inspect;sheet.heroPage=0;persistSheet();renderSheet();$('augment-sheet').querySelector('.sheet-scroll').scrollTop=0;}
  else if(d.remove){sheet.pairPage=0;sheet.ids=sheet.ids.filter(id=>id!==d.remove);if(sheet.active===d.remove)sheet.active=sheet.ids.at(-1);sheet.heroPage=0;persistSheet();renderSheet();}
  else if(d.pagePairs){sheet.pairPage=Math.max(0,sheet.pairPage+Number(d.pagePairs));renderSheetEvidence();}
  else if(d.pagePick){sheet.page+=Number(d.pagePick);renderPicker();}
  else if(d.pageHeroes){sheet.heroPage+=Number(d.pageHeroes);renderComparison();}
  else if(d.pageGear){sheet.gearPage+=Number(d.pageGear);renderGeneralGear();}
  else if(b.hasAttribute('data-refresh-combo'))syncPairView(true);
  else if(d.mechanic){
    if(sheet.ids.includes(d.mechanic)){sheet.active=d.mechanic;sheet.heroPage=0;persistSheet();renderSheet();$('augment-sheet').querySelector('.sheet-scroll').scrollTop=0;}
    else appendChoice(d.mechanic);
  }
});
$('augment-sheet').addEventListener('input',e=>{if(sheet && e.target.id==='augment-find'){sheet.query=e.target.value;sheet.page=0;renderPicker();}});
$('augment-sheet').addEventListener('change',e=>{if(sheet && e.target.id==='augment-tier'){sheet.rarity=e.target.value;sheet.page=0;renderPicker();}});
$('augment-sheet').addEventListener('cancel',e=>{e.preventDefault();dismissSheet();});
}
