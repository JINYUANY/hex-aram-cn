'use strict';

const profileSections={augments:'海克斯库',targets:'技能强化',items:'装备库',builds:'出装搭配',skills:'技能与属性',pairs:'海克斯搭配'};
const catalogNames={heroes:'英雄榜',items:'装备图鉴',augments:'海克斯图鉴',builds:'英雄出装'};
const siteTitle=document.title;
let profile=null, profileHeaderHTML='';

function profileUrl(id,section='augments',entry) {
  const params=new URLSearchParams({hero:id});
  if(section!=='augments')params.set('view',section);
  if(entry)params.set('entry',entry);
  return '?'+params;
}
function heroRecord(id) {
  const sample=stats.heroes.find(h=>h.id===id);
  const newer=leadingGG() && gg.catalog.heroes.find(h=>h.id===id);
  return {hero:newer || sample,sample,newer:Boolean(newer)};
}
function renderProfile() {
  const {hero,sample,newer}=heroRecord(profile.id);
  if(!hero)return;
  const section=profile.section, e=stats.equipment;
  const augCount=sample?Object.values(sample.augmentCounts).filter(n=>n>0).length:null;
  const eqCount=e?.byHero?.[hero.id]?.rows.length;
  const source=newer?'ARAMGG · 国服 '+esc(gg.catalog.patch)+' · 统计日期 '+esc(ggDate(hero.date))+' · 截止时间未披露':'AramHex · '+metaLine(stats);
  const metric=(name,value)=>'<div><dt>'+name+'</dt><dd>'+esc(value)+'</dd></div>';
  const nav=Object.entries(profileSections).map(([key,name])=>{
    const n=key==='augments'?augCount:key==='items'?eqCount:null;
    const entry=section==='pairs' && (key==='augments' || key==='pairs')?profile.entry:null;
    return '<a id="section-'+key+'" href="'+esc(profileUrl(hero.id,key,entry))+'" data-profile-section="'+key+'"'+(section===key?' aria-current="page"':'')+'>'+name+(n!=null?' <small>'+count(n)+'</small>':'')+'</a>';
  }).join('');
  const sourceTab=history.state?.originTab || 'heroes';
  const html='<nav class="profile-crumb" aria-label="当前位置"><a href="?tab='+esc(sourceTab)+'" data-back-catalog>返回'+esc(catalogNames[sourceTab] || '英雄榜')+'</a><span>/</span><span>'+esc(hero.name)+'</span></nav>'+
    '<div class="profile-summary"><div class="profile-id">'+assetFor(hero)+'<div><small>'+esc(hero.title || championBook.byId?.[hero.id]?.title)+'</small>'+
    '<h1 id="profile-name" tabindex="-1">'+esc(hero.name)+'</h1><p>'+esc(championBook.byId?.[hero.id]?.roles?.join(' · ') || '')+'</p></div></div>'+
    '<div class="profile-totals"><dl>'+metric('英雄胜率',pct(hero.winRate))+metric(newer?'国服登场率':'出场占比',pct(hero.pickRate))+metric(newer?'样本场数':'出场人次',hero.games==null?'未披露':count(hero.games))+'</dl><p>'+source+'</p></div></div>'+
    '<nav class="profile-nav" aria-label="英雄资料栏目">'+nav+'</nav>';
  if(html!==profileHeaderHTML){$('champion-profile').innerHTML=html;profileHeaderHTML=html;}
  document.title=hero.name+' · '+profileSections[section]+' | 海克斯战局';
  const article=section==='skills' || section==='builds';
  document.body.classList.toggle('profile-article',article);
  $('profile-mechanics').hidden=section!=='pairs';
  if(section==='pairs'){
    const cards=sample && mechanicCards(sample);
    $('profile-mechanics').innerHTML='<h2>'+esc(hero.name)+'的专属机制联动</h2>'+(cards || '<p class="sheet-note">暂无已核实的英雄专属机制条目。</p>')+'<div id="mechanic-sets"></div>'+
      '<p class="sheet-note">按技能与强化说明整理。Riot 的展示规则限制强化胜率，机制联动和同局场数均不能证明胜率跃升。</p>'+(sample?heroHoldingGaps(sample):'');
    showMechanicSets(sample);
  }
  if(!article)return false;
  const detail=$('detail');
  detail.dataset.hero=hero.id;
  let body;
  if(section==='skills'){
    const book=championBook.byId?.[hero.id];
    body=(sample?'<button class="slink" data-skills-for="'+hero.id+'">查看与'+esc(hero.name)+'技能关联的海克斯</button>':'')+(book?championFacts(book,hero.id):'<p class="detail-note">对应版本的英雄技能和基础属性尚未收录。</p>');
  }else if(section==='builds'){
    body=sample?gearDetail(sample):'<p class="detail-note">AramHex 当前没有该英雄的出装样本。</p>';
  }
  detail.innerHTML='<h2>'+esc(hero.name)+' · '+profileSections[section]+'</h2>'+body;
  return true;
}
function displayProfile(id,section,entry) {
  profile={id,section,entry:/^[1-9]\d{0,7}$/.test(entry)?entry:null};
  document.body.classList.add('profile-mode');
  $('champion-profile').hidden=false;
  const tab=section==='items'?'items':'augments';
  resetTab(tab);
  ui.scopeHero=id;
  const params=atlasLocation().searchParams;
  if(section==='targets'){
    ui.skillFilter=skillKeys.includes(params.get('slot'))?params.get('slot'):'linked';
    ui.skillBasis=Object.hasOwn(bindingTypes,params.get('basis'))?params.get('basis'):'';
  }
  const isTable=['targets','augments','items','pairs'].includes(section);
  const rows=entry && isTable?listRows():[];
  const index=rows.findIndex(r=>r.id===entry);
  if(index>=0){ui.page=Math.floor(index/PAGE_SIZE);ui.id=entry;}
  renderList();renderSummary();
  if(index>=0 && section!=='items'){
    if(scopedHero()?.augmentCounts[entry]>0)openAugmentSheet(id,entry,(params.get('with') || '').split(','),params.get('inspect'),false);
    else if(section==='targets')openSkillReference(id,entry);
  }
  if(index<0 && entry && section==='items'){
    const item=equipmentById.get(entry);
    if(item)showDialog(item.name,'<p class="info">本批没有该英雄持有这件装备的记录。</p>'+itemDetail({...item,games:null,holdRate:null,wins:null,winRate:null}));
  }
}
function leaveProfile() {
  dismissSheet(false);
  if($('dialog').open)$('dialog').close();
  profile=null;profileHeaderHTML='';
  $('champion-profile').hidden=true;
  $('profile-mechanics').hidden=true;
  document.body.classList.remove('profile-mode','profile-article');
  document.title=siteTitle;
}
function openProfile(id,section='augments',entry=null) {
  if(!Object.hasOwn(profileSections,section) || !heroRecord(id).hero)return;
  if($('dialog').open)$('dialog').close();
  const sameHero=profile && profile.id===id;
  let state=history.state;
  if(!profile){
    const catalog={...ui};
    if(ui.tab==='heroes')catalog.id=id;
    setAtlasRoute('replaceState',{catalog,scroll:window.scrollY},'',location.href);
    state={originTab:ui.tab,hasCatalog:true};
    setAtlasRoute('pushState',state,'',profileUrl(id,section,entry));
  }else{
    setAtlasRoute('replaceState',state,'',profileUrl(id,section,entry));
  }
  displayProfile(id,section,entry);
  const focus=sameHero?$('section-'+section):$('profile-name');
  focus?.focus({preventScroll:true});
  if(entry && ['augments','items'].includes(section) && matchMedia('(max-width:760px)').matches)$('detail').scrollIntoView({block:'start'});
  else window.scrollTo(0,0);
}
function returnToCatalog() {
  if(history.state?.hasCatalog){history.back();return;}
  setAtlasRoute('replaceState',null,'','?tab=heroes');
  restoreLocation();
  $('tab-heroes').focus({preventScroll:true});
}
function restoreLocation() {
  if(!stats)return;
  leaveProfile();
  const params=atlasLocation().searchParams, tab=params.get('tab'), id=params.get('hero');
  if(id && heroRecord(id).hero){
    const requested=params.get('view') || (location.hash==='#hero-pairs'?'pairs':tab);
    const section=Object.hasOwn(profileSections,requested)?requested:'augments';
    displayProfile(id,section,params.get('entry') || params.get('id'));
    const list=history.state?.heroList;
    if(list && !params.has('entry') && list.scopeHero===id && (section==='pairs'||section==='augments'||section==='targets') && (section!=='targets'||(list.skillFilter===ui.skillFilter && list.skillBasis===ui.skillBasis))){
      Object.assign(ui,list);$('search').value=ui.query;renderList();
      $('results').querySelector('tr.selected .hero-cell')?.focus({preventScroll:true});window.scrollTo(0,history.state.listY || 0);
    }else window.scrollTo(0,0);
    return;
  }
  const saved=history.state?.catalog;
  resetTab(saved?.tab || (Object.hasOwn(catalogNames,tab)?tab:'heroes'));
  if(saved){
    Object.assign(ui,saved);$('search').value=ui.query;
  }else if(params.get('id')){
    const selected=sourceRows().find(r=>r.id===params.get('id'));
    if(selected){ui.id=selected.id;ui.query=selected.name;$('search').value=ui.query;}
  }
  renderList();renderSummary();
  if(saved){
    const focus=$('results').querySelector('tr.selected .hero-cell');
    focus?.focus({preventScroll:true});
    window.scrollTo(0,history.state.scroll || 0);
  }else window.scrollTo(0,0);
}
window.addEventListener('popstate',restoreLocation);
