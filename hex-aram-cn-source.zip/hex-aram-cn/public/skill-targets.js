'use strict';

let augmentSkillBook={}, spellTraitsBook={};
const bindingTypes={rule:'固定键位',official:'官方实例',gameplay:'实战记录',text:'技能文本关联',external:'额外获得的技能',pending:'指定键位待核实',excluded:'历史移除或修复',pbe:'历史测试服'};
const skillKeys=['P','Q','W','E','R'];

function unpackSkillBook(book){
  if(book.schema!==2)return book;
  for(const target of Object.values(book.byId)){
    for(const [heroId,refs] of Object.entries(target.textByHero || {})){
      target.textByHero[heroId]=refs.map(ref=>Number.isInteger(ref)?book.conditionFacts?.[ref]:ref).filter(f=>f?.heroId===heroId);
    }
  }
  return book;
}
function skillTarget(id){
  return augmentSkillBook.patch===stats.patch?augmentSkillBook.byId?.[id]:null;
}
function currentSkills(heroId){
  return championBook.version?.startsWith(stats.patch+'.')?championBook.byId?.[heroId]?.skills || []:[];
}
function namedPart(entry,heroId){
  const p=typeof entry==='string'?{slot:entry}:entry;
  const skill=currentSkills(heroId).find(s=>s.slot===p.slot);
  if(p.qualifier)return {...p,skill:null};
  return {...p,name:p.name || skill?.name,skill:p.name && p.name!==skill?.name?null:skill};
}
function heroSkillParts(target,heroId){
  return (target.byHero?.[heroId] || target.slots || []).map(p=>namedPart(p,heroId));
}
function partType(part){
  return part.sourceKeys?.some(key=>augmentSkillBook.sources[key]?.kind==='official')?'official':'gameplay';
}
function skillRelations(t,heroId){
  if(!t)return [];
  const entries=[];
  for(const p of t.slots || [])entries.push({...namedPart(p,heroId),type:'rule'});
  for(const p of t.affectedSlots || [])entries.push({...namedPart(p,heroId),type:'rule',role:'affected'});
  for(const p of t.byHero?.[heroId] || [])entries.push({...namedPart(p,heroId),type:partType(p)});
  for(const p of t.textByHero?.[heroId] || [])entries.push({...namedPart(p,heroId),type:'text'});
  return entries;
}
function relatedPartsLabel(parts){
  return [...new Set(parts.map(p=>[p.slot,p.name,p.qualifier].filter(Boolean).join(' · ')))].join(' / ');
}
function externalSkillLabel(t){
  if(!t.granted?.length)return t.label;
  return t.granted.map(p=>[championBook.byId?.[p.heroId]?.name,p.slot,namedPart(p,p.heroId).name].filter(Boolean).join(' · ')).join(' / ');
}
function skillSummary(id,heroId){
  const t=skillTarget(id);if(!t)return '';
  if(t.kind==='external')return '额外获得 · '+externalSkillLabel(t);
  const parts=skillRelations(t,heroId).filter(p=>p.role!=='affected');
  if(parts.length){
    const labels=[...new Set(parts.map(p=>bindingTypes[p.type]))].join(' / ');
    return labels+' · '+relatedPartsLabel(parts);
  }
  return t.kind==='champion' && heroId?'该英雄键位待核实':t.label;
}
function listSkillLabel(id,heroId){
  const t=skillTarget(id);
  if(!t || profile?.section!=='targets')return skillSummary(id,heroId);
  return evidenceListLabel(id,heroId,targetSlot(),ui.skillBasis);
}
function historicalRelations(t,heroId){
  const records=[];
  for(const [type,group] of [['excluded',t.excludedByHero],['pbe',t.historyByHero]]){
    for(const p of group?.[heroId] || [])records.push({...namedPart(p,heroId),type});
  }
  return records;
}
function evidenceListLabel(id,heroId,slot,basis){
  const t=skillTarget(id);
  if(!t)return '';
  const parts=[...skillRelations(t,heroId),...historicalRelations(t,heroId)]
    .filter(p=>(!slot || p.slot===slot) && (!basis || p.type===basis));
  if(!parts.length)return skillSummary(id,heroId);
  return [...new Set(parts.map(p=>(p.role==='affected'?'受到影响':bindingTypes[p.type])+' · '+relatedPartsLabel([p])))].join(' / ');
}
function normalizedAugmentQuery(value){
  return String(value || '').trim().toLowerCase().replaceAll('回响释放','回响施放');
}
function matchesAugmentText(a,input,heroId){
  const q=normalizedAugmentQuery(input);
  if(!q)return true;
  const t=skillTarget(a.id), terms=[a.name,a.id];
  if(t){
    terms.push(t.label,t.description,skillSummary(a.id,heroId));
    if(heroId)for(const p of skillRelations(t,heroId))terms.push(p.slot+'技能',p.name,p.mechanic,p.note);
    if(heroId && profile?.section==='targets'){
      for(const p of historicalRelations(t,heroId))terms.push(p.slot,p.name,p.qualifier,p.note);
    }
    if(t.granted)terms.push(externalSkillLabel(t));
  }
  return terms.some(value=>normalizedAugmentQuery(value).includes(q));
}
function skillFilter(){
  const choices=[['','全部强化'],['linked','技能相关'],...(ui.scopeHero?[['known','有键位资料'],['pending','指定技能待核实'],...skillKeys.map(k=>[k,k==='P'?'被动技能':k+' 技能'])]:[])];
  return '<label class="select-label">技能 <select id="skill-filter">'+choices.map(([value,name])=>'<option value="'+value+'" '+(ui.skillFilter===value?'selected':'')+'>'+name+'</option>').join('')+'</select></label>';
}
function matchBinding(t,heroId,slot,basis='',includeHistory=false){
  if(!t)return false;
  const parts=skillRelations(t,heroId);
  if(basis==='pending')return !slot && t.kind==='champion' && !(t.byHero?.[heroId]?.length);
  if(basis==='external')return !slot && t.kind==='external';
  if(basis==='pbe' || basis==='excluded'){
    const entries=(basis==='pbe'?t.historyByHero:t.excludedByHero)?.[heroId] || [];
    return entries.some(p=>!slot || p.slot===slot);
  }
  if(!slot && !basis)return true;
  if(includeHistory && !basis && historicalRelations(t,heroId).some(p=>p.slot===slot))return true;
  return parts.some(p=>(!slot || p.slot===slot) && (!basis || p.type===basis));
}
function matchesSkillFilter(id){
  const filter=ui.skillFilter, t=skillTarget(id);
  if(!filter)return true;
  if(!t)return false;
  if(filter==='known')return skillRelations(t,ui.scopeHero).length>0;
  if(filter==='pending')return matchBinding(t,ui.scopeHero,'','pending');
  return matchBinding(t,ui.scopeHero,skillKeys.includes(filter)?filter:'',profile?.section==='targets'?ui.skillBasis:'',profile?.section==='targets');
}
function proofLinks(keys){
  const refs=[...new Set(keys || [])].map(k=>augmentSkillBook.sources?.[k]).filter(Boolean);
  return refs.map(ref=>{
    const label=ref.name+(ref.patch?' · '+ref.patch:ref.kind==='gameplay'?'（录像版本未核实）':'');
    const byline=[ref.author,ref.publishedOn?'发布于 '+ref.publishedOn:''].filter(Boolean).map(esc).join(' · ');
    return external(ref.url,label)+(byline?' · '+byline:'');
  }).join(' · ');
}
function labeledSkill(part){
  const label=relatedPartsLabel([part]);
  const source=proofLinks(part.sourceKeys);
  return '<div class="target-skill">'+(part.skill?skillIcon(part.skill):'')+'<div><strong>'+esc(label)+'</strong>'+(part.note?'<small>'+esc(part.note)+'</small>':'')+(source?'<small>'+source+'</small>':'')+'</div></div>';
}
function skillTargetDetail(id,heroId){
  const t=skillTarget(id);if(!t)return '';
  let body='';
  const parts=skillRelations(t,heroId);
  for(const type of ['rule','official','gameplay','text']){
    const group=parts.filter(p=>p.type===type && p.role!=='affected');
    if(group.length)body+='<h4>'+bindingTypes[type]+'</h4><div class="target-skills">'+group.map(labeledSkill).join('')+'</div>';
  }
  if(t.affectedSlots?.length)body+='<p><b>'+esc(t.affectedLabel || '受到影响的技能')+'</b>　'+esc(relatedPartsLabel(parts.filter(p=>p.role==='affected')))+'</p>';
  if(t.kind==='external')body+='<p><b>'+esc(externalSkillLabel(t))+'</b></p>';
  if(heroId && t.kind==='champion' && !t.byHero?.[heroId]?.length)body+='<p>已有资料尚未确认这位英雄的具体键位。对局时可在强化卡面查看指定技能。</p>';
  if(t.description && t.description!==augmentBook.byId?.[id]?.description)body+='<p>'+esc(t.description)+'</p>';
  for(const [type,records] of [['excluded',t.excludedByHero?.[heroId]],['pbe',t.historyByHero?.[heroId]]]){
    if(records?.length)body+='<details><summary>'+bindingTypes[type]+'</summary>'+records.map(p=>labeledSkill(namedPart(p,heroId))).join('')+'</details>';
  }
  if(t.historyNotes?.length)body+='<details><summary>历史版本说明</summary>'+t.historyNotes.map(p=>'<p>'+esc(p.note)+' '+proofLinks(p.sourceKeys)+'</p>').join('')+'</details>';
  if(heroId && (t.kind==='champion' || parts.some(p=>p.type==='text')))body+='<p class="sheet-note">持有人次按强化汇总。国服样本未披露逐技能的持有或触发次数。</p>';
  body+='<p class="sheet-note">技能资料 '+esc(augmentSkillBook.patch)+' · '+proofLinks(t.sourceKeys)+'</p>';
  if(!heroId)body+=skillDirectoryMarkup(id);
  return '<section class="skill-target"><h3>'+esc(t.label || '强化关联技能')+'</h3>'+body+'</section>';
}
