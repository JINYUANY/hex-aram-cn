import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {runInNewContext} from 'node:vm';
const service=await readFile(new URL('../src/service.mjs',import.meta.url),'utf8');
const seed={schema:4,seq:20,patch:'16.23',cutoff:'2026-11-20T08:00:00+08:00',heroes:[{id:'157'}],augments:[],regions:[],equipment:{catalog:[]}};
function api(fetchStats,BUCKET){
  const worker=runInNewContext('(()=>{'+service.replace('export default {','return {')+'})()',{
    URL,Response,fetchStats,seeds:{stats:seed}
  });
  return async(query='')=>(await worker.fetch(new Request('https://local.test/api/stats'+query),{PUBLIC_CHANNEL:true,BUCKET})).json();
}
test('network recovery immediately retries a failed attempt; successful concurrent reads reuse it',async()=>{
  let online=false,calls=0;
  const request=api(async()=>{calls++;if(!online)throw Error('offline');return {...seed,seq:21};});
  assert.equal((await request()).stale,true);
  online=true;
  const results=await Promise.all([request('?reconnect=1'),request('?reconnect=1')]);
  assert.ok(results.every(r=>r.value.seq===21 && !r.stale));
  await request();assert.equal(calls,2);
  await request('?check=1');assert.equal(calls,3);
});
test('unreadable stored JSON is repaired with the existing etag; blocked persistence retains the new batch',async()=>{
  let saved;
  const bucket={get:async()=>({etag:'bad',json:()=>{throw Error('bad JSON');}}),put:async(path,data,options)=>{
    assert.equal(options.onlyIf.etagMatches,'bad');saved=JSON.parse(data);return {};
  }};
  const request=api(async()=>({...seed,seq:21}),bucket);
  assert.equal((await request()).value.seq,21);assert.equal(saved.value.seq,21);
  const blocked=api(async()=>({...seed,seq:22}),{get:async()=>null,put:async()=>{throw Error('quota');}});
  assert.equal((await blocked()).value.seq,22);assert.equal((await blocked()).stale,false);
});
test('an older stored batch cannot replace a newer bundled sample',async()=>{
  const request=api(async seq=>{assert.equal(seq,20);return null;},{get:async()=>({etag:'old',json:()=>({value:{...seed,seq:19},tried:Date.now()})}),put:async()=>({})});
  assert.equal((await request()).value.seq,20);
});

test('a repaired edition of the same sample reaches an open client',async()=>{
  const request=api(async()=>({...seed,revision:'enriched'}));
  assert.equal((await request('?seq=20&rev=partial')).value.revision,'enriched');
  assert.equal((await request('?seq=20&rev=enriched')).value,null);
  assert.equal((await request('?seq=20')).value.revision,'enriched');
});
