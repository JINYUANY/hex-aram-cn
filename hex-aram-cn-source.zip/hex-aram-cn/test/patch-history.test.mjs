import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {mergePatchHistory} from '../src/patch-history.mjs';
const history=JSON.parse(await readFile(new URL('../data/patch-history.json',import.meta.url)));
test('offline records keep dated PC sources, paginated older versions and the full known Mayhem changes',()=>{
  assert.ok(history.length>20);
  assert.deepEqual(mergePatchHistory({history}),history);
  assert.ok(history.every(r=>r.url.startsWith('https://lol.qq.com/') && r.title && Number.isFinite(Date.parse(r.publishedAt))));
  assert.equal(history.find(d=>d.patch==='26.22').entries.length,24);
});
test('archive survives a new headline, a partial mirror and a later correction',()=>{
  const doc=history[0],source={...doc,mayhem:{...doc,entries:doc.entries.slice(0,1)}};
  const partial={...doc,hotfixes:[],mayhem:null};
  const newer={...partial,patch:'26.24',url:'https://lol.qq.com/gicp/news/410/100.html',publishedAt:'2026-12-02T09:00:00+08:00'};
  const merged=mergePatchHistory({history},source,partial,newer);
  assert.equal(merged.length,history.length+1);
  assert.equal(merged[0].entries,null);
  assert.equal(merged.find(d=>d.url===doc.url).entries.length,1);
  assert.deepEqual(mergePatchHistory({history:merged},newer),merged);
});

test('Tencent offer notices preserve the spell stage, the original patch and the whole-hero scope',async()=>{
  const {parseOfferChanges}=await import('../src/mayhem-notes.mjs');
  const heading=text=>'<p><strong style="font-size:18px">'+text+'</strong></p>';
  const body=heading('海克斯大乱斗 强化符文可用性')+heading('【示例】不再提供给')+
    '<p>● 【李青】Q1</p><p>● 【伊莉丝】人类形态Q</p>'+
    heading('极地大乱斗')+'<p>● 【其他英雄】R</p>';
  assert.deepEqual(parseOfferChanges(body,true),[
    {hero:'李青',augment:'示例',skill:'Q1',state:'removed'},
    {hero:'伊莉丝',augment:'示例',skill:'人类形态Q',state:'removed'}]);
  const records=history.flatMap(d=>(d.offerChanges || []).map(r=>({...r,patch:d.patch})));
  assert.ok(records.some(r=>r.patch==='26.12' && r.hero==='波比' && r.augment==='回响施放' && r.skill==='W'));
  assert.ok(records.some(r=>r.hero==='扎克' && r.augment==='连锁反应' && r.skill===''));
  const article={...history[0],entries:[],offerChanges:parseOfferChanges(body,true)};
  const source={...article,mayhem:article};
  assert.deepEqual(mergePatchHistory(source,{...article,mayhem:null})[0].offerChanges,article.offerChanges);
});

test('Tencent hero exclusions survive older mirrors and skill fixes keep their original scope',()=>{
  const doc=history.find(d=>d.patch==='26.18'), rebuilt=mergePatchHistory({history:[{...doc,offerChanges:[]} ]})[0];
  assert.equal(rebuilt.offerChanges.length,96);
  assert.ok(rebuilt.offerChanges.some(r=>r.hero==='基兰' && r.augment==='扳机炼狱' && !r.skill));
  const earlier=history.find(d=>d.patch==='26.14');
  assert.ok(earlier.offerChanges.some(r=>r.hero==='亚索' && r.skill==='E' && r.augment==='急速之追求'));
  const syndra=history.find(d=>d.patch==='26.23');
  assert.ok(syndra.skillInteractions.some(r=>r.hero==='辛德拉' && r.skill==='弱者退散' && r.augment==='老练狙神'));
  assert.ok(!(syndra.offerChanges || []).some(r=>r.hero==='辛德拉' && r.augment==='老练狙神'));
});
