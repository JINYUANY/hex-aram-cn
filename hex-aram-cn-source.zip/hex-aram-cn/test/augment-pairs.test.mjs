import assert from 'node:assert/strict';
import test from 'node:test';
import {verifiedPairs,readVerifiedPairs} from '../src/augment-pairs.mjs';

const meta={schema:1,region:'CN',mode:'normal',heroId:'157',patch:'16.23',measure:'same-player-final-augment-pair',
  source:{name:'Fixture',url:'https://example.org/sample'},cutoff:'2026-11-18T00:00:00+08:00',coverage:'partial',heroGames:16};
const pair=(a,b,games)=>({augmentIds:[a,b],games});
const rows=[pair('7','3',3),{...pair('11','7',8),wins:6}];
const check=doc=>verifiedPairs(doc,'16.23','157');
test('exact counts use an unordered pair and one documented cohort',()=>{
  const result=check({...meta,rows});
  assert.deepEqual(result.rows,[pair('7','11',8),pair('3','7',3)]);
  assert.equal(result.source.url,meta.source.url);assert.equal(result.cutoff,meta.cutoff);
  for(const fields of [{region:'WORLD'},{heroId:'1'},{patch:'16.22'},{mode:'arena'},{coverage:null},
    {measure:'first-three-picks'},{cutoff:'2026-11-18'},{cutoff:'2099-11-18T02:00:00Z'},{source:{name:'?',url:'javascript:0'}}]){
    assert.throws(()=>check({...meta,rows,...fields}));
  }
});
test('trios, reversed duplicates, missing counts, estimates and zero are never shown',()=>{
  for(const invalid of [[{augmentIds:['7','3','8'],games:4}],[...rows,pair('3','7',3)],
    [pair('7','7',2)],[pair('7','3',0)],[pair('7','3',17)],[pair('7','3',0.8)],[pair('7','3','3')],
    [{augmentIds:['7','3'],pickRate:1.23}],[]])assert.throws(()=>check({...meta,rows:invalid}));
});
test('missing publication, failed read and verified batch have distinct outcomes',async()=>{
  const key='augment-pairs/cn-normal-16.23-hero-157';
  const bucket=doc=>({get:async k=>{assert.equal(k,key);return doc && {json:async()=>doc};}});
  const read=b=>readVerifiedPairs(b,'16.23','157');
  assert.equal((await read(bucket(null))).status,'unpublished');
  assert.deepEqual((await read(bucket(null))).rows,[]);
  assert.equal((await read(bucket({...meta,rows:[]}))).status,'unavailable');
  assert.equal((await read(null)).status,'unavailable');
  assert.equal((await read(bucket({...meta,rows}))).status,'ready');
});

test('v2 preserves the reported sets and only exposes outcomes for eligible equipment',()=>{
  const record={...meta,schema:2,measure:'same-player-final-augment-set'};
  const ids=['11','3','7'];
  const items=new Map([['3031',{kind:'complete',canShowWinRate:true}],['994403',{kind:'augmentReward',canShowWinRate:false}]]);
  const trio={augmentIds:ids,games:7,wins:5,finalItems:[
    {id:'3031',games:4,wins:3},{id:'994403',games:2,wins:1},{id:'unknown',games:1,wins:1}]};
  const verify=rows=>verifiedPairs({...record,rows},meta.patch,meta.heroId,items);
  assert.deepEqual(verify([trio]).rows,[{augmentIds:['3','7','11'],games:7,items:[{id:'3031',games:4,winRate:75}]}]);
  assert.throws(()=>verify([trio,{...trio,augmentIds:ids.toReversed()}]));
  assert.throws(()=>verify([{...trio,augmentIds:['3','7','7']}]));
  assert.throws(()=>verify([{...trio,finalItems:[{id:'3031',games:8,wins:1}]}]));
});

test('public pair channel selects one exact batch, keeps historical data separate and restores offline',async()=>{
  const {publicPairs}=await import('../src/augment-pairs.mjs');
  const cache=new Map(),bucket={get:async k=>cache.has(k)?{json:async()=>JSON.parse(cache.get(k))}:null,put:async(k,v)=>cache.set(k,v)};
  const get=(patch,samples)=>publicPairs(bucket,patch,'157',async()=>({pairSamples:samples}));
  const current={...meta,rows},old={...current,patch:'16.22'},wrong={...current,mode:'ranked'};
  const missing=await get(meta.patch,[wrong,old]);
  assert.equal(missing.status,'unpublished');assert.equal(missing.historical.patch,'16.22');assert.deepEqual(missing.rows,[]);
  const live=await get(meta.patch,[wrong,old,current,{...current,rows:[pair('7','11',0)]}]);
  assert.deepEqual(live.rows,check(current).rows);
  await get('16.22',[old]);
  const offline=await publicPairs(bucket,meta.patch,'157',async()=>{throw Error('offline');});
  assert.equal(offline.stale,true);assert.deepEqual(offline.rows,live.rows);assert.equal(offline.cutoff,meta.cutoff);
});
