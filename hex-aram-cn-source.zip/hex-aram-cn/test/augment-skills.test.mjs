import assert from 'node:assert/strict';
import test from 'node:test';
import {readFile} from 'node:fs/promises';
import {runInNewContext} from 'node:vm';

const load=async path=>JSON.parse(await readFile(new URL(path,import.meta.url)));
const [targets,augments,champions]=await Promise.all([
  load('../public/augment-skill-targets.json'),load('../data/augment-catalog.json'),load('../data/champion-catalog.json')
]);
test('skill bindings reference versioned catalog entries, documented slots and named evidence',()=>{
  assert.equal(targets.patch,augments.patch);
  for(const [id,t] of Object.entries(targets.byId)){
    assert.ok(augments.byId[id]);
    for(const ref of t.sourceKeys)assert.match(targets.sources[ref]?.url ?? '',/^https:\/\//);
    for(const key of t.slots ?? [])assert.ok(['P','Q','W','E','R'].includes(key));
    for(const groups of [t.byHero,t.excludedByHero]){
      for(const [hero,bindings] of Object.entries(groups ?? {})){
        for(const part of bindings){
          assert.ok(champions.byId[hero].skills.some(s=>s.slot===part.slot));
          assert.ok(part.sourceKeys.length>0);
          for(const ref of part.sourceKeys)assert.ok(targets.sources[ref]?.url.startsWith('https://'));
        }
      }
    }
  }
  if(targets.patch==='16.23'){
    const echo=targets.byId['2062'];
    assert.equal(echo.kind,'champion');assert.equal(echo.slots,undefined);
    assert.ok(echo.byHero['4'].some(p=>p.slot==='Q' && p.name==='万能牌'));
    assert.deepEqual(targets.byId['1349'].affectedSlots,['Q','W','E']);
  }
});

test('all champion roots, keywords and referenced condition facts use the same patch and owner',async()=>{
  const traits=await load('../public/champion-spell-traits.json');
  assert.equal(traits.patch,targets.patch);
  assert.deepEqual(Object.keys(traits.byHero).sort(),Object.keys(champions.byId).sort());
  for(const [id,hero] of Object.entries(champions.byId)){
    const data=traits.byHero[id];assert.match(data.source,/^https:\/\//);
    assert.match(data.sha256,/^[a-f0-9]{64}$/);
    for(const s of hero.skills){
      assert.ok(Array.isArray(data.slots[s.slot]));
      assert.ok(data.slotMeta[s.slot].status);
    }
  }
  assert.ok(champions.byId['37'].keywords.includes('琴女'));
  for(const t of Object.values(targets.byId)){
    for(const [hero,refs] of Object.entries(t.textByHero ?? {})){
      assert.equal(t.kind,'conditional');assert.equal(new Set(refs).size,refs.length);
      for(const ref of refs){
        const f=targets.conditionFacts[ref];
        assert.equal(f.heroId,hero);assert.equal(f.evidenceType,'text');
        assert.ok(champions.byId[hero].skills.some(s=>s.slot===f.slot && s.name===f.name));
        assert.ok(f.sourceKeys.every(k=>targets.sources[k]));
      }
    }
    for(const ref of t.granted ?? [])assert.ok(champions.byId[ref.heroId].skills.some(s=>s.slot===ref.slot));
    for(const [hero,records] of Object.entries(t.historyByHero ?? {}))for(const p of records){
      assert.ok(champions.byId[hero].skills.some(s=>s.slot===p.slot));
      assert.ok(p.sourceKeys.some(k=>targets.sources[k]?.kind==='pbe'));
    }
  }
});

test('one slot filter distinguishes fixed, affected, observed, conditional, borrowed and removed abilities',async()=>{
  const script=await readFile(new URL('../public/skill-targets.js',import.meta.url),'utf8');
  const api=runInNewContext(script+'\naugmentSkillBook=unpackSkillBook(book);({skillTarget,matchBinding,skillRelations,evidenceListLabel});',{
    stats:{patch:targets.patch},championBook:champions,book:structuredClone(targets)
  });
  const match=(id,hero,slot,basis)=>api.matchBinding(api.skillTarget(id),hero,slot,basis);
  assert.ok(match('3163','37','W','text'));assert.ok(!match('3163','37','E','text'));
  assert.ok(!match('3163','37','W','gameplay'));assert.ok(match('1018','37','R','text'));
  assert.ok(match('2062','4','Q','gameplay'));assert.ok(match('1349','37','W','rule'));
  assert.ok(match('2062','12','Q','gameplay'));assert.ok(match('2062','12','E','excluded'));
  assert.ok(!match('2062','12','E','gameplay'));
  assert.ok(api.matchBinding(api.skillTarget('2062'),'12','E','',true));
  assert.match(api.evidenceListLabel('2062','12','E',''),/历史移除或修复 · E · 践踏/);
  assert.match(api.evidenceListLabel('2073','60','Q',''),/人类形态Q/);
  assert.ok(api.skillTarget('2073').excludedByHero['60'].some(p=>p.slot==='Q' && p.qualifier));
  assert.ok(match('1420','4','','external'));assert.ok(!match('1420','4','W',''));
  assert.ok(match('2100','157','E','excluded'));assert.ok(!match('2100','157','E','official'));
  assert.equal(api.skillRelations(api.skillTarget('1349'),'37').filter(p=>p.role==='affected').length,3);
});
