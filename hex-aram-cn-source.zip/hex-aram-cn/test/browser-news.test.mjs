import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {parseTencentDirectory} from '../src/official.mjs';
import {mergeBrowserNews} from '../src/game-feed.mjs';
const old=JSON.parse(await readFile(new URL('../data/official.json',import.meta.url)));
const now='2026-12-02T10:00:00Z',url='https://lol.qq.com/gicp/news/410/123456.html';
const directory=(title='26.24版本更新公告')=>parseTencentDirectory({data:{result:[{sTitle:title,sAuthor:'英雄联盟官方',sCreated:'2026-12-02 10:04:00',iDocID:'123456',sRedirectURL:url}]}});
test('the official directory can lead both samples and mirrors; late matching details enrich it',()=>{
  const first=mergeBrowserNews(old,old,directory(),now);
  assert.equal(first.patch,'26.24');assert.equal(first.samplePatch,'16.24');assert.equal(first.notesPending,true);assert.equal(first.championBalance,null);assert.equal(first.detailCheckedAt,null);
  assert.throws(()=>mergeBrowserNews(first,old,null,now));
  const body={...first,notesPending:false,checkedAt:'2026-12-02T09:58:00Z',mayhem:{schema:1,patch:first.patch,samplePatch:first.samplePatch,url,entries:[]}};
  delete body.detailCheckedAt;
  const next=mergeBrowserNews(first,body,directory(),now);
  assert.equal(next.notesPending,false);assert.equal(next.detailCheckedAt,body.checkedAt);assert.equal(next.newsChannel,'direct');
});
test('a date-only Tencent heading remains independently visible without guessing a patch',()=>{
  const d=directory('12月2日停机版本更新公告');
  const state=mergeBrowserNews(old,old,d,now);
  assert.equal(state.patch,old.patch);assert.equal(state.directoryPending.url,url);
  assert.equal(mergeBrowserNews(state,old,null,now).directoryPending.url,url);
  assert.throws(()=>directory('26.24云顶之弈版本更新公告'));
});
