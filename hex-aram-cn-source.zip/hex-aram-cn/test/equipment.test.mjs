import assert from 'node:assert/strict';
import {test} from 'node:test';
import {canShowItemWinRate, prepareEquipment} from '../src/equipment.mjs';
import {prepareAugmentGear} from '../src/stats.mjs';

const manifest = {
  patch:'16.23', mode:'normal', files:{
    'hero_item_holdings.json': {sha256:'holdings'},
    'equipment_heroes.json': {sha256:'participants'}
  }
};
const tables = {
  meta:{
    snapshot_at:'2026-11-20T08:00:00+08:00', low_sample_threshold:3000,
    equipment:{valid_matches:2, minimum_duration_s:300}
  },
  equipment_heroes:{'1':{games:15}, '2':{games:5}},
  hero_item_holdings:{
    '1':{'1011':{games:2,wins:1}, '3084':{games:8,wins:5}, '994403':{games:2,wins:1}},
    '2':{'3084':{games:5,wins:2}}
  },
  hero_items:{'1':{'3084':{games:4,wins:3}}},
  item_metadata:{
    '1011':{name:'巨人腰带',category:'other'},
    '3084':{name:'心之钢',category:'complete_equipment'},
    '994403':{name:'金铲铲',category:'complete_equipment'},
    '881':{name:'仅资料'}
  }
};
const game = {communityPatch:'16.23', communityItems:{
  '1011':{name:'巨人腰带',to:[3084,555]},
  '3084':{
    name:'心之钢', from:[1011,1011,555], categories:['Health'],
    description:'<stats>900生命值</stats><br><br><passive>吞食</passive> (0秒)<br>提供0-30%的伤害，治疗0生命值。'
  }
}};

test('all-holdings denominators, quest reward suppression, sparse metadata and recipes', () => {
  const equipment = prepareEquipment(manifest,tables,{},game);
  const items = new Map(equipment.catalog.map(row=>[row.id,row]));
  assert.equal(equipment.denominator,20);
  assert.equal(equipment.matches,2);
  assert.equal(equipment.byHero['1'].denominator,15);
  const heartsteel = items.get('3084');
  assert.equal(heartsteel.games,13);
  assert.equal(heartsteel.wins,7);
  assert.equal(heartsteel.holdRate,65);
  assert.deepEqual(heartsteel.from,['1011','1011']);
  assert.deepEqual(items.get('1011').into,['3084']);
  assert.deepEqual(heartsteel.attributes,['900生命值']);
  assert.deepEqual(heartsteel.types,['生命值']);
  assert.match(heartsteel.effects,/〔数值未提供〕秒/);
  assert.match(heartsteel.effects,/0-30%/);
  assert.doesNotMatch(heartsteel.effects,/治疗0/);
  assert.equal(items.get('881').games,null);
  const spatula = items.get('994403');
  assert.equal(spatula.kind,'augmentReward');
  assert.equal(spatula.wins,null);
  assert.equal(spatula.winRate,null);
  assert.deepEqual(equipment.byHero['1'].rows.find(r=>r[0]==='994403'),['994403',2,null]);
  assert.equal(canShowItemWinRate('994403',spatula),false);
  assert.equal(canShowItemWinRate('3084',heartsteel),true);
  assert.equal(canShowItemWinRate('555'),false);
});

test('different releases cannot contribute a denominator or a wrong-patch description', () => {
  const index = {datasets:[{
    mode:'normal', patch:'16.22', snapshot_at:'2026-11-17T18:00:00+08:00',
    files:{'hero_item_holdings.json':{sha256:'holdings'}}
  }]};
  const equipment = prepareEquipment(manifest,tables,index,{...game,communityPatch:'16.22'});
  assert.equal(equipment.patch,'16.22');
  assert.equal(equipment.denominator,null);
  assert.equal(equipment.matches,null);
  const heartsteel = equipment.catalog.find(row=>row.id==='3084');
  assert.equal(heartsteel.holdRate,null);
  assert.equal(heartsteel.games,13);
  assert.equal(heartsteel.effects,'');
});

test('invalid holdings counts fail before a partial release can be presented', () => {
  const propped = structuredClone(tables);
  propped.hero_item_holdings['1']['3084'].games = 16;
  assert.throws(()=>prepareEquipment(manifest,propped), /超出样本/);
  delete propped.hero_item_holdings;
  const equipment = prepareEquipment(manifest,propped);
  assert.equal(equipment.available,false);
  assert.equal(equipment.denominator,null);
  assert.equal(equipment.catalog.find(row=>row.id==='3084').games,null);
});

test('first legendary equipment retains its own release, cutoff and disclosure flag',()=>{
  const end='2026-11-17T18:00:00+08:00';
  const rule={file:'hero_augment_items.json',record:'first legendary_items record',reused_from:{patch:'16.22'},end_exclusive:end};
  const meta={patch:'16.23',components:{destiny:rule}};
  const report={source:'stats',show_winrate:true,items:[{item:3084,games:4,wins:3},{item:994403,games:2,wins:1}]};
  const equipment=prepareEquipment(manifest,tables,{},game);
  const verify=(m,t)=>prepareAugmentGear(m,t,equipment);
  const result=verify(meta,{'157':{'3081':report,'3078':report},'2':{'3081':{...report,show_winrate:false}}});
  assert.equal(result.augmentId,'3081');assert.equal(result.patch,'16.22');assert.equal(result.cutoff,end);
  assert.deepEqual(result.byHero['157'],[{id:'3084',games:4,winRate:75}]);
  assert.deepEqual(result.byHero['2'],[{id:'3084',games:4,winRate:null}]);
  assert.equal(verify({...meta,components:{destiny:{...rule,end_exclusive:null}}},{}),null);
});
