import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import test from 'node:test';
import vm from 'node:vm';

const script=await readFile(new URL('../public/library.js',import.meta.url),'utf8');
const baseSample={patch:'16.24',seq:21,heroes:[{id:'1'}],augments:[{id:'3265',name:'坚不可破',rarity:'silver'}]};
const champion={key:'1',id:'Annie',title:'安妮',name:'黑暗之女',tags:['Mage'],stats:{hp:560},partype:'法力'};
const ability={name:'测试技能',description:'技能<br>说明',image:{full:'Annie.png'}};
champion.passive=ability;champion.spells=Array(4).fill(ability);
const row={id:3265,augmentNameId:'Fortified',nameTRA:'坚不可破',rarity:'kSilver',
  augmentSmallIconPath:'/lol-game-data/assets/ASSETS/UX/Kiwi/Fortified.png'};
const aug={__type:'AugmentData',AugmentPlatformId:3265,AugmentNameId:'Fortified',NameTra:'Fortified_Name',
  DescriptionTra:'Fortified_Description',RootSpell:'effect'};
const mode={sample:aug,reference:{...aug,AugmentPlatformId:300,AugmentNameId:'Unsampled',NameTra:'other',DescriptionTra:'generic'},
  effect:{mSpell:{DataValues:[{name:'Armor',values:[20,20]}]}}};
const registry=[row,{...row,id:300,augmentNameId:'Unsampled',nameTRA:'仅玩法收录'},
  {...row,id:999,augmentNameId:'Arena',nameTRA:'仅竞技场收录'}];
const strings={'{37e9a81d30}':'坚不可破','{339cd63df0}':'获得<scaleArmor>@Armor@护甲</scaleArmor>。',
  other:'仅玩法收录',generic:'强化{{SpellName}}，增长@Unknown@。'};
function sandbox(state=new Map()){
  const requests=[];
  let missingStrings=false;
  const fetch=async (url,options)=>{
    requests.push({url,method:options.method || 'GET'});
    let value;
    if(url.endsWith('versions.json'))value=['16.25.1','16.24.2','16.24.1'];
    else if(url.endsWith('championFull.json')){
      const version=url.match(/cdn\/([\d.]+)\//)[1];
      value={version,data:{Annie:champion}};
    }else if(url.endsWith('kiwi.bin.json'))value=mode;
    else if(url.endsWith('augments.json'))value=registry;
    else if(!missingStrings && url.endsWith('stringtable.json'))value={entries:strings};
    return {ok:Boolean(value),headers:{get:()=>value?'test-revision':''},async json(){return value;}};
  };
  const ctx=vm.createContext({fetch,URL,AbortSignal,stats:structuredClone(baseSample),esc:String,artPath:v=>v,
    renderList(){},localStorage:{getItem:k=>state.get(k),setItem:(k,v)=>state.set(k,v)}});
  const run=code=>vm.runInContext(code,ctx);
  run(script);
  run(`championBook={version:'16.23.1',byId:{'1':{key:'Annie',keywords:['火女']}}};
    augmentBook={patch:'16.23',atlas:{columns:1,rows:1},byId:{'3265':{name:'坚不可破',description:'过期效果',iconIndex:0}}};`);
  return {run,requests,state,failStrings:v=>{missingStrings=v;}};
}

test('patch changes isolate previous definitions; runtime rebuilds mode-only reference and localized heroes',async()=>{
  const {run,requests,state}=sandbox();
  run("stats.equipment={catalogVersion:'16.23.9'};selectGameCatalogPatch(stats.patch)");
  assert.equal(run("definition(stats.augments[0])"),'');
  assert.equal(run("lookupAugmentIcon(stats.augments[0])"),'');
  assert.equal(run("championBook.byId"),undefined);
  await run('Promise.all([refreshGameCatalogs(),refreshGameCatalogs()])');
  assert.equal(requests.length,5);
  assert.equal(run('championBook.version'),'16.24.2');
  assert.equal(run("championBook.byId['1'].keywords[0]"),'火女');
  assert.equal(run("championBook.byId['1'].skills[4].slot"),'R');
  assert.equal(run("championBook.byId['1'].skills[4].description"),'技能\n说明');
  assert.equal(run('definition(stats.augments[0])'),'获得20护甲。');
  assert.equal(run("augmentBook.byId['300'].referenceOnly"),true);
  assert.equal(run("augmentBook.byId['999']"),undefined);
  assert.match(run("augmentBook.byId['300'].description"),/所选技能.*数值待核实/);
  assert.match(run('lookupAugmentIcon(stats.augments[0])'),/16\.24.*fortified\.png/);
  assert.doesNotMatch(run('lookupAugmentIcon(stats.augments[0])'),/augment-atlas/);

  const reopened=sandbox(state);
  reopened.run('selectGameCatalogPatch(stats.patch)');
  assert.equal(reopened.run('definition(stats.augments[0])'),'获得20护甲。');
  assert.equal(reopened.run("championBook.byId['1'].name"),'安妮');
  await reopened.run('refreshGameCatalogs()');
  assert.equal(reopened.requests.length,0);
  await reopened.run("stats.seq++;stats.augments.push({id:'300',name:'仅玩法收录',rarity:'silver'});refreshGameCatalogs()");
  assert.equal(reopened.requests.filter(r=>r.method==='HEAD').length,3);
  assert.equal(reopened.requests.filter(r=>r.method==='GET' && r.url.includes('communitydragon')).length,0);
  assert.equal(reopened.run("augmentBook.byId['300'].referenceOnly"),false);
});

test('a late translation archive can be retried; failed rechecks retain verified matching texts',async()=>{
  const {run,failStrings}=sandbox();
  failStrings(true);
  await run('refreshGameCatalogs()');
  assert.equal(run('augmentBook.textAvailable'),false);
  assert.equal(run('definition(stats.augments[0])'),'');
  assert.match(run('lookupAugmentIcon(stats.augments[0])'),/fortified\.png/);
  failStrings(false);
  await run('refreshGameCatalogs(true)');
  assert.equal(run('definition(stats.augments[0])'),'获得20护甲。');
  failStrings(true);
  await run('refreshGameCatalogs(true)');
  assert.equal(run('definition(stats.augments[0])'),'获得20护甲。');
});

test('a request for the previous patch cannot repopulate a newly selected version',async()=>{
  const {run}=sandbox();
  await run("const old=refreshGameCatalogs(); stats={...stats,patch:'16.25'};selectGameCatalogPatch(stats.patch);old");
  assert.equal(run('championBook.byId'),undefined);
  assert.equal(run('augmentBook.byId'),undefined);
});

test('a later patch reads fixed spell keys and disabled flags, and leaves other ability augments unresolved',async()=>{
  const {run}=sandbox();
  const targetCode=await readFile(new URL('../public/skill-targets.js',import.meta.url),'utf8');
  run(targetCode);
  const book=run(`buildModeCatalog(stats,{kiwi:'https://raw.communitydragon.org/16.24/game/maps/modespecificdata/kiwi.bin.json'},
    {one:{__type:'AugmentData',AugmentPlatformId:1,AugmentNameId:'GoH_PentakillAug_W',DescriptionTra:'Kiwi_GoH_PentakillAug_Generic_Description',NameTra:'one',IsAbilityAugment:true},
    two:{__type:'AugmentData',AugmentPlatformId:2,AugmentNameId:'Variable',DescriptionTra:'other',NameTra:'two',IsAbilityAugment:true,Enabled:false}},
    [{id:1,augmentNameId:'GoH_PentakillAug_W',nameTRA:'固定',rarity:'kGold'},{id:2,augmentNameId:'Variable',nameTRA:'指定',rarity:'kGold'}],{})`);
  assert.equal(book.byId['1'].fixedSlot,'W');assert.equal(book.byId['2'].modeDisabled,true);
  run('augmentBook='+JSON.stringify(book)+';augmentSkillBook={patch:"16.23",byId:{2:{slots:["R"]}}}');
  assert.equal(run('skillTarget("1").slots[0]'),'W');assert.equal(run('skillTarget("2").kind'),'champion');
  assert.equal(run('skillTarget("2").slots'),undefined);
});
