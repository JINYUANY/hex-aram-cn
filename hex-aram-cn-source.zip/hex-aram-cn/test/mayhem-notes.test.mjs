import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { parseMayhemArticle, fetchMayhemNotes } from '../src/mayhem-notes.mjs';

const official = { patch: '26.23', samplePatch: '16.23', url: 'https://lol.qq.com/gicp/news/410/37102797.html',
  title: '26.23版本更新公告', publishedAt: '2026-11-18T18:51:48+08:00', hotfixes: [] };
const article = '<h1>26.23版本更新公告</h1><h3>英雄</h3><p>海克斯大乱斗</p>' +
  '<h3><strong>海克斯大乱斗</strong></h3><blockquote><p>模式简介</p></blockquote>' +
  '<h4>英雄</h4><p><strong>布兰德</strong></p><ul><li>承受伤害：110% &rArr; 105%</li></ul>' +
  '<p><strong>亚索</strong></p><li>总攻击速度提升：2.5% → 0%</li>' +
  '<h4>强化符文</h4><p><strong>弹跳蜜蜂</strong></p><li>伤害：50-100% ⇒ 60%</li>' +
  '<p><strong>新增&nbsp;坚不可破</strong></p><p>获得20护甲。</p>' +
  '<h4>BUG修复</h4><li>修复了【修复项】的文本。</li><li>修复了问题。（注：暂未修复）</li>' +
  '<h3>极地大乱斗</h3><h4>英雄</h4><p><b>仅经典大乱斗</b></p><li>伤害：5 ⇒ 8</li>';

test('only dedicated Mayhem entries, preserving title, numbers, annotations and provenance', () => {
  const result = parseMayhemArticle(official, article);
  assert.deepEqual(result.entries.map(x => x.kind), ['buff', 'nerf', 'adjust', 'new', 'fix', 'other']);
  assert.deepEqual(result.entries[0], { kind: 'buff', category: '英雄', name: '布兰德', details: ['承受伤害：110% ⇒ 105%'], basis: '数值方向' });
  assert.equal(result.entries[3].name, '坚不可破');
  assert.deepEqual(result.entries.at(-1).details, ['修复了问题。（注：暂未修复）']);
  assert.equal(result.title, official.title);
  assert.equal(result.publishedAt, official.publishedAt);
  assert.equal(result.url, official.url);
});

test('group compound effects conservatively, preserve standalone subjects and removed augments', () => {
  const detail = '<h4>英雄</h4><p><strong>李青</strong></p><li>伤害：5 ⇒ 8</li>' +
    '<li>斯维因</li><li>承受伤害：105% ⇒ 100%</li><li>伤害：90 ⇒ 80</li>' +
    '<h4>赛季之星</h4><li><strong>心之钢</strong>：描述</li>' +
    '<h4>已移除的强化符文</h4><li>炽燃利息</li><h3>下节</h3>';
  const result = parseMayhemArticle(official, '<h1>26.23版本公告</h1><h3>海克斯大乱斗</h3>' + detail);
  assert.deepEqual(result.entries.map(x => [x.name, x.kind]), [['李青','buff'], ['斯维因','adjust'], ['心之钢','adjust'], ['炽燃利息','adjust']]);
  assert.deepEqual(result.entries.at(-1).details, ['已移除的强化符文']);
});

test('ignore navigation, mentions and unrecognized layouts, reject stale version and non-Tencent origin', () => {
  assert.throws(() => parseMayhemArticle(official, article.replace('<h1>26.23', '<h1>26.22')), /版本不一致/);
  assert.throws(() => parseMayhemArticle(official, article.replace('<strong>海克斯大乱斗</strong>', '模式综述')), /尚未识别/);
  assert.throws(() => parseMayhemArticle(official, '<h1>26.23版本公告</h1><h3>海克斯大乱斗</h3><table><tr><td>未知布局</td></tr></table>'), /尚未识别/);
  assert.throws(() => parseMayhemArticle({ ...official, url: 'https://example.org/' }, article), /腾讯版本公告/);
});

test('fetches canonical source, fails on an upstream HTTP error', async () => {
  const result = await fetchMayhemNotes(official, async url => {
    assert.equal(url, official.url);
    return new Response(article);
  });
  assert.equal(result.entries.length, 6);
  await assert.rejects(fetchMayhemNotes(official, async () => new Response('missing', { status: 404 })), /404/);
});

test('bundled snapshot keeps per-entry source fields across daily live refreshes', () => {
  const seed = JSON.parse(readFileSync(new URL('../data/mayhem-notes.json', import.meta.url)));
  assert.equal(new URL(seed.url).origin, 'https://lol.qq.com');
  assert.equal(seed.schema, 1);
  assert.ok(Number.isFinite(Date.parse(seed.publishedAt)));
  assert.ok(seed.entries.length && seed.entries.every(x => x.category && x.name && x.details?.length));
});

const hotfix = { title: '11月20日 不停机更新', url: 'https://lol.qq.com/news/detail.shtml?docid=9000000000000000017',
  publishedAt: '2026-11-20T12:00:00+08:00' };
const cmcHeading = label => '<p><span style="font-size: 18px;"><strong>' + label + '</strong></span></p>';
const cmcBullet = line => '<p><span style="font-size: 14px;">●</span>' + line + '</p>';
const cmcHotfix = cmcHeading('惩戒之箭 韦鲁斯') + cmcBullet('不应计入韦鲁斯条目') +
  cmcHeading('海克斯大乱斗 BUG修复') + cmcBullet('修复了一个BUG，该BUG曾导致：李青的W护盾值不随技能等级增长。') +
  cmcBullet('修复了【升级：风暴狂涌】的问题。') + cmcHeading('经典模式') + cmcBullet('不应计入经典模式修复');
const cmcDocument = changes => ({ data: { result: { sAuthor: '英雄联盟官方', sTitle: hotfix.title,
  iDocID: '9000000000000000017', sContent: cmcHotfix, ...changes } } });
const withHotfix = (changes, hotfixes = [hotfix]) => fetchMayhemNotes({ ...official, hotfixes }, async url => {
  if (url === official.url) return new Response(article);
  assert.equal(url, 'https://apps.game.qq.com/cmc/zmMcnContentInfo?r0=json&source=web_pc&type=0&docid=9000000000000000017');
  return Response.json(cmcDocument(changes));
});

test('Tencent CMC hotfix preserves source and only the explicitly headed mode subsection', async () => {
  const result = await withHotfix({});
  assert.equal(result.entries.length, 6);
  assert.deepEqual(result.hotfixes, [hotfix]);
  assert.equal(result.hotfixDetails.length, 1);
  const { entries, ...metadata } = result.hotfixDetails[0];
  assert.deepEqual(metadata, hotfix);
  assert.deepEqual(entries.map(x => [x.kind, x.category, x.name]), [
    ['fix', 'BUG修复', '李青的W护盾值不随技能等级增长'], ['fix', 'BUG修复', '升级：风暴狂涌'],
  ]);
});

test('missing mode, mismatched Tencent document, unsafe redirect and older patch keep only the source link', async () => {
  for (const invalid of [{ sAuthor: '投稿' }, { sTitle: '标题已变更' }, { iDocID: '17' },
    { sRedirectURL: 'https://example.org/news' }, { sContent: cmcBullet('本期热修涉及海克斯大乱斗。') },
    { sContent: cmcHeading('海克斯大乱斗') + '<p>未知结构</p>' }]) {
    const result = await withHotfix(invalid);
    assert.equal(result.entries.length, 6);
    assert.deepEqual(result.hotfixes, [hotfix]);
    assert.deepEqual(result.hotfixDetails, []);
  }
  const previous = { ...hotfix, publishedAt: '2026-10-23T16:25:24+08:00' };
  assert.deepEqual((await withHotfix({}, [previous])).hotfixDetails, []);
});

test('one unreadable hotfix cannot prevent another official HTML hotfix from loading', async () => {
  const broken = { ...hotfix, url: 'https://lol.qq.com/gicp/news/410/37102890.html' };
  const readable = { ...hotfix, url: 'https://lol.qq.com/gicp/news/410/37102899.html' };
  const result = await fetchMayhemNotes({ ...official, hotfixes: [broken, readable] }, async url => {
    if (url === official.url) return new Response(article);
    if (url === broken.url) return new Response('', { status: 404 });
    return new Response(article.replace('26.23版本更新公告', hotfix.title));
  });
  assert.equal(result.hotfixes.length, 2);
  assert.deepEqual(result.pendingHotfixes,[broken.url]);
  assert.deepEqual(result.hotfixDetails.map(x => x.url), [readable.url]);
  assert.equal(result.hotfixDetails[0].entries.length, 6);
});
