import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {runInNewContext} from 'node:vm';
const source=await readFile(new URL('../scripts/download-updates.js',import.meta.url),'utf8');
const build='a'.repeat(64);
const release={project:'hex-aram-cn',build,builtAt:10,version:'1.1.0'};
async function check(published){
  const nodes=new Map();
  const node=()=>({append(){},replaceChildren(){},addEventListener(){},textContent:''});
  const document={hidden:false,addEventListener(){},createElement:node,createDocumentFragment:node,getElementById(id){
    if(!nodes.has(id))nodes.set(id,node());return nodes.get(id);
  }};
  let destination=null;
  const location={hash:'#?hero=4&view=targets',search:'',origin:'null',href:'file:///guide.html',
    replace(href){destination=href;}};
  const fetch=async url=>{
    if(String(url).includes('CHANGELOG.md'))return new Response('## 1.1.0 · 2026-11-21\n- 更新');
    if(!published)throw TypeError('offline');
    return Response.json(published);
  };
  runInNewContext(source+'\nstartReleaseCheck(release,"## 1.1.0\\n- 内置公告");',{
    document,location,URL,release,fetch,AbortSignal,window:{addEventListener(){}},setInterval(){}
  });
  await new Promise(resolve=>setImmediate(resolve));
  return {destination,status:nodes.get('release-check-status').textContent};
}
test('download opens the published HTTPS edition on a newer build and retains the selected hero',async()=>{
  const result=await check({...release,build:'b'.repeat(64),builtAt:11});
  const u=new URL(result.destination);assert.equal(u.origin,'https://jinyuany.github.io');
  assert.equal(u.pathname,'/hex-aram-cn/');assert.equal(u.hash,'#?hero=4&view=targets');
});
test('same build, offline and older manifests leave the open copy usable',async()=>{
  assert.match((await check(release)).status,/已是最新/);
  assert.match((await check(null)).status,/继续使用/);
  assert.equal((await check({...release,build:'b'.repeat(64),builtAt:9})).destination,null);
});

test('semantic versions take precedence over build clocks',async()=>{
  assert.equal((await check({...release,version:'1.0.9',build:'b'.repeat(64),builtAt:100})).destination,null);
  assert.ok((await check({...release,version:'1.10.0',build:'b'.repeat(64),builtAt:9})).destination);
});
