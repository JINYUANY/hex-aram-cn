import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {fetchStats} from '../src/stats.mjs';

const raw='https://raw.githubusercontent.com/czgreat/aramhex-data/';
const cutoff='2026-11-20T00:00:00Z';
function fixture(){
  const patch='16.23',seq=20,path='patches/'+patch+'/normal';
  const metadata={mode:'normal',patch,snapshot_at:cutoff,augment_exposure:'结算持有，六槽去重',window:{start:'2026-11-19T00:00:00Z',end_exclusive:cutoff},
    matches:{valid:1},hero_participations:10,regions:['测试'],equipment:{recommendation_table:'hero_item_recommendations.json',
      recommendation_denominator:'equipment_recommendation_heroes.json',recommendation_participations:8,
      tables:{'hero_item_holdings.json':'全部装备'}}};
  const tables={
    meta:metadata,heroes:{1:{name:'测试英雄',title:'测试',games:10,wins:5}},augments:{1001:{name:'测试强化',rarity:'gold'}},
    hero_augments:{1:{1001:{games:6}}},item_metadata:{1011:{name:'装备',category:'complete_equipment'}},
    hero_items:{1:{1011:{games:2,wins:1}}},hero_item_recommendations:{1:{1011:{games:4,wins:2}}},
    equipment_recommendation_heroes:{1:{games:8}},hero_item_holdings:{1:{1011:{games:6,wins:2}}},equipment_heroes:{1:{games:10}}
  };
  const files=Object.fromEntries(Object.entries(tables).map(([name,value])=>[name+'.json',{sha256:createHash('sha256').update(JSON.stringify(value)).digest('hex')}]));
  const manifest={schema_version:1,seq,patch,mode:'normal',matches:1,path,snapshot_at:cutoff,files};
  const index={latest_seq:seq, datasets:[manifest]};
  const state={manifest,index,tables,community:true,revision:1,requests:[],fallbackPath:'',corrupt:''};
  state.fetch=async (u)=>{
    state.requests.push(u);
    if(u===raw+'main/latest.json')return Response.json(manifest);
    let key;
    if(u.startsWith(raw+'data-v20/')){
      key=u.slice((raw+'data-v20/').length);
      if(state.fallbackPath===key)return new Response(null,{status:503});
    }else if(u.startsWith('https://api.github.com/repos/czgreat/aramhex-data/contents/')){
      key=new URL(u).pathname.split('/contents/')[1];
      assert.equal(new URL(u).searchParams.get('ref'),'data-v20');
    }
    if(key==='index.json')return Response.json(index);
    if(key?.startsWith(path+'/')){
      const name=key.slice(path.length+1,-5);
      return Response.json(state.corrupt===name?{}:tables[name]);
    }
    const version=patch+'.'+state.revision;
    if(u.endsWith('/api/versions.json'))return Response.json(['16.23.1','16.22.1',version]);
    if(u.endsWith('/data/zh_CN/item.json'))return Response.json({version,data:{1011:{name:'神奇装备',tags:['Health'],image:{full:'1011.png'}}}});
    if(u.endsWith('/data/zh_CN/champion.json'))return Response.json({version,data:{Hero:{key:'1',id:'Hero'}}});
    if(u.includes('/zh_cn/v1/items.json') && state.community)return Response.json([{id:1011,name:'神奇装备',description:'<stats>150生命值</stats>'}]);
    return new Response(null,{status:404});
  };
  return state;
}

test('same release fills a missing item catalog and applies game data build revisions on manual refresh',async()=>{
  const f=fixture();f.community=false;
  const partial=await fetchStats(19,null,false,f.fetch);
  assert.equal(partial.seq,20);assert.equal(partial.enrichment.communityItems,'pending');
  assert.equal(partial.enrichment.previousHoldings,'not-published');
  assert.equal(partial.heroes[0].items[0].games,4);
  assert.equal(partial.heroes[0].items[0].holdRate,50);
  f.community=true;
  const repaired=await fetchStats(20,partial,false,f.fetch);
  assert.equal(repaired.enrichment.communityItems,'ready');
  assert.deepEqual(repaired.equipment.catalog[0].attributes,['150生命值']);
  assert.notEqual(repaired.revision,partial.revision);
  f.requests.length=0;
  assert.equal(await fetchStats(20,repaired,false,f.fetch),null);
  assert.deepEqual(f.requests,[raw+'main/latest.json']);
  f.requests.length=0;
  assert.equal(await fetchStats(20,repaired,true,f.fetch),null);
  assert.ok(!f.requests.some(u=>u.includes('/data-v20/')));
  f.revision=2;
  const hotfix=await fetchStats(20,repaired,true,f.fetch);
  assert.equal(hotfix.equipment.catalogVersion,'16.23.2');assert.match(hotfix.heroes[0].icon,/16\.23\.2/);
  assert.notEqual(hotfix.revision,repaired.revision);
  f.community=false;await assert.rejects(fetchStats(20,hotfix,true,f.fetch),/保留/);
});

test('raw CDN can fail independently; neither transport can replace mismatched checksums or an inconsistent index',async()=>{
  const f=fixture();f.fallbackPath=f.manifest.path+'/heroes.json';
  assert.equal((await fetchStats(0,null,false,f.fetch)).matches,1);
  assert.ok(f.requests.some(u=>u.startsWith('https://api.github.com/repos/czgreat/aramhex-data/contents/')));
  f.corrupt='heroes';await assert.rejects(fetchStats(0,null,false,f.fetch),/发布清单不一致/);
  f.corrupt='';f.index.latest_seq=21;await assert.rejects(fetchStats(0,null,false,f.fetch),/索引与批次清单不符/);
});

test('refuse missing recommendation tables declared by release metadata',async()=>{
  const f=fixture();delete f.manifest.files['hero_item_recommendations.json'];
  await assert.rejects(fetchStats(0,null,false,f.fetch),/缺少元数据声明的明细表/);
  const incomplete=fixture();delete incomplete.manifest.files['hero_item_holdings.json'];
  await assert.rejects(fetchStats(0,null,false,incomplete.fetch),/缺少元数据声明的明细表/);
  const wrongDenominator=fixture();
  wrongDenominator.tables.equipment_recommendation_heroes[1].games=7;
  wrongDenominator.manifest.files['equipment_recommendation_heroes.json'].sha256=createHash('sha256')
    .update(JSON.stringify(wrongDenominator.tables.equipment_recommendation_heroes)).digest('hex');
  await assert.rejects(fetchStats(0,null,false,wrongDenominator.fetch),/推荐装备分母与元数据不一致/);
});

test('reject rewrites to the same publication sequence even during an automatic check',async()=>{
  const f=fixture();
  const current=await fetchStats(0,null,false,f.fetch);
  f.manifest.matches=2;
  await assert.rejects(fetchStats(20,current,false,f.fetch),/清单发生变化/);
  f.manifest.patch='16.24';
  f.manifest.path='patches/16.24/normal';
  await assert.rejects(fetchStats(20,current,true,f.fetch),/版本发生变化/);
});

test('retries a temporarily unreachable prior release and distinguishes a verified incompatible cohort',async()=>{
  for(const comparable of [true,false]){
    const f=fixture();
    const path='patches/16.22/normal',previousCutoff='2026-11-17T10:00:00Z';
    const meta={...f.tables.meta,patch:'16.22',snapshot_at:previousCutoff,window:{end_exclusive:previousCutoff},
      augment_exposure:comparable?f.tables.meta.augment_exposure:'其他统计口径'};
    const records={meta,heroes:f.tables.heroes,hero_augments:f.tables.hero_augments};
    const files=Object.fromEntries(Object.entries(records).map(([name,data])=>[name+'.json',{sha256:createHash('sha256')
      .update(JSON.stringify(data)).digest('hex')}]));
    f.index.datasets.push({path,patch:'16.22',snapshot_at:previousCutoff,matches:1,mode:'normal',files});
    let available=false;
    const read=(u,opts)=>{
      if(!u.includes(path+'/'))return f.fetch(u,opts);
      const name=new URL(u).pathname.split('/').at(-1).slice(0,-5);
      return available?Response.json(records[name]):new Response(null,{status:503});
    };
    const partial=await fetchStats(0,null,false,read);
    assert.equal(partial.enrichment.previousHoldings,'pending');
    available=true;
    const recovered=await fetchStats(20,partial,false,read);
    assert.equal(recovered.enrichment.previousHoldings,comparable?'ready':'not-comparable');
    assert.equal(recovered.holdingBaseline?.patch,comparable?'16.22':undefined);
    assert.equal(await fetchStats(20,recovered,false,read),null);
  }
});

test('the high-score build table follows its own dataset version and checksum, ignoring event datasets',async()=>{
  const {fetchHighBuilds}=await import('../src/stats.mjs');
  const cutoff='2026-11-17T18:00:00+08:00',base='https://raw.githubusercontent.com/czgreat/aramhex-data/data-v20/';
  const file='bands/high/core_builds.json',table={157:[{ordered:true,items:['3032','123430','6333'],games:20,wins:12}]};
  const meta={patch:'16.22',mode:'normal',snapshot_at:cutoff,bands:{bands:{high:{label:'前5%'}}},
    equipment:{bands:['high'],core_table:'core_builds.json'}};
  const hash=o=>({sha256:createHash('sha256').update(JSON.stringify(o)).digest('hex')});
  const normal={...meta,bands:true,path:'patches/16.22/normal',files:{[file]:hash(table),'meta.json':hash(meta)}};
  const current={patch:'16.23',snapshot_at:'2026-11-20T08:00:00+08:00'};
  const index={datasets:[normal,{...normal,...current,mode:'first-prismatic',path:'patches/16.23/first-prismatic'}]};
  const eq={catalog:table[157][0].items.map(id=>({id,canShowWinRate:true}))};
  const fetcher=async url=>Response.json(url.includes('meta.json')?meta:table);
  const data=await fetchHighBuilds(base,index,current,eq,fetcher);
  assert.equal(data.patch,'16.22');assert.equal(data.cutoff,cutoff);assert.equal(data.byHero[157][0].winRate,60);
  eq.catalog[1].canShowWinRate=false;
  assert.equal((await fetchHighBuilds(base,index,current,eq,fetcher)).byHero[157][0].winRate,null);
  table[157][0].games=21;
  await assert.rejects(fetchHighBuilds(base,index,current,eq,fetcher),/不一致/);
});

function withSpells(f,table){
  f.tables.hero_spells=table;
  f.manifest.files['hero_spells.json']={sha256:createHash('sha256').update(JSON.stringify(table)).digest('hex')};
  const read=f.fetch;
  f.fetch=(url,opts)=>url.endsWith('/summoner.json')?Response.json({version:'16.23.1',data:{
    Flash:{key:'4',name:'闪现',image:{full:'SummonerFlash.png'}},Mark:{key:'32',name:'标记',image:{full:'SummonerSnowball.png'}}}}):read(url,opts);
}

test('a legacy snapshot of the same batch gains verified summoner pairs and recovers after a file outage',async()=>{
  const f=fixture(),old=await fetchStats(0,null,false,f.fetch);
  delete old.enrichment.summonerSpells;delete old.summonerSpells;
  withSpells(f,{1:{'32+4':{games:8}}});
  f.corrupt='hero_spells';
  const partial=await fetchStats(20,old,false,f.fetch);
  assert.equal(partial.enrichment.summonerSpells,'pending');assert.equal(partial.matches,1);
  f.corrupt='';
  const fresh=await fetchStats(20,partial,false,f.fetch);
  assert.deepEqual(fresh.summonerSpells.byHero[1],{games:8,pairs:{'4+32':8}});
  assert.equal(fresh.summonerSpells.catalog[4].name,'闪现');
  assert.equal(fresh.summonerSpells.cutoff,cutoff);assert.equal(fresh.enrichment.summonerSpells,'ready');
  assert.equal(await fetchStats(20,fresh,false,f.fetch),null);
  withSpells(f,{1:{'4+32':{games:6}}});
  await assert.rejects(fetchStats(20,fresh,true,f.fetch),/同批召唤师技能清单/);
});

test('new batch without usable summoner data retains the previous sample and its cutoff',async()=>{
  const f=fixture();withSpells(f,{1:{'4+32':{games:8}}});
  const current=await fetchStats(0,null,false,f.fetch);
  const prior={...current,seq:19,summonerSpells:{...current.summonerSpells,seq:19,patch:'16.22',cutoff:'2026-11-17T10:00:00Z'}};
  for(const table of [{1:{'4+32':{games:11}}},{1:{'4+32':{games:1},'32+4':{games:1}}},{1:{'4+4':{games:2}}},null]){
    if(table)withSpells(f,table);else delete f.manifest.files['hero_spells.json'];
    const updated=await fetchStats(19,prior,false,f.fetch);
    assert.deepEqual(updated.summonerSpells,prior.summonerSpells);
    assert.equal(updated.enrichment.summonerSpells,table?'pending':'not-published');
    assert.equal(updated.seq,20);
  }
});
