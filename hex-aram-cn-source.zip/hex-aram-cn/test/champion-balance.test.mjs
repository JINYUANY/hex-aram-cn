import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {fetchChampionBalance,validateChampionBalance} from '../src/champion-balance.mjs';

const roster=[{id:157,name:'亚索',alias:'Yasuo'},{id:429,name:'卡莉丝塔',alias:'Kalista'},{id:266,name:'亚托克斯',alias:'Aatrox'}];
const official={patch:'26.23',samplePatch:'16.23',balanceNotices:{documents:[]}};
const classicData=`return {
  ["Yasuo"] = {
    ["id"] = 157,
    ["changes"] = "V26.23",
    ["stats"] = { ["ms"] = 1,
      ["aram"] = {
        ["total_as"] = 1.025,
        --["tenacity"] = 9,
      },
    },
  },
  ["Kalista"] = {
  \t["id"] = 429,
      ["aram"] = {
        ["dmg_taken"] = 0.9,
      },
      ["aram"] = {
        ["dmg_taken"] = 1,
      },
  },
  ["Aatrox"] = {
    ["id"] = 266,
    ["stats"] = {
      ["aram"] = {["dmg_dealt"] = 1.05,},
    },
  }
}`;
const mayhemData=`=== List of mode overrides ===
Champions=
{| class="article-table"
|-
| {{ci|Yasuo}}
| Special modifiers
* Total attack speed increase changed to 0% from +{{fd|2.5}}%.
| {{ai|W|Yasuo}}
* Damage dealt changed to +10% from -1%.
|-
| {{ci|Kalista}}
| Special modifiers
* Damage received changed to -5% from -10%.
|
|}`;
function wiki({classic=classicData,mayhem=mayhemData,comment='[[V26.23]]',unavailable}={}) {
  return async url=>{
    const q=new URL(url).searchParams, classicPage=q.get('titles')==='Module:ChampionData/data';
    if(unavailable==='all' || (unavailable==='classic' && classicPage) || (unavailable==='mayhem' && !classicPage))throw Error('offline');
    const title=classicPage?'Module:ChampionData/data':'ARAM: Mayhem';
    const history=q.has('rvlimit');
    const rev={revid:classicPage?21:22,timestamp:'2026-11-18T01:00:00Z'};
    if(history)rev.comment=comment;
    else rev.slots={main:{content:classicPage?classic:mayhem}};
    return Response.json({query:{pages:[{title,revisions:[rev]}]}});
  };
}
const metrics=row=>Object.fromEntries(row.metrics.map(m=>[m.key,m.value]));
test('normalizes explicit mode values independently, excludes missing fields, skill changes, comments and overridden Lua keys',async()=>{
  const data=await fetchChampionBalance(official,roster,null,wiki());
  assert.deepEqual(metrics(data.modes.aram.byHero[157]),{total_as:2.5});
  assert.deepEqual(metrics(data.modes.mayhem.byHero[157]),{total_as:0});
  assert.deepEqual(metrics(data.modes.aram.byHero[429]),{dmg_taken:100});
  assert.deepEqual(metrics(data.modes.mayhem.byHero[429]),{dmg_taken:95});
  assert.equal(data.modes.mayhem.byHero[266],undefined);
  assert.deepEqual(metrics(data.modes.aram.byHero[266]),{dmg_dealt:105});
  assert.match(data.modes.mayhem.byHero[157].source.url,/PermanentLink\/22$/);
});
test('latest same-patch Tencent main/hotfix metrics take priority with individual source dates',async()=>{
  const doc={url:'https://lol.qq.com/news/a',publishedAt:'2026-11-19T03:00:00Z',patch:'26.23',samplePatch:'16.23'};
  const data=await fetchChampionBalance({...official,balanceNotices:{documents:[
    {...doc,entries:[{name:'亚索',mode:'mayhem',details:['总攻击速度提升：2.5% ⇒ 0%', '对小兵的造成伤害：75% ⇒ 90%']}]},
    {...doc,url:doc.url+'-fix',publishedAt:'2026-11-20T03:00:00Z',entries:[{name:'亚索',mode:'mayhem',details:['总攻击速度提升：0% → 2%']}]},
    {...doc,patch:'26.22',samplePatch:'16.22',entries:[{name:'亚托克斯',mode:'mayhem',details:['造成伤害：100% ⇒ 90%']}]}
  ]}},roster,null,wiki());
  assert.deepEqual(metrics(data.modes.mayhem.byHero[157]),{total_as:2});
  assert.equal(data.modes.mayhem.byHero[157].metrics[0].source.url,doc.url+'-fix');
  assert.equal(data.modes.aram.byHero[157].metrics[0].source,undefined);
  assert.equal(data.modes.mayhem.byHero[266],undefined);
});
test('keeps only a matching verified revision through outages and fails each missing or mismatched source independently',async()=>{
  const data=await fetchChampionBalance(official,roster,null,wiki());
  const cached=await fetchChampionBalance(official,roster,data,wiki({unavailable:'all'}));
  assert.equal(cached.modes.aram.status,'cached');
  assert.deepEqual(cached.modes.mayhem.byHero,data.modes.mayhem.byHero);
  const partial=await fetchChampionBalance(official,roster,null,wiki({comment:'[[V26.22]]'}));
  assert.equal(partial.modes.mayhem.status,'pending');
  assert.equal(partial.modes.aram.status,'ready');
  const mention=await fetchChampionBalance(official,roster,null,wiki({comment:'Revert old [[V26.23]] value'}));
  assert.equal(mention.modes.mayhem.status,'pending');
  const bumped=await fetchChampionBalance({...official,patch:'26.24',samplePatch:'16.24'},roster,data,wiki());
  assert.deepEqual(bumped.modes.aram.byHero,{});
  assert.deepEqual(bumped.modes.mayhem.byHero,{});
  assert.throws(()=>validateChampionBalance(data,'16.24'));
  const tampered=structuredClone(data);tampered.modes.aram.byHero[157].source.url='https://example.org/spoof';
  assert.throws(()=>validateChampionBalance(tampered,'16.23'));
});
test('a new patch can show Tencent figures before either Wiki table is ready',async()=>{
  const url='https://lol.qq.com/news/patch';
  const doc={patch:'26.24',samplePatch:'16.24',url,publishedAt:'2026-12-01T12:00:00Z'};
  const result=await fetchChampionBalance({...doc,hotfixes:[],mayhem:{...doc,balanceEntries:[
    {mode:'mayhem',name:'亚索',details:['造成伤害：100% ⇒ 105%']}
  ],balanceHotfixes:[{url:'https://lol.qq.com/news/unlisted',publishedAt:'2026-12-02T12:00:00Z',
    entries:[{mode:'mayhem',name:'亚索',details:['造成伤害：105% ⇒ 80%']}]}]}},roster,null,wiki({unavailable:'all'}));
  assert.equal(result.modes.mayhem.status,'pending');
  assert.deepEqual(metrics(result.modes.mayhem.byHero[157]),{dmg_dealt:105});
  assert.equal(result.modes.mayhem.byHero[157].source.url,url);
  assert.deepEqual(result.modes.aram.byHero,{});
});
test('bundled figures keep actual versions, permanent links, Tencent announcement provenance and mode-specific values',async()=>{
  const data=JSON.parse(await readFile(new URL('../data/champion-balance.json',import.meta.url),'utf8'));
  assert.doesNotThrow(()=>validateChampionBalance(data,data.patch));
  if(data.officialPatch!=='26.23')return;
  assert.equal(data.modes.aram.byHero[157].metrics.find(m=>m.key==='total_as').value,2.5);
  assert.equal(data.modes.mayhem.byHero[157].metrics.find(m=>m.key==='total_as').value,0);
  assert.match(data.modes.mayhem.byHero[157].metrics.find(m=>m.key==='total_as').source.url,/^https:\/\/lol.qq.com\//);
  assert.equal(data.modes.aram.byHero[429].metrics.find(m=>m.key==='dmg_taken').value,100);
  assert.equal(data.modes.mayhem.byHero[429].metrics.find(m=>m.key==='dmg_taken').value,95);
  assert.ok(Object.keys(data.modes.aram.byHero).length>=155);
  assert.ok(Object.keys(data.modes.mayhem.byHero).length>=60);
});

test('a champion with only a skill change has its own scope, can refresh, and has no invented general values',async()=>{
  const mayhem=`=== List of mode overrides ===
Champions=
{| class="article-table"
|-
| {{ci|Yasuo}}
|
| {{ai|Q|Yasuo}}
* Cooldown changed to {{ap|18 to 14}} seconds.
* Only while moving, the next hit gains 10 units.
{{ai|W|Kalista}}
* Damage reduction changed to 45%.
General
* Abilities' damage to minions increased to 100% from 60%.
|}`;
  const first=await fetchChampionBalance(official,roster,null,wiki({mayhem}));
  const {aram,mayhem:mode}=first.modes;
  assert.equal(mode.byHero['157'],undefined);
  assert.equal(aram.skillsByHero,undefined);
  const groups=mode.skillsByHero['157'];
  assert.deepEqual(groups.map(g=>g.slot),['Q','all']);
  assert.deepEqual(groups[0].details,[{lang:'zh-CN',text:'冷却时间调整为 18/17/16/15/14 秒。'},
    {lang:'en',text:'Only while moving, the next hit gains 10 units.'}]);
  const cached=await fetchChampionBalance(official,roster,first,wiki({unavailable:'all'}));
  assert.deepEqual(cached.modes.mayhem.skillsByHero,mode.skillsByHero);
  const future=await fetchChampionBalance({...official,patch:'26.24',samplePatch:'16.24'},roster,first,wiki({unavailable:'all'}));
  assert.equal(future.modes.mayhem.skillsByHero,undefined);
  const changed=await fetchChampionBalance(official,roster,first,wiki({mayhem:mayhem.replace('18 to 14','22 to 18')}));
  assert.match(changed.modes.mayhem.skillsByHero['157'][0].details[0].text,/22\/21\/20\/19\/18/);
  const invalid=structuredClone(first);invalid.modes.aram.skillsByHero=mode.skillsByHero;
  assert.throws(()=>validateChampionBalance(invalid,first.patch));
  const legacy=structuredClone(first);delete legacy.modes.mayhem.skillsByHero;
  assert.equal(validateChampionBalance(legacy,first.patch),legacy);
});

test('patched Wiki rows bind to the correct localized form or all skills with their original conditions',async()=>{
  const data=JSON.parse(await readFile(new URL('../data/champion-balance.json',import.meta.url),'utf8'));
  if(data.officialPatch!=='26.23')return;
  const s=data.modes.mayhem.skillsByHero;
  assert.equal(Object.keys(s).length,17);
  assert.equal(Object.values(s).flat().flatMap(g=>g.details).length,35);
  assert.equal(data.modes.mayhem.byHero['106'],undefined);
  assert.deepEqual([s['106'][0].slot,s['106'][0].name],['E','霹天雳地']);
  assert.match(s['106'][0].details[0].text,/11%.*14%.*最大生命值/);
  assert.equal(s['64'][1].name,'回音击（二段 Q）');
  assert.match(s['64'][1].details[1].text,/160\/240\/320\/400\/480/);
  assert.match(s['240'][0].details[0].text,/己方泉水.*0\.25.*25.*与预期不符/);
  assert.equal(s['910'][0].slot,'all');
  assert.match(s['17'][0].details[0].text,/小兵.*66%.*100%/);
});
