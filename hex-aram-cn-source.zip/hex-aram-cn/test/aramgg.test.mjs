import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {runInNewContext} from 'node:vm';
import {fetchAramgg,getTrios} from '../src/aramgg.mjs';

const config={service:'aramgg-data-api',schemaVersion:1,locale:'zh-CN',gamePatch:'16.24',apiRelease:1,
  dataVersion:'16.24.1',publishedAt:'2026-12-02T03:00:00Z',matchHistoryUpload:{collectionPolicy:{targetGamePatch:'16.25'}}};
const cn={id:157,name:'亚索',stats:{gamePatch:'16.24',region:'CN',source:'tencent',winRate:.55,pickRate:.12,games:null,date:'2026-12-01'}};
const list={meta:config,data:[cn,{...cn,id:158,stats:{...cn.stats,region:'WORLD'}}]};
const previous={config:null,catalog:null};
const ok=o=>new Response(JSON.stringify(o));

test('Public config alone never becomes a CN hero sample; target and publication time are separate',async t=>{
  let calls=0;
  t.mock.method(globalThis,'fetch',async(u,opts)=>{
    calls++;assert.ok(u.endsWith('config.json'));assert.equal(opts.headers.Authorization,undefined);return ok(config);
  });
  const value=await fetchAramgg(previous);
  assert.equal(calls,1);assert.equal(value.status,'needs-key');assert.equal(value.catalog,null);assert.equal(value.config.patch,'16.24');
});
test('Only CN Tencent rows from a matching envelope enter the ranking; failed releases retain the previous catalog',async t=>{
  let mode='ok',hits=0;
  const next={...config,apiRelease:2,dataVersion:'16.24.2'};
  t.mock.method(globalThis,'fetch',async(u,opts)=>{
    if(u.endsWith('config.json'))return ok(mode==='ok'?config:next);
    hits++;assert.equal(opts.headers.Authorization,'Bearer fixture');
    if(mode==='quota')return new Response('',{status:429});
    return ok(list);
  });
  const v=await fetchAramgg(previous,'fixture');
  assert.equal(v.catalog.heroes.length,1);assert.equal(v.catalog.heroes[0].winRate,55);
  assert.equal(v.catalog.heroes[0].games,null);assert.equal(v.catalog.date,'2026-12-01');
  await fetchAramgg(v,'fixture');assert.equal(hits,1);
  mode='mismatch';
  let fail=await fetchAramgg(v,'fixture');assert.equal(fail.status,'unavailable');assert.equal(fail.catalog.version,'16.24.1');
  mode='quota';fail=await fetchAramgg(v,'fixture');assert.equal(fail.status,'quota');assert.deepEqual(fail.catalog,v.catalog);
});
test('Trio counts keep row-level region and patch; no inferred wins, missing counts or cutoffs',async t=>{
  const version={config:{patch:'16.24',version:'16.24.1'},status:'ready'};
  const grouped=(ids,games,region,patch)=>({augmentIds:ids,
    stats:{source:'aramgg-client-upload',wins:80,winRate:.7,games,region,gamePatch:patch,date:'2026-12-01'}});
  const payload={meta:config,data:{champion:cn,augments:[{id:1,name:'甲'},{id:2,name:'乙'},{id:3,name:'丙'}],augmentTrios:[
    grouped([1,2,3],170,'CN','16.24'),grouped([1,2,4],190,'WORLD','16.23'),grouped([1,2,5],180,null,null),
    grouped([2,1,3],170,'CN','16.24'),grouped([2,3,4],null,'CN','16.24')]}};
  let hits=0;t.mock.method(globalThis,'fetch',async()=>{hits++;return ok(payload);});
  const env={ARAMGG_API_KEY:'fixture'};
  assert.equal((await getTrios(version,{},'157')).status,'needs-key');assert.equal(hits,0);
  const [a,b]=await Promise.all([getTrios(version,env,'157'),getTrios(version,env,'157')]);
  assert.deepEqual(a,b);assert.equal(hits,1);assert.equal(a.rows.length,3);assert.equal(a.unverified,1);
  assert.deepEqual(a.rows.map(r=>[r.region,r.patch,r.games]),[['WORLD','16.23',190],[null,null,180],['CN','16.24',170]]);
  assert.deepEqual(a.rows[2].augmentIds,['1','2','3']);
  assert.deepEqual(a.rows[2].names,['甲','乙','丙']);assert.ok(!JSON.stringify(a).includes('winRate'));
  await getTrios(version,env,'157');assert.equal(hits,1);
});

test('unqueried trios keep the access reason and selected augments filter complete records',async()=>{
  const source=await readFile(new URL('../public/sources.js',import.meta.url),'utf8');
  let requests=0;
  const rows=[{augmentIds:['1','2','3'],games:161},{augmentIds:['1','2','4'],games:190},{augmentIds:['2','3','4'],games:170}];
  const api=runInNewContext(source+'\n({trioStatusText,matchingTrioRows,readTrioRecord})',{read:async()=>{requests++;return {status:'ready',version:'16.23.1',rows};}});
  assert.match(api.trioStatusText('16.23',null,null,'needs-key',0),/等待配置/);
  assert.match(api.trioStatusText('16.23',null,null,'quota',0),/额度/);
  assert.match(api.trioStatusText('16.23',null,{pending:true},'ready',0),/正在查询/);
  assert.match(api.trioStatusText('16.23',{status:'ready'},null,'ready',0),/已查询/);
  const pending=api.readTrioRecord('157','16.23.1');
  assert.equal(pending,api.readTrioRecord('157','16.23.1'));
  await pending.promise;
  assert.equal(pending,api.readTrioRecord('157','16.23.1'));
  assert.equal(requests,1);
  assert.deepEqual(api.matchingTrioRows(pending.value.rows,['2','1']),rows.slice(0,2));
  assert.deepEqual(api.matchingTrioRows(rows,['1','2','3']),[rows[0]]);
  assert.deepEqual(api.matchingTrioRows(rows,['5']),[]);
});
