import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import test from 'node:test';
import {fetchMayhemNotes,parseMayhemArticle} from '../src/mayhem-notes.mjs';
import {mergeBalanceNotices,validateBalanceNotices} from '../src/balance-notices.mjs';
import {fetchOfficial} from '../src/official.mjs';

const official={patch:'26.23',samplePatch:'16.23',url:'https://lol.qq.com/gicp/news/410/37102797.html',
  title:'26.23版本更新公告',publishedAt:'2026-11-18T18:51:48+08:00',hotfixes:[]};
const excerpt=(mode,champion,line)=>'<h3>'+mode+'</h3><h4>英雄</h4><p><strong>'+champion+'</strong></p><ul><li>'+line+'</li></ul>';
const modes=excerpt('极地大乱斗','卡莉丝塔','造成伤害：110% ⇒ 105%')+excerpt('海克斯大乱斗','亚索','总攻击速度提升：2.5% ⇒ 0%')+
  excerpt('斗魂竞技场','亚索','本句只属于竞技场')+excerpt('召唤师峡谷','卡莉丝塔','本句只属于峡谷');
const head='<h1>26.23版本更新公告</h1>';
const mayhem=parseMayhemArticle(official,head+modes);
const collect=(previous=null,notes=mayhem)=>mergeBalanceNotices(previous,{...official,mayhem:notes});

test('Tencent parent mode heading governs each hero change, excluding other modes and item sections',()=>{
  const {documents}=collect();
  assert.deepEqual(documents[0].entries.map(e=>[e.mode,e.name]),[['mayhem','亚索'],['aram','卡莉丝塔']]);
  assert.equal(documents[0].entries[0].details[0],'总攻击速度提升：2.5% ⇒ 0%');
  assert.equal(documents[0].url,official.url);
  const onlyItems=parseMayhemArticle(official,head+'<h3>海克斯大乱斗</h3><h4>装备</h4><p><strong>装备</strong></p><li>冷却时间：2 ⇒ 3</li>');
  assert.equal(onlyItems.balanceEntries.length,0);
});

test('a verified Tencent article with only classic ARAM evidence populates the correct mode',async()=>{
  const body=head+excerpt('极地大乱斗','卡莉丝塔','造成伤害：110% ⇒ 105%');
  const notes=await fetchMayhemNotes(official,async()=>new Response(body));
  assert.equal(notes.entries.length,0);
  assert.equal(notes.balanceEntries[0].mode,'aram');
  await assert.rejects(fetchMayhemNotes({...official,patch:'26.24'},async()=>new Response(body)),/版本不一致/);
});

test('date-only Tencent maintenance title requires the explicit deployment version',()=>{
  const title='6月25日凌晨1点停机版本更新公告';
  const source={...official,title,patch:'26.13',samplePatch:'16.13'};
  const dated='<h1>'+title+'</h1>';
  const release='<p>LOL将在6月25日凌晨1点开始全区停机维护(请注意：排位赛将关闭)发布26.13版本，预计停机时间为01:00-12:00。</p>';
  assert.equal(parseMayhemArticle(source,dated+release+modes).patch,'26.13');
  assert.throws(()=>parseMayhemArticle(source,dated+'<p>上次发布26.13版本</p>'+modes),/版本不一致/);
  assert.throws(()=>parseMayhemArticle(source,head+release+modes),/版本不一致/);
  assert.throws(()=>parseMayhemArticle({...source,title:'别的公告'},dated+release+modes),/版本不一致/);
});

test('newer mainland date-titled release from notice feed can lead the patch archive',async()=>{
  const title='6月25日凌晨1点停机版本更新公告';
  const url='https://lol.qq.com/gicp/news/410/37089201.html';
  const feed={data:{result:[{sAuthor:'英雄联盟官方',sTitle:title,sCreated:'2026-06-24 18:00:00',
    iDocID:'87654',sRedirectURL:url}]}};
  const archive='<li class="newsitem"><a href="/gicp/news/410/37088140.html">26.12版本公告</a>2026-06-10</li>';
  const read=article=>fetchOfficial(async address=>address.includes('zmMcnTargetContentList')?Response.json(feed):
    new Response(address.includes('/423/2/')?archive:article));
  const main='<h1>'+title+'</h1><p>LOL将在6月25日凌晨1点开始全区停机维护，发布26.13版本。</p>';
  const result=await read(main);
  assert.equal(result.patch,'26.13');
  assert.equal(result.url,url);
  await assert.rejects(read(main.replace('LOL将在','上次曾在')),/确认版本号/);
  await assert.rejects(read(main.replace(title,'6月11日凌晨1点停机版本更新公告')),/正文/);
});

test('late and corrected source documents merge idempotently; failures retain dated prior evidence',()=>{
  const initial=collect();
  assert.deepEqual(collect(initial),initial);
  const priorHotfix=structuredClone(initial.documents[0]);priorHotfix.hotfix=true;priorHotfix.url='https://lol.qq.com/news/detail.shtml?docid=1234';
  const previous={...initial,documents:[priorHotfix,...initial.documents]};
  assert.deepEqual(mergeBalanceNotices(previous,{...official,mayhem,notesPending:true}),previous);
  assert.deepEqual(mergeBalanceNotices(previous,{...official,mayhem:{...mayhem,publishedAt:'2026-11-01T00:00:00+08:00'}}),previous);
  const amended=collect(previous,{...mayhem,balanceEntries:[]});
  assert.deepEqual(amended.documents,[priorHotfix]);
  assert.deepEqual(mergeBalanceNotices(previous,{...official,hotfixes:[priorHotfix],
    mayhem:{...mayhem,balanceEntries:[],balanceHotfixes:[{...priorHotfix,entries:[]}]}}).documents,[]);
  const malformed=structuredClone(initial);
  malformed.documents[0].entries[0].mode='rift';
  assert.throws(()=>validateBalanceNotices(malformed));
  assert.throws(()=>validateBalanceNotices({...initial,documents:[{...initial.documents[0],samplePatch:'16.22'}]}));
  assert.throws(()=>validateBalanceNotices({...initial,documents:[{...initial.documents[0],url:'https://example.org/notes'}]}));
});

test('bundled history uses dated mainland official material and actual distinct current patch subjects',async()=>{
  const seed=validateBalanceNotices(JSON.parse(await readFile(new URL('../data/balance-notices.json',import.meta.url))));
  const docs=seed.documents.filter(d=>d.patch==='26.23' && !d.hotfix);
  assert.equal(docs.length,1);
  assert.ok(docs[0].entries.some(e=>e.mode==='aram' && e.name==='卡莉丝塔' && e.details.includes('承受伤害：90% ⇒ 100%')));
  assert.ok(docs[0].entries.some(e=>e.mode==='mayhem' && e.name==='亚索' && e.details.includes('总攻击速度提升：2.5% ⇒ 0%')));
  assert.ok(seed.documents.some(d=>d.patch==='26.20' && d.entries.some(e=>e.mode==='mayhem' && e.name==='盖伦' && e.details.some(s=>s.includes('W冷却时间')))));
});

test('classic-only hotfix enriches the dated archive without joining the Mayhem news list',async()=>{
  const hotfix={url:'https://lol.qq.com/gicp/news/410/123456.html',title:'11月20日热更新',publishedAt:'2026-11-20T00:00:00+08:00'};
  const o={...official,hotfixes:[hotfix]};
  const notes=await fetchMayhemNotes(o,async url=>new Response(url===hotfix.url?'<h1>'+hotfix.title+'</h1>'+
    excerpt('极地大乱斗','卡莉丝塔','造成伤害：105% ⇒ 100%'):head+modes));
  assert.equal(notes.hotfixDetails.length,0);
  const archived=mergeBalanceNotices(null,{...o,mayhem:notes});
  const doc=archived.documents[0];
  assert.equal(doc.url,hotfix.url);
  assert.deepEqual(doc.entries.map(e=>[e.mode,e.name]),[['aram','卡莉丝塔']]);
  assert.equal(doc.hotfix,true);
});
