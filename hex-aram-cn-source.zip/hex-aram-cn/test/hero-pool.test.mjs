import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {fetchHeroPool, validateHeroPool} from '../src/hero-pool.mjs';

// All hero and augment examples below are artificial adapter fixtures.
const source = {name: '测试发布者', url: 'https://example.org/pool/17.1'};
const row = (id, state) => ({augmentId: id, state, detail: '测试用供选规则', source});
const fixture = () => ({
  schema: 1, measure: 'hero-augment-offer-eligibility', patch: '17.1', region: 'CN', mode: 'normal',
  publishedAt: '2025-01-02T13:00:00+08:00', source,
  heroes: {'111': {complete: false, rows: [row('9001', 'allowed'), row('9002', 'blocked')]}}
});

test('bundled rules validate on their declared patch, and unreported heroes remain unknown', async () => {
  const seed = JSON.parse(await readFile(new URL('../data/hero-pool.json', import.meta.url), 'utf8'));
  assert.equal(validateHeroPool(seed, seed.patch).patch, seed.patch);
  const empty = {...fixture(), heroes: {}};
  assert.deepEqual(validateHeroPool(empty, '17.1').heroes, {});
});

test('future patch carries only explicit per-hero decisions with evidence', () => {
  const sample = fixture();
  assert.deepEqual(validateHeroPool(sample, '17.1'), sample);
  assert.deepEqual(Object.keys(validateHeroPool(sample, '17.1').heroes), ['111']);
  sample.heroes['111'].complete = true;
  assert.throws(() => validateHeroPool(sample, '17.1'));
  sample.heroes['111'].coverageSource = source;
  assert.deepEqual(validateHeroPool(sample, '17.1'), sample);
  sample.heroes['111'].rows = [row('9002', 'blocked')];
  assert.throws(() => validateHeroPool(sample, '17.1'));
});

test('different patch, geography, queue, holdings, IDs and missing row evidence fail closed', () => {
  const changes = [
    s => {s.patch = '17.2';}, s => {s.region = 'KR';}, s => {s.mode = 'special';},
    s => {s.measure = 'hero-augment-holdings';}, s => {s.heroes = [];},
    s => {s.heroes['111'].complete = 'true';}, s => {s.heroes['111'].rows[1].state = 'observed';},
    s => {s.heroes['111'].rows[1].augmentId = '9001';}, s => {s.heroes['111'].rows[1].augmentId = 9001;},
    s => {delete s.heroes['111'].rows[0].source;}, s => {delete s.heroes['111'].rows[0].detail;},
    s => {s.source = {...source, url: 'https://user@example.org/'};}, s => {s.publishedAt = '2025-02-30T00:00:00Z';},
    s => {s.publishedAt = '2025-02-01 12:17:00';}
  ];
  for (const change of changes) {
    const sample = fixture();
    change(sample);
    assert.throws(() => validateHeroPool(sample, '17.1'));
  }
});

test('anonymous configured fetch verifies payload and propagates source failure', async () => {
  const sample = fixture();
  assert.equal(await fetchHeroPool('', '17.1', () => assert.fail('unconfigured')), null);
  const result = await fetchHeroPool(source.url, '17.1', async (url, options) => {
    assert.equal(url, source.url);
    assert.equal(options.credentials, 'omit');
    assert.equal(options.redirect, 'error');
    return Response.json(sample);
  });
  assert.deepEqual(result, sample);
  await assert.rejects(fetchHeroPool(source.url, '17.2', async () => Response.json(sample)));
  await assert.rejects(fetchHeroPool('http://example.org', '17.1', () => assert.fail('invalid URL')));
  await assert.rejects(fetchHeroPool(source.url, '17.1', async () => new Response(null, {status: 503})), /503/);
});
