import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {runInNewContext} from 'node:vm';
const base=new URL('../',import.meta.url);
const read=path=>readFile(new URL(path,base),'utf8');
const code=await read('public/game-updates.js');
const official=JSON.parse(await read('data/official.json'));
official.mayhem=JSON.parse(await read('data/mayhem-notes.json'));
const stats=JSON.parse(await read('data/stats.json'));
function ui(o=official){
  return runInNewContext(code+'\n;({patchEntries,filterPatchEntries,patchSubjectBody,poolParams,restorePool,offerNoticeRows})',{
    URLSearchParams,document:{addEventListener(){}},stats,official:o,augmentBook:{},esc:String,date:String,external:(url,title)=>title+' '+url
  });
}
test('announcement search includes numeric descriptions and scopes kind with intersection',()=>{
  const {patchEntries,filterPatchEntries,patchSubjectBody}=ui();
  const rows=patchEntries(official);
  assert.equal(filterPatchEntries(rows,'nerf','亚索 2.5%').length,1);
  assert.equal(filterPatchEntries(rows,'buff','９０秒')[0].name,'拯救');
  assert.equal(filterPatchEntries(rows,'buff','亚索').length,0);
  assert.match(patchSubjectBody('强化符文','鼓声暴起 低音轰鸣'),/腾讯版本公告/);
  assert.match(patchSubjectBody('英雄','亚索'),/2.5%/);
  assert.equal(patchSubjectBody('英雄','亚'),'');
  assert.equal(patchSubjectBody('装备','鼓声暴起 低音轰鸣'),'');
});
test('revision and hotfix provenance stay with matching current announcement',()=>{
  const o=structuredClone(official);
  const doc={title:'热修',url:'https://lol.qq.com/news/detail.shtml?docid=3',publishedAt:o.publishedAt};
  o.hotfixes=[doc];o.mayhem.hotfixDetails=[{...doc,entries:[{category:'英雄',name:'亚索',kind:'adjust',details:['新的改动'],basis:'公告条目'}]}];
  const {filterPatchEntries,patchEntries,patchSubjectBody}=ui(o);
  assert.equal(filterPatchEntries(patchEntries(o),'all','热修 亚索').length,1);
  assert.match(patchSubjectBody('英雄','亚索'),/docid=3/);
  o.patch='26.24';assert.equal(patchEntries(o).length,0);
});
test('pool filter and pagination share URL round-trip, invalid options fall back',()=>{
  const {restorePool,poolParams}=ui();
  const p=new URLSearchParams({group:'held',tier:'gold',q:'鼓声',page:'2'});
  restorePool('157',p);
  const restored=poolParams('157');for(const [k,v] of p)assert.equal(restored.get(k),v);
  restorePool('157',new URLSearchParams('group=x&tier=x&page=-1'));
  assert.equal(poolParams('157').toString(),'hero=157&view=pool');
});

test('each historical offer statement is reachable from exactly one hero profile',async()=>{
  const history=JSON.parse(await read('data/patch-history.json'));
  const {offerNoticeRows}=ui({...official,history});
  const actual=stats.heroes.flatMap(hero=>offerNoticeRows(hero));
  const expected=history.flatMap(doc=>doc.offerChanges || []);
  assert.ok(expected.length>0);assert.equal(actual.length,expected.length);
  for(const statement of expected){
    assert.ok(actual.some(r=>r.hero===statement.hero && r.augment===statement.augment && r.skill===statement.skill && r.state===statement.state));
  }
});
