import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {collectGame,validateGameFeed,readGameFeed,carryBalanceSkills} from '../src/game-feed.mjs';

const load=async file=>JSON.parse(await readFile(new URL('../data/'+file+'.json',import.meta.url)));
const official=await load('official');
official.mayhem=await load('mayhem-notes');
official.heroPool=await load('hero-pool');
const channel=o=>({schema:1,region:'CN',mode:'normal',official:o});
function source(patch,article){
  return async url=>{
    if(url.includes('/423/2/'))return new Response('<li class="newsitem"><a href="/gicp/news/410/37102797.html">'+patch+'版本更新公告</a>2026-11-21</li>');
    if(url.includes('apps.game.qq.com'))return Response.json({data:{result:[]}});
    return new Response(article);
  };
}
test('new announcement is visible independently of notes, last patch rules and samples',async()=>{
  const o=await collectGame(official,null,source('26.24','unrecognized'));
  assert.equal(o.samplePatch,'16.24');
  assert.equal(o.notesPending,true);
  assert.equal(o.mayhem,null);
  assert.equal(o.heroPool,null);
});
test('temporary failure retains only same-version details and refuses regression',async()=>{
  const kept=await collectGame(official,undefined,source('26.23','unrecognized'));
  assert.equal(kept.mayhem.entries.length,official.mayhem.entries.length);
  assert.equal(kept.heroPool.patch,official.samplePatch);
  assert.equal(kept.notesPending,true);
  await assert.rejects(()=>collectGame(official,null,source('26.22','unrecognized')));
});
test('reject mismatched notes, pool and unauthorized hero snapshot payloads',()=>{
  assert.ok(validateGameFeed(channel(structuredClone(official))));
  assert.throws(()=>validateGameFeed(channel({...official,mayhem:{...official.mayhem,patch:'26.22'}})));
  assert.throws(()=>validateGameFeed(channel({...official,heroPool:{...official.heroPool,region:'WORLD'}})));
  assert.throws(()=>validateGameFeed({...channel(official),aramgg:{status:'ready',heroes:[]}}));
});


test('reject mismatched official-to-client versions and mismatched mode balance snapshots',async()=>{
  const championBalance=await load('champion-balance'),balanceNotices=await load('balance-notices');
  assert.ok(validateGameFeed(channel({...official,championBalance,balanceNotices})));
  assert.throws(()=>validateGameFeed(channel({...official,samplePatch:'16.22',mayhem:null,heroPool:null})));
  assert.throws(()=>validateGameFeed(channel({...official,championBalance:{...championBalance,patch:'16.22'}})));
  assert.throws(()=>validateGameFeed(channel({...official,balanceNotices:{...balanceNotices,region:'WORLD'}})));
});

test('manual checks resolve mirror lag independently for the announcement and authorized hero catalog',async()=>{
  const record=v=>({status:'ready',config:{version:'16.23.'+v,patch:'16.23',release:v},
    catalog:{version:'16.23.'+v,patch:'16.23',heroes:[{id:'157',name:'亚索',winRate:50}]}});
  const later={...official,checkedAt:new Date(Date.parse(official.checkedAt)+60000).toISOString()};
  let reads=0;
  const fetcher=async url=>{
    reads++;return Response.json(url.includes('api.github.com')?{...channel(later),aramgg:record(1)}:{...channel(official),aramgg:record(2)});
  };
  const [a,b]=await Promise.all([readGameFeed(true,fetcher),readGameFeed(true,fetcher)]);
  assert.equal(reads,2);assert.equal(a.official.checkedAt,later.checkedAt);assert.equal(b.aramgg.catalog.version,'16.23.2');
  const partial=await readGameFeed(true,async url=>url.includes('api.github.com')?Response.json(channel(official)):new Response('offline',{status:503}));
  assert.equal(partial.official.patch,official.patch);
  await assert.rejects(readGameFeed(true,async()=>Response.json({})));
});

test('older-format caches can recover skill rows only from an identical patch and source revision',()=>{
  const mode={source:{url:'https://wiki.leagueoflegends.com/en-us/Special:PermanentLink/1'},byHero:{}};
  const incoming={patch:'16.23',modes:{aram:mode,mayhem:mode}};
  const skill={slot:'E',name:'',details:[{lang:'zh-CN',text:'护盾提高'}]};
  const previous={...incoming,modes:{...incoming.modes,mayhem:{...mode,skillsByHero:{106:[skill]}}}};
  assert.deepEqual(carryBalanceSkills(incoming,previous).modes.mayhem.skillsByHero[106],[skill]);
  assert.equal(carryBalanceSkills(incoming,{...previous,patch:'16.22'}),incoming);
  assert.equal(carryBalanceSkills({...incoming,modes:{...incoming.modes,mayhem:{...mode,source:{url:'new'}}}},previous).modes.mayhem.skillsByHero,undefined);
  assert.deepEqual(carryBalanceSkills({...incoming,modes:{...incoming.modes,mayhem:{...mode,skillsByHero:{}}}},previous).modes.mayhem.skillsByHero,{});
});
