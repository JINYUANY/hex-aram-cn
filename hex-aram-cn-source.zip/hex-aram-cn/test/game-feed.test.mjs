import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {collectGame,validateGameFeed} from '../src/game-feed.mjs';

const load=async file=>JSON.parse(await readFile(new URL('../data/'+file+'.json',import.meta.url)));
const official=await load('official');
official.mayhem=await load('mayhem-notes');
official.heroPool=await load('hero-pool');
const channel=o=>({schema:1,region:'CN',mode:'normal',official:o});
function source(patch,article){
  return async url=>{
    if(url.includes('/423/2/'))return new Response('<li class="newsitem"><a href="/gicp/news/410/37102797.html">'+patch+'版本更新公告</a>2026-11-21</li>');
    if(url.includes('apps.game.qq.com'))return Response.json({data:{result:[]}});
    return new Response(article);
  };
}
test('new announcement is visible independently of notes, last patch rules and samples',async()=>{
  const o=await collectGame(official,null,source('26.24','unrecognized'));
  assert.equal(o.samplePatch,'16.24');
  assert.equal(o.notesPending,true);
  assert.equal(o.mayhem,null);
  assert.equal(o.heroPool,null);
});
test('temporary failure retains only same-version details and refuses regression',async()=>{
  const kept=await collectGame(official,undefined,source('26.23','unrecognized'));
  assert.equal(kept.mayhem.entries.length,official.mayhem.entries.length);
  assert.equal(kept.heroPool.patch,official.samplePatch);
  assert.equal(kept.notesPending,true);
  await assert.rejects(()=>collectGame(official,null,source('26.22','unrecognized')));
});
test('reject mismatched notes, pool and unauthorized hero snapshot payloads',()=>{
  assert.ok(validateGameFeed(channel(structuredClone(official))));
  assert.throws(()=>validateGameFeed(channel({...official,mayhem:{...official.mayhem,patch:'26.22'}})));
  assert.throws(()=>validateGameFeed(channel({...official,heroPool:{...official.heroPool,region:'WORLD'}})));
  assert.throws(()=>validateGameFeed({...channel(official),aramgg:{status:'ready',heroes:[]}}));
});

