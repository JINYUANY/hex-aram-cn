import assert from 'node:assert/strict';
import {test} from 'node:test';
import {readFile} from 'node:fs/promises';
import {runInNewContext} from 'node:vm';
import {prepareHoldingBaseline,previousNormalRelease} from '../src/stats.mjs';

const release={patch:'16.22',mode:'normal',matches:2,path:'patches/16.22/normal',snapshot_at:'2026-11-17T18:00:00+08:00'};
const meta={...release,matches:{valid:2},augment_exposure:'final-held',excluded_augments:{exclude:true}};
const current={patch:'16.23',window:{start:'2026-11-19T08:00:00+08:00'},augment_exposure:'final-held'};
test('history compares canonical normal releases with compatible non-overlapping exposure windows',()=>{
  const index={datasets:[{...release,patch:'16.24'}, {...release,path:'patches/16.22-pbe/normal'},release,{...release,snapshot_at:'2026-11-21T00:00:00+08:00'}]};
  assert.equal(previousNormalRelease(index,current),release);
  const heroes={a:{games:12},b:{games:8}};
  const counts={a:{x:{games:3,wins:2},exclude:{games:5}},b:{x:{games:2},y:{games:1}}};
  const baseline=prepareHoldingBaseline(release,meta,heroes,counts,current);
  assert.deepEqual(baseline.totals,{x:5,y:1});assert.equal(baseline.players,20);
  assert.deepEqual(baseline.byHero.a,{games:12,held:{x:3}});
  assert.throws(()=>prepareHoldingBaseline(release,meta,heroes,counts,{...current,augment_exposure:'at-offer'}));
  assert.throws(()=>prepareHoldingBaseline(release,meta,heroes,{a:{x:{games:15}}},current));
});
test('scope, comparison group, tiers and historical baselines retain independent denominators',async()=>{
  const source=await readFile(new URL('../public/augment-ranks.js',import.meta.url),'utf8');
  const hero={id:'1',games:20,augmentCounts:{x:5,y:4}},other={id:'2',games:80,augmentCounts:{x:3,z:4}};
  const stats={heroParticipations:100,heroes:[hero,other],holdingBaseline:{byHero:{'1':{games:10,held:{x:2}}},totals:{x:3},players:50}};
  const augmentMap=new Map([['x',{games:8}],['y',{games:4}],['z',{games:4}]]);
  const rows=[{id:'x',games:5,holdRate:25,rarity:'gold'},{id:'y',games:4,holdRate:20,rarity:'gold'},{id:'z',games:null,referenceOnly:true}];
  const result=runInNewContext(source+'\nobservedHeroCounts=indexAugmentCoverage(stats.heroes);augmentRankRows(rows,hero);',{rows,stats,hero,augmentMap});
  assert.equal(result[0].coverage,2);assert.equal(result[0].tierShare,500/9);assert.equal(result[0].otherRate,3.75);assert.equal(result[0].gap,21.25);
  assert.equal(result[0].trend,5);assert.equal(result[1].trend,null);assert.equal(result[2].holdRate,undefined);
});
