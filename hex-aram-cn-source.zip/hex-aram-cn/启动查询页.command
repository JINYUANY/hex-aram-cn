#!/bin/zsh
cd -- "${0:A:h}" || exit 1
if ! command -v node >/dev/null; then
  echo "直接使用请解压免安装包并双击图鉴 HTML。运行此可选服务需要 Node.js 22 或更高版本。"
  read -k 1
  exit 1
fi
(sleep 1; open http://127.0.0.1:4187) &
exec node server.mjs
