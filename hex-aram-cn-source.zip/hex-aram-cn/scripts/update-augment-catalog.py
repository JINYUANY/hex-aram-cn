"""Build version-matched Mayhem reference assets before publishing the static site.

Install Pillow and xxhash, then run: python3 scripts/update-augment-catalog.py
Use --stats PATH for a freshly synchronized AramHex stats snapshot. Images and
versioned source documents are cached locally. Use --refresh for patch hotfixes.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
import html
from io import BytesIO
import json
import math
from pathlib import Path
import re
import subprocess
import tempfile

from PIL import Image
from xxhash import xxh3_64_intdigest


ROOT = Path(__file__).resolve().parents[1]
CDRAGON = "https://raw.communitydragon.org"
REGISTRY = "plugins/rcp-be-lol-game-data/global/zh_cn/v1/cherry-augments.json"
GAME_MODE = "game/maps/modespecificdata/kiwi.bin.json"
LOCALE = "game/zh_cn/data/menu/en_us/lol.stringtable.json"
RARITIES = {"kSilver": "silver", "kGold": "gold", "kPrismatic": "prismatic"}


def cached_file(url, target, refresh):
    if target.is_file() and not refresh:
        return target
    target.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=target.parent, delete=False) as temp:
        pending = Path(temp.name)
    try:
        subprocess.run(["curl", "--silent", "--show-error", "--fail", "--location",
                        "--retry", "2", "--connect-timeout", "10", "--max-time", "90",
                        "--output", str(pending), url], check=True)
        pending.replace(target)
    finally:
        pending.unlink(missing_ok=True)
    return target


def read_json(path):
    return json.loads(path.read_bytes())


def string_value(strings, key):
    # CommunityDragon resolves well-known RST keys to names. Other v5 keys
    # are the low 38 bits of XXH3, as used by Riot from game version 15.2.
    name = key.strip().lower()
    if name in strings:
        return strings[name]
    key_hash = xxh3_64_intdigest(name.encode()) & ((1 << 38) - 1)
    return strings.get(f"{{{key_hash:010x}}}")


def bin_key(name):
    # Spell calculations can similarly be exported under their BIN FNV1a key.
    value = 2166136261
    for char in name.lower().encode():
        value = ((value ^ char) * 16777619) & 0xffffffff
    return f"{{{value:08x}}}"


def archive_image(row, base, cache, refresh):
    prefix = "/lol-game-data/assets/"
    image_path = row["augmentSmallIconPath"]
    if not image_path.startswith(prefix):
        raise ValueError(f"Unknown asset path {image_path}")
    suffix = image_path[len(prefix):].lower()
    if not re.fullmatch(r"assets/[a-z0-9_./-]+\.png", suffix) or ".." in suffix:
        raise ValueError(f"Invalid asset path {suffix}")
    url = f"{base}/plugins/rcp-be-lol-game-data/global/default/{suffix}"
    token = sha256(url.encode()).hexdigest()
    filename = cached_file(url, cache / "icons" / (token + ".png"), refresh)
    with Image.open(filename) as image:
        if image.format != "PNG" or image.width < 16 or image.height < 16:
            raise ValueError(f"Invalid image at {url}")
        rgba = image.convert("RGBA")
        if not rgba.getbbox():
            raise ValueError(f"Empty image at {url}")
        return rgba.resize((64, 64), Image.Resampling.LANCZOS)


def load_sources(stats, refresh):
    patch = stats["patch"]
    if not re.fullmatch(r"\d+\.\d+", patch) or not isinstance(stats["seq"], int):
        raise ValueError("The sample must identify its patch and AramHex release")
    base = f"{CDRAGON}/{patch}"
    cache = ROOT / ".cache" / "augment-catalog" / patch
    sample = (f"https://raw.githubusercontent.com/czgreat/aramhex-data/data-v{stats['seq']}"
              f"/patches/{patch}/normal/meta.json")
    sources = {"kiwi": base + "/" + GAME_MODE, "strings": base + "/" + LOCALE,
               "registry": base + "/" + REGISTRY, "sample": sample}
    data = {}
    for name, url in sources.items():
        stem = f"sample-{stats['seq']}" if name == "sample" else name
        data[name] = read_json(cached_file(url, cache / (stem + ".json"), refresh))
    if data["sample"]["patch"] != patch or data["sample"]["mode"] != stats["mode"]:
        raise ValueError("The AramHex release does not match the sample")
    return base, cache, sources, data


def fmt(value):
    return f"{value:.5f}".rstrip("0").rstrip(".")


def scalar_part(part, values):
    kind = part.get("__type")
    if kind == "NumberCalculationPart":
        return part.get("mNumber", 0)
    if kind == "NamedDataValueCalculationPart":
        return values.get(part["mDataValue"].lower())
    return None


def scale_term(part, values, factor):
    const = scalar_part(part, values)
    if const is not None:
        return fmt(const * factor)
    kind = part.get("__type")
    if kind == "ByCharLevelInterpolationCalculationPart":
        return f"{fmt(part['mStartValue'] * factor)}～{fmt(part['mEndValue'] * factor)}（随等级成长）"
    if kind == "ByCharLevelBreakpointsCalculationPart":
        points = part.get("mBreakpoints", [])
        if len(points) == 1 and "mAdditionalBonusAtThisLevel" in points[0]:
            base = part["mLevel1Value"]
            end = base + points[0]["mAdditionalBonusAtThisLevel"]
            return f"{fmt(base * factor)}（{points[0]['mLevel']}级起为{fmt(end * factor)}）"
    if kind not in {"StatByNamedDataValueCalculationPart", "StatByCoefficientCalculationPart"}:
        return None
    stats = {0: "法术强度", 1: "护甲", 2: "攻击力", 6: "魔法抗性", 12: "生命值"}
    stat = stats.get(part.get("mStat", 0))
    if stat is None or part.get("mStatFormula", 0) not in (0, 2):
        return None
    if part.get("mStatFormula") == 2:
        stat = "额外" + stat
    elif part.get("mStat") == 12:
        stat = "最大生命值"
    coefficient = part.get("mCoefficient", values.get(part.get("mDataValue", "").lower()))
    if coefficient is None:
        return None
    return f"{fmt(coefficient * factor)}×{stat}"


def computed_value(calc, values, suffix_percent, factor):
    if not calc:
        return None
    parts = [scalar_part(part, values) for part in calc.get("mFormulaParts", [])]
    if not parts:
        return None
    multiplier = scalar_part(calc["mMultiplier"], values) if "mMultiplier" in calc else 1
    if multiplier is None:
        return None
    percent = calc.get("mDisplayAsPercent", False)
    if None in parts:
        if "mRangedMultiplier" in calc:
            return None
        scale = multiplier * factor * (100 if percent else 1)
        terms = [scale_term(part, values, scale) for part in calc["mFormulaParts"]]
        if None in terms:
            return None
        result = terms[0] if len(terms) == 1 else "（" + "＋".join(terms) + "）"
        return result + ("%" if percent and not suffix_percent else "")
    number = sum(parts) * multiplier * factor
    if percent:
        number *= 100
    suffix = "%" if percent and not suffix_percent else ""
    if "mRangedMultiplier" in calc:
        ranged = scalar_part(calc["mRangedMultiplier"], values)
        if ranged is None:
            return None
        # The source occasionally stores 2/3 as .667, displayed as integer
        # distances, or integer percentage points, by the client.
        precision = calc.get("mPrecision", 0)
        first = fmt(round(number, precision))
        second = fmt(round(number * ranged, precision))
        unit = "%" if percent else ""
        return f"（近战{first}{unit}、远程{second}{unit}）"
    return fmt(number) + suffix


def description_for(augment, objects, strings):
    template = string_value(strings, augment["DescriptionTra"])
    if not template:
        raise ValueError(f"Missing description for {augment['AugmentPlatformId']}")

    slot = re.fullmatch(r"GoH_PentakillAug_([QWER])", augment["AugmentNameId"])
    skill = slot.group(1) + "技能" if slot else "所选技能"

    def macro(match):
        name = match.group(1).strip()
        if name.lower() == "spellname":
            return skill
        value = string_value(strings, name)
        if value is None:
            raise ValueError(f"Unknown translation reference {name}")
        return value

    for _ in range(4):
        if "{{" not in template:
            break
        template = re.sub(r"\{\{(.*?)\}\}", macro, template)
    template = html.unescape(template)
    template = re.sub(r"<br\s*/?>|<li>", "\n", template, flags=re.I)
    template = re.sub(r"<[^>]+>|%i:[^%]+%", "", template, flags=re.I)
    template = template.replace("【" + skill + "】技能", skill).replace("【" + skill + "】", skill)
    template = template.replace("强化版技能获得" + skill, "强化后的" + skill + "获得")
    template = template.replace(skill + "技能", skill)
    spell = objects.get(augment.get("RootSpell"), {}).get("mSpell", {})
    values = {}
    for row in spell.get("DataValues", []):
        levels = row.get("values", [])
        if levels and len(set(levels)) == 1:
            values[row["name"].lower()] = levels[0]
    calcs = {k.lower(): v for k, v in spell.get("mSpellCalculations", {}).items()}
    quest = objects.get(augment.get("QuestData", {}).get("Quest"), {})
    dynamic = []

    def numeric(match):
        name, multiplier, unit = match.groups()
        lookup = name.lower()
        factor = float(multiplier or 1)
        if lookup in values:
            return fmt(values[lookup] * factor) + unit
        calc = calcs.get(lookup) or calcs.get(bin_key(lookup))
        result = computed_value(calc, values, bool(unit), factor)
        if result is not None:
            if result.startswith("（近战") and result.endswith("）"):
                return result
            return result + unit
        if lookup == "questrequirement":
            milestones = [m.get("{7fec0982}") for m in quest.get("Milestones", [])]
            if milestones and all(isinstance(v, int) for v in milestones):
                return "/".join(map(str, milestones)) + unit
        dynamic.append(name)
        return "〔" + name + "〕"

    text = re.sub(r"@([\w]+)(?:\*(-?[\d.]+))?@(%?)", numeric, template)
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\s*\n+\s*", "\n", text).strip()
    # A few in-game calculations require live player state or an undocumented
    # operator. Keep their published mechanics without inventing a number.
    text = re.sub(r"1\+〔\w+〕个飞弹", "飞弹", text)
    text = re.sub(r"〔\w+〕", "", text)
    text = re.sub(r"(\d+(?:\.\d+)?～\d+(?:\.\d+)?)（随等级成长）%", r"\1%（随等级成长）", text)
    return text, dynamic


def build_catalog(stats, refresh):
    base, cache, sources, data = load_sources(stats, refresh)
    game = data["kiwi"]
    strings = data["strings"]["entries"]
    samples = {str(row["id"]): row for row in stats["augments"]}
    registry = {str(row["id"]): row for row in data["registry"]}
    exclusions = data["sample"].get("excluded_augments", {})
    definitions = sorted((v for v in game.values()
                          if isinstance(v, dict) and v.get("__type") == "AugmentData"),
                         key=lambda v: v["AugmentPlatformId"])
    by_id, icon_sources, icon_indexes, internal = {}, {}, {}, []
    for augment in definitions:
        aid = str(augment["AugmentPlatformId"])
        entry = registry[aid]
        name = (string_value(strings, augment["NameTra"]) or "").strip()
        if not name and not entry["nameTRA"].strip() and aid not in samples:
            internal.append(aid)
            continue
        rarity = RARITIES[entry["rarity"]]
        if (entry["augmentNameId"] != augment["AugmentNameId"] or name != entry["nameTRA"] or
                (aid in samples and (name != samples[aid]["name"] or rarity != samples[aid]["rarity"]))):
            raise ValueError(f"Data sources disagree on augment {aid}")
        text, dynamic = description_for(augment, game, strings)
        if not text or re.search(r"@|\{\{|%i:|〔|<[^>]+>", text):
            raise ValueError(f"Description has unresolved content: {aid}")
        if aid in by_id:
            raise ValueError(f"Duplicate mode definition for {aid}")
        path = entry["augmentSmallIconPath"].lower()
        if path not in icon_indexes:
            icon_indexes[path] = len(icon_indexes)
            icon_sources[path] = entry
        by_id[aid] = {"name": name, "rarity": rarity, "description": text,
                      "iconIndex": icon_indexes[path], "referenceOnly": aid not in samples}
        if augment.get("Enabled") is False:
            by_id[aid]["modeDisabled"] = True
        if augment.get("IsAbilityAugment") is True:
            by_id[aid]["abilityAugment"] = True
            fixed = re.fullmatch(r"GoH_PentakillAug_([QWER])", augment["AugmentNameId"])
            if fixed and augment.get("DescriptionTra") == "Kiwi_GoH_PentakillAug_Generic_Description":
                by_id[aid]["fixedSlot"] = fixed.group(1)
        if aid in exclusions:
            by_id[aid]["sampleNote"] = exclusions[aid]
        if dynamic:
            by_id[aid]["descriptionNote"] = "部分数值随对局状态变化。"
    if not by_id or samples.keys() - by_id.keys():
        raise ValueError(f"Missing sampled IDs: {samples.keys() - by_id.keys()}")
    columns, tile = 16, 64
    rows = math.ceil(len(icon_sources) / columns)
    atlas = Image.new("RGBA", (columns * tile, rows * tile))
    with ThreadPoolExecutor(max_workers=6) as pool:
        pictures = pool.map(lambda row: archive_image(row, base, cache, refresh), icon_sources.values())
        for index, picture in enumerate(pictures):
            atlas.paste(picture, (index % columns * tile, index // columns * tile))
    image_bytes = BytesIO()
    atlas.save(image_bytes, format="WEBP", lossless=True, method=6)
    bitmap = image_bytes.getvalue()
    catalog = {
        "modeRulesVersion": 1, "patch": stats["patch"], "sampleSeq": stats["seq"], "locale": "zh_CN",
        "attribution": "游戏图标与简体中文文本 © Riot Games，由 CommunityDragon 按版本归档。国服样本来自 AramHex，依 CC BY-NC 4.0 提供。",
        "sources": {**sources, "assetsGuide": "https://communitydragon.org/docs/assets",
                    "riotPolicy": "https://www.riotgames.com/en/legal"},
        "atlas": {"path": "/augment-atlas.webp", "sha256": sha256(bitmap).hexdigest(),
                  "columns": columns, "rows": rows, "tile": tile},
        "coverage": {"sampled": len(samples), "referenceOnly": len(by_id) - len(samples),
                     "displayed": len(by_id), "distinctIcons": len(icon_sources),
                     "internalIdsOmitted": internal},
        "byId": by_id,
    }
    return bitmap, catalog


def replace_file(destination, data):
    with tempfile.NamedTemporaryFile(dir=destination.parent, delete=False) as tmp:
        pending = Path(tmp.name)
    try:
        pending.write_bytes(data)
        pending.chmod(0o644)
        pending.replace(destination)
    finally:
        pending.unlink(missing_ok=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stats", type=Path, default=ROOT / "data" / "stats.json")
    parser.add_argument("--refresh", action="store_true")
    args = parser.parse_args()
    bitmap, catalog = build_catalog(read_json(args.stats), args.refresh)
    payload = (json.dumps(catalog, ensure_ascii=False, indent=2) + "\n").encode()
    replace_file(ROOT / "public" / "augment-atlas.webp", bitmap)
    replace_file(ROOT / "data" / "augment-catalog.json", payload)
    print(catalog["patch"], catalog["coverage"])
