// Rebuild the offline archive for the requested season from Tencent's dated PC patch index.
import {readFile,writeFile} from 'node:fs/promises';
import {mergePatchHistory} from '../src/patch-history.mjs';
import {fetchOfficial} from '../src/official.mjs';
import {fetchMayhemNotes} from '../src/mayhem-notes.mjs';
const year=process.argv[2];
if(!/^20\d\d$/.test(year || ''))throw Error('请输入归档年份');
const records=new Map();
for(let page=1;page<=100;page++){
  const list='https://lol.qq.com/gicp/news/423/2/1334/'+page+'.html';
  const res=await fetch(list,{signal:AbortSignal.timeout(12000)});
  if(!res.ok)throw Error('腾讯目录 HTTP '+res.status);
  const html=new TextDecoder('gb18030').decode(await res.arrayBuffer());
  const rows=html.match(/<li\b[^>]*class="newsitem"[^>]*>[\s\S]*?<\/li>/gi);
  if(!rows?.length)throw Error('腾讯目录格式未识别');
  for(const row of rows){
    if(!row.includes('>'+year+'-'))continue;
    const href=row.match(/href="(\/gicp\/news\/410\/\d+\.html)"/)?.[1];
    if(!href)continue;
    const url=new URL(href,list).href;
    if(records.has(url))continue;
    const article=await fetch(url,{signal:AbortSignal.timeout(12000)});
    if(!article.ok)throw Error(url+' HTTP '+article.status);
    const bytes=await article.arrayBuffer();
    const local=async request=>{
      if(String(request)===url)return new Response(bytes);
      if(String(request).includes('/423/2/1334/'))return new Response(row);
      throw Error('仅使用当前归档目录行和对应腾讯正文');
    };
    const o=await fetchOfficial(local);
    let notes;
    try{notes=await fetchMayhemNotes(o,local);}catch{/* Keep the verified version, date and original article. */}
    records.set(url,{patch:o.patch,title:o.title,url,publishedAt:o.publishedAt,entries:notes?.entries ?? null,...(notes?.offerChanges?{offerChanges:notes.offerChanges}:{})});
  }
  if(rows.some(row=>(row.match(/class="item-time">(20\d\d)/)?.[1] || year)<year) || !html.includes('/'+(page+1)+'.html'))break;
}
if(!records.size)throw Error('没有匹配的版本公告');
const destination=new URL('../data/patch-history.json',import.meta.url);
const prior=await readFile(destination,'utf8').then(JSON.parse).catch(error=>{if(error.code==='ENOENT')return [];throw error;});
const history=mergePatchHistory({history:prior.filter(d=>d.publishedAt.startsWith(year+'-'))},{history:[...records.values()]});
await writeFile(destination,JSON.stringify(history)+'\n');
console.log(records.size+' 篇腾讯公告，'+[...records.values()].filter(d=>d.entries?.length).length+' 篇有海克斯改动');
