"""Build the item icons for a published AramHex batch from Riot's matching sprite sheets."""
import argparse
import hashlib
import io
import json
import math
from pathlib import Path
from urllib.request import urlopen

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
REPO = "https://raw.githubusercontent.com/czgreat/aramhex-data"
DRAGON = "https://ddragon.leagueoflegends.com/cdn"


def download(url):
    with urlopen(url, timeout=45) as response:
        return response.read()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("seq", type=int, help="AramHex data-v release number")
    args = parser.parse_args()
    release = f"{REPO}/data-v{args.seq}"
    manifest = json.loads(download(f"{release}/latest.json"))
    meta = download(f"{release}/{manifest['path']}/item_metadata.json")
    if hashlib.sha256(meta).hexdigest() != manifest["files"]["item_metadata.json"]["sha256"]:
        raise ValueError("Metadata does not match the release")
    version = manifest["patch"] + ".1"
    items = json.loads(download(f"{DRAGON}/{version}/data/zh_CN/item.json"))["data"]
    ids = sorted(set(json.loads(meta)) & items.keys(), key=int)
    cols, cell = 16, 48
    rows = math.ceil(len(ids) / cols)
    canvas = Image.new("RGBA", (cols * cell, rows * cell))
    sheets = {}
    for i, item_id in enumerate(ids):
        icon = items[item_id]["image"]
        name = icon["sprite"]
        if name not in sheets:
            sheets[name] = Image.open(io.BytesIO(download(f"{DRAGON}/{version}/img/sprite/{name}"))).convert("RGBA")
        x, y = icon["x"], icon["y"]
        tile = sheets[name].crop((x, y, x + icon["w"], y + icon["h"])).resize((cell, cell))
        canvas.paste(tile, (i % cols * cell, i // cols * cell))
    canvas.save(ROOT / "public" / "items-atlas.webp", quality=88, method=6)
    index = {"version": version, "cols": cols, "rows": rows, "byId": {key:i for i,key in enumerate(ids)}}
    (ROOT / "public" / "item-icons.json").write_text(json.dumps(index, separators=(",", ":")), encoding="utf-8")
    print(f"{len(ids)} item icons · Data Dragon {version}")


if __name__ == "__main__":
    main()
