"""Build patch-specific skill scopes for ARAM Mayhem from the mode and champion catalogs.

Run after scripts/update-augment-catalog.py. IsAbilityAugment and spell-name tokens
identify designated-spell cards. Hero bindings require separately attributed evidence.
"""
import json
import runpy
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
REVIEWED = "16.23"
GRANTED = {
    "1310": ("35", ["Q","P"], "强化授予欺诈魔术和背刺效果。"),
    "1386": ("166", ["E"], "强化把一个召唤师技能替换为骄行荡寇。"),
    "1420": ("37", ["W","E"], "强化交替自动施放娑娜的两支乐曲。"),
    "1421": ("497", ["R"], "宝冠落下后，强化赋予洛终极技能的魅惑效果。"),
    "2005": ("360", ["P","R"], "强化授予评分机制，达到 S 评价后自动施放炼狱扳机。"),
}
# These cards use a fixed slot even though some localizations substitute SpellName.
FIXED = {
    "1103": ("Q", "提升第一项基础技能的技能急速。"),
    "1150": ("W", "提升第二项基础技能的技能急速。"),
    "1151": ("E", "提升第三项基础技能的技能急速。"),
    "3170": ("Q", "五杀摇滚的 Q 键强化。"), "3171": ("W", "五杀摇滚的 W 键强化。"),
    "3172": ("E", "五杀摇滚的 E 键强化。"), "3173": ("R", "五杀摇滚的 R 键强化。"),
}
ULTIMATES = {
    "1004": "封锁终极技能", "1011": "施放大招时免疫伤害", "1088": "刷新大招",
    "1112": "施放大招时免疫控制", "1194": "大招伤害触发变形",
    "1211": "施放大招时标记敌人", "1344": "施放大招时获得增益",
    "1349": "大招触发基础技能刷新", "1413": "施放大招时嘲讽",
    "3055": "大招获得技能急速", "3118": "满足击杀条件后返还大招冷却",
}
# Conditions describe the effect spelled out on the card, not a per-champion whitelist.
CONDITIONS = {
    "2054": "额外瞄准目标的指定技能", "2055": "执行额外飞弹任务的指定技能",
    "2062": "由复制体再次施放的指定技能", "2064": "施放后触发冲刺的指定技能",
    "2065": "施放后触发恐惧的指定技能", "2072": "指定技能的飞弹",
    "2073": "能伤害敌方英雄的指定技能", "2076": "能伤害敌方英雄的指定技能",
    "2077": "能定身或缚地的指定技能", "2078": "能击退目标的指定技能",
    "2096": "有持续时间的指定技能", "2100": "完成急速任务的指定技能",
    "2109": "可再次施放的指定技能", "2111": "强化攻击或技能的指定技能",
    "2116": "完成增伤任务的指定技能", "2123": "由其他施法重置的指定技能",
    "2125": "提供持续增益的指定技能", "2126": "期间普攻可返还冷却的指定技能",
    "2129": "形成地形的指定技能", "2133": "可治疗友军或为其提供护盾的指定技能",
    "2135": "持续期间可普攻叠钉的指定技能", "2136": "能命中敌方英雄的指定技能",
    "2138": "能命中敌方英雄的指定技能", "2144": "能提供护盾的指定技能",
    "3053": "持续期间触发减速的指定技能", "3060": "获得技能急速转伤害的指定技能",
    "3075": "施放后产生反冲的指定技能", "3085": "施放后获得攻速的指定技能",
    "3088": "能伤害并标记敌人的指定技能", "3123": "获准暴击的指定技能",
    "3149": "可治疗友军或为其提供护盾的指定技能", "3159": "可击杀敌方英雄的指定技能",
    "1067": "施放后回复生命的指定技能",
}
TRIGGERS = {
    "1019": "冲刺、跳跃、闪烁或传送类技能", "1027": "冲刺、闪烁或传送类技能",
    "1063": "冲刺、闪烁或传送", "1073": "冲刺、闪烁、传送或离开潜行",
    "1113": "达到狙击条件的非终极技能", "1214": "游戏认定的旋转类技能",
    "1018": "定身或缚地敌方英雄", "1136": "定身或缚地敌人",
    "1323": "定身或缚地敌方英雄", "1375": "定身敌方英雄",
    "1315": "冲刺或闪烁", "1104": "英雄的召唤物", "1092": "装备效果与持续伤害",
    "2004": "向友军提供治疗或护盾", "3163": "向友方英雄提供治疗或护盾",
    "2087": "技能施放与随机技能冷却返还", "1129": "普通攻击及符合条件的强化攻击",
}
# (augment id, champion alias, slot(s), evidence, note, optional form-specific name)
CASES = [
    ("2062", "TwistedFate", "Q", "tfVideo", "实战录像中，崔斯特施放万能牌后，复制体会再扔出一组卡牌。录像记录过此键位，国服统计未逐局拆分键位。"),
    ("2062", "Hecarim", "Q", "hecVideo", "实战录像记录了复制体再次施放暴走。"),
    ("2062", "Zac", "W", "zacVideo", "实战录像记录了扎克 W 的回响效果。"),
    ("2062", "Blitzcrank", "R", "blitzVideo", "实战录像记录了布里茨 R 的回响效果。"),
    ("2062", "Amumu", "R", "amumuVideo", "实战录像记录了阿木木 R 的回响效果。"),
    ("2062", "Sett", "W", "settVideo", "玩家实战展示了 W 蓄意轰拳的回响，复制体也会打出一拳。"),
    ("2062", "Kennen", "R", "kennenVideo", "玩家实战记录了凯南 R 的回响效果。"),
    ("2062", "Shen", "E", "p20", "26.20 修复了慎使用闪现或预输入另一技能时，复制体无法完成 E 突进的问题。"),
    ("2062", "Volibear", "R", "p16", "26.16 记录了复制体施放 R 时的防御塔减益显示修复。"),
    ("2062", "Morgana", "R", "p15", "26.15 记录了莫甘娜 R 复制体朝向的修复。"),
    ("2072", "Nidalee", "Q", "p23", "仅指人类形态的标枪。26.23 修复了美洲狮形态也能投掷标枪的异常。", "标枪投掷（人类形态）"),
    ("2072", "Lucian", "W", "p20", "被强化的是 W 的弹体。E 是公告中导致旧异常的另一个动作。"),
    ("2072", "Ekko", "Q", "p15", "26.15 修复了 Q 飞弹到达末端时无法分裂的异常。"),
    ("2055", "Ezreal", "R", "p19", "26.19 调整了该大招对应的多重射击任务进度。"),
    ("2055", "Nami", "R", "p19", "26.19 调整了该大招对应的多重射击任务进度。"),
    ("2055", "Blitzcrank", "Q", "p12", "Riot 用布里茨 Q 举例说明完成额外飞弹任务后的效果。"),
    ("2055", "Lux", "Q", "dev", "Riot 的模式介绍演示了拉克丝 Q 多重发射的情形。"),
    ("2064", "Garen", "E", "p12", "Riot 用盖伦的 E 举例说明快步的冲刺效果。"),
    ("2064", "Kennen", "R", "p12", "Riot 用凯南的 R 举例说明快步的冲刺效果。"),
    ("2100", "Locke", "E", "p15", "26.15 修复了 E 的第二段突进无法推进此任务的异常。"),
    ("2116", "Locke", "E", "p15", "26.15 修复了 E 的第二段突进无法推进此任务的异常。"),
    ("1019", "MasterYi", "Q", "p15", "26.15 公告记录了 Q 与全凭身法的技能急速联动。"),
    ("1019", "Viego", "R", "p15", "26.15 公告记录了 R 与全凭身法的技能急速联动。"),
    ("1113", "Anivia", "Q", "p23", "26.23 修复了 Q 可以无冷却施放的异常，仍需满足狙击条件。"),
    ("1113", "Syndra", "E", "p23", "26.23 修复了弱者退散无法触发老练狙神的问题。"),
    ("1113", "Aurora", "Q", "p20", "26.20 修复了 Q 无法获得冷却返还的问题。"),
    ("1113", "Velkoz", "Q", "p15", "26.15 修复了 Q 首次命中时无法触发的问题。"),
    ("1113", "Velkoz", "W", "p19", "26.19 修复了 W 的冷却返还数值。"),
    ("1113", "Locke", "Q", "p15", "26.15 修复了 Q 弹药间隔上的异常冷却返还。"),
    ("2087", "Veigar", "W", "p16", "26.16 修复了维迦 W 无法触发冷却返还的问题。"),
    ("1129", "Blitzcrank", "E", "p16", "26.16 修复了该技能强化的普攻无法施加神射法师伤害的问题。"),
    ("1129", "Nasus", "Q", "p16", "26.16 修复了该技能强化的普攻无法施加神射法师伤害的问题。"),
    ("1129", "Trundle", "Q", "p16", "26.16 修复了该技能强化的普攻无法施加神射法师伤害的问题。"),
]
# A patch note removing an offer is negative evidence, never a confirmed target.
EXCLUDED = [
    ("2100","Yasuo","E","p14"), ("2123","Katarina","E","p15"), ("2123","Shaco","E","p15"),
    ("2100","Akshan","E","p15"), ("2116","Akshan","E","p15"), ("2116","Draven","Q","p15"),
    ("2116","Illaoi","E","p15"), ("2116","Malphite","W","p15"), ("2138","Akshan","E","p15"),
    ("2136","Akshan","E","p15")
]


def load(path):
    return json.loads(path.read_text())

def add_evidence(book, champions, supplement):
    targets, sources = book["byId"], book["sources"]
    if supplement.get("patch", REVIEWED) != book["patch"]:
        raise ValueError("Skill evidence patch mismatch")
    for key, source in supplement["sources"].items():
        if key in sources and sources[key]["url"] != source["url"]:
            raise ValueError(f"Conflicting evidence source: {key}")
        if not source["url"].startswith("https://"):
            raise ValueError(f"Missing evidence URL: {key}")
        sources[key] = {**sources.get(key, {}), **source}
    for field in ("examples", "exclusions", "notes"):
        for record in supplement.get(field, []):
            target = targets[str(record["augmentId"])]
            keys = record["sourceKeys"]
            if not keys or not all(key in sources for key in keys):
                raise ValueError(f"Missing source for {record}")
            if field == "notes":
                target.setdefault("historyNotes", []).append({"note":record["note"], "sourceKeys":keys})
                continue
            hero_id = str(record["heroId"])
            slots = {s["slot"]:s["name"] for s in champions["byId"][hero_id]["skills"]}
            slot = record["slot"]
            part = {"slot":slot, "name":record.get("name") or slots[slot], "note":record["note"], "sourceKeys":keys}
            if record.get("qualifier"):
                part["qualifier"] = record["qualifier"]
                if not record.get("name"):
                    part.pop("name")
            if slot not in slots:
                raise ValueError(f"Invalid evidence slot: {record}")
            group = "excludedByHero" if field == "exclusions" else "byHero"
            if field == "examples" and any(sources[key].get("kind")=="pbe" for key in keys):
                group = "historyByHero"
            bindings = target.setdefault(group, {}).setdefault(hero_id, [])
            if not any(p["slot"] == slot and p.get("sourceKeys") == keys and p.get("note") == part["note"] for p in bindings):
                bindings.append(part)


def pack_text_links(book, links):
    # Reuse each attributed hero/skill fact across the augments that use it.
    pool, indices = [], {}
    for aid, heroes in links.items():
        groups = {}
        for hid, parts in heroes.items():
            refs = []
            for part in parts:
                fact = {"heroId":hid, **part}
                key = json.dumps(fact, ensure_ascii=False, sort_keys=True)
                if key not in indices:
                    indices[key] = len(pool)
                    pool.append(fact)
                ref = indices[key]
                if ref not in refs:
                    refs.append(ref)
            groups[hid] = refs
        book["byId"][aid]["textByHero"] = groups
    book["conditionFacts"] = pool


def build():
    catalog=load(ROOT/"data/augment-catalog.json")
    patch=catalog["patch"]
    reviewed = patch == REVIEWED
    conditions=runpy.run_path(str(ROOT/"scripts/skill-condition-links.py"))
    mode=load(ROOT/f".cache/augment-catalog/{patch}/kiwi.json")
    champions=load(ROOT/"data/champion-catalog.json")
    stats=load(ROOT/"data/stats.json")
    assert champions["version"].startswith(patch+".") and stats["patch"]==patch
    sources={"mode":{"name":"本版游戏模式文件","url":catalog["sources"]["kiwi"]},
             "strings":{"name":"本版游戏技能强化文本","url":catalog["sources"]["strings"]},
             "champions":{"name":"本版英雄技能原文","url":champions["sourceUrl"]},
             "dev":{"name":"Riot 模式开发说明","kind":"official","url":"https://www.leagueoflegends.com/en-us/news/dev/dev-augmentmaxxing-aram-mayhem/"}}
    for n in (12,14,15,16,19,20,23):
        sources[f"p{n}"]={"name":"Riot 版本公告","kind":"official","patch":f"26.{n}","url":f"https://www.leagueoflegends.com/en-us/news/game-updates/league-of-legends-patch-26-{n}-notes/"}
    for key,title,video in [("tfVideo","崔斯特 Q 回响实战","Gki-Qdzg6rM"),("hecVideo","赫卡里姆 Q 回响实战","Wdx8gKHulh8"),
            ("zacVideo","扎克 W 回响实战","fZzZqyUaDBY"),("blitzVideo","布里茨 R 回响实战","uDmCrp_Dbs4"),
            ("amumuVideo","阿木木 R 回响实战","StPi4bRqWa0"),
            ("kennenVideo","凯南 R 回响实战","Nw1WYpMkBZs")]:
        sources[key]={"name":title,"kind":"gameplay","url":"https://www.youtube.com/watch?v="+video}
    sources["settVideo"]={"name":"瑟提 W 回响实战","kind":"gameplay","url":"https://www.bilibili.com/video/BV1VmKQ69Ete/"}
    by_id={}
    for data in mode.values():
        if not isinstance(data,dict) or data.get("__type")!="AugmentData":continue
        aid=str(data["AugmentPlatformId"])
        if aid not in catalog["byId"]:continue
        text=catalog["byId"][aid]["description"]
        item={"sourceKeys":["mode","strings"]}
        if not reviewed:
            if aid in TRIGGERS and conditions["skill_fingerprint"](catalog["byId"][aid]) == conditions["REVIEWED_AUGMENTS"].get(aid):
                by_id[aid]={**item,"kind":"conditional","label":TRIGGERS[aid],"description":text}
            elif data.get("IsAbilityAugment") or "所选技能" in text:
                by_id[aid]={**item,"kind":"champion","label":"技能强化 · 键位待核实",
                            "description":"本版技能资料已收录此项。具体关联键位待核实，请查看当局强化提示。"}
            continue
        if aid in GRANTED:
            hero_id, slots, note = GRANTED[aid]
            item.update(kind="external", label="强化授予的外来技能", description=note,
                        granted=[{"heroId":hero_id,"slot":slot} for slot in slots])
            item["sourceKeys"].append("champions")
        elif aid in FIXED:
            slot,note=FIXED[aid]
            assert data.get("IsAbilityAugment")
            if aid.startswith("317"):assert "强化"+slot+"技能" in text
            item.update(kind="fixed",label="固定 "+slot+" 技能",description=note,slots=[slot])
        elif data.get("IsAbilityAugment") or "所选技能" in text:
            item.update(kind="champion",label=CONDITIONS.get(aid,"本局指定的英雄技能"),
                        description="游戏在强化卡面标明本局指定的技能。已记录的实例按英雄和键位列出，完整可选键位以对局内说明为准。")
        elif aid in ULTIMATES:
            assert "终极技能" in text
            item.update(kind="fixed",label=ULTIMATES[aid],description=text,slots=["R"])
            if aid=="1349":
                item.update(affectedSlots=["Q","W","E"],affectedLabel="施放 R 后，刷新以下基础技能并为其提供技能急速")
        elif aid in ("1045","2099"):
            assert "基础技能" in text
            item.update(kind="fixed",label="影响基础技能冷却",description=text,slots=["Q","W","E"])
        elif aid in TRIGGERS:
            item.update(kind="conditional",label=TRIGGERS[aid],description=text)
        else:continue
        by_id[aid]=item
    heroes={h["key"]:h for h in champions["byId"].values()}
    for aid,alias,slot,source,note,*override in (CASES if reviewed else []):
        hero=heroes[alias]
        skills=champions["byId"][hero["id"]]["skills"]
        name=next(s["name"] for s in skills if s["slot"]==slot)
        if override:name=override[0]
        by_id[aid].setdefault("byHero",{}).setdefault(hero["id"],[]).append(
            {"slot":slot,"name":name,"note":note,"sourceKeys":[source]})
    for aid,alias,slot,source in (EXCLUDED if reviewed else []):
        hero=heroes[alias]
        by_id[aid].setdefault("excludedByHero",{}).setdefault(hero["id"],[]).append(
            {"slot":slot,"note":"该键位的错误供选已由 Riot 修复。","sourceKeys":[source]})
    result={"schema":2,"patch":patch,"sources":sources,"byId":dict(sorted(by_id.items(),key=lambda a:int(a[0])))}
    if reviewed:
        add_evidence(result, champions, load(ROOT/"scripts/skill-evidence.json"))
        assert result["byId"]["2062"]["byHero"]["4"][0]["name"]=="万能牌"
    pack_text_links(result, conditions["build_links"](champions,catalog,result))
    assert all(source in sources for v in by_id.values() for source in v["sourceKeys"])
    return result


if __name__=="__main__":
    result=build()
    destination=ROOT/"public/augment-skill-targets.json"
    with tempfile.NamedTemporaryFile(mode="w",encoding="utf-8",dir=destination.parent,delete=False) as tmp:
        json.dump(result,tmp,ensure_ascii=False,separators=(",",":"))
        tmp.write("\n")
    staged=Path(tmp.name)
    staged.chmod(0o644)
    staged.replace(destination)
    print(f'{len(result["byId"])} 条强化规则；{sum(len(x) for v in result["byId"].values() for x in v.get("byHero",{}).values())} 条逐英雄技能实例。')

