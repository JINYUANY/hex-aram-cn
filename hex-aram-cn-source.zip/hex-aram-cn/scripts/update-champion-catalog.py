#!/usr/bin/env python3
"""Build the zh_CN champion catalog and local ability atlas for a Data Dragon version.

Requires Python 3 and Pillow with WebP support. Run from any directory:
    python3 scripts/update-champion-catalog.py 16.23.1
    python3 scripts/update-champion-catalog.py 16.24.1 --portraits

Use --portraits to rebuild the separate champion portrait atlas and its index too.
Run the site's normal build after refreshing the files.
"""

import argparse
import html
import io
import json
import math
import re
import tempfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parents[1]
KEYWORDS_URL = "https://game.gtimg.cn/images/lol/act/img/js/heroList/hero_list.js"
ROLES = {
    "Assassin": "刺客", "Fighter": "战士", "Mage": "法师",
    "Marksman": "射手", "Support": "辅助", "Tank": "坦克",
}
CELL = 48
SLOTS = ("P", "Q", "W", "E", "R")


def download(url):
    with urlopen(url, timeout=40) as response:
        return response.read()


def description(value):
    # Preserve paragraph boundaries while removing Riot-specific formatting tags.
    value = re.sub(r"<(?:br|hr)\s*/?>", "\n", value, flags=re.I)
    value = html.unescape(re.sub(r"<[^>]+>", "", value))
    return "\n".join(line.strip() for line in value.splitlines() if line.strip())


def save_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, separators=(",", ":")) + "\n",
                    encoding="utf-8")


def add_keywords(catalog, directory):
    if directory.get("version") != catalog["version"].rsplit(".", 1)[0]:
        return
    for row in directory["hero"]:
        champion = catalog["byId"].get(str(row["heroId"]))
        if champion and champion["key"].lower() == row["alias"].lower():
            champion["keywords"] = list(dict.fromkeys(term.strip() for term in row["keywords"].split(",") if term.strip()))
    catalog["keywordsSource"] = KEYWORDS_URL


def image_source(name, cdn):
    from PIL import Image
    if not re.fullmatch(r"(champion|passive|spell)[0-9]+\.png", name):
        raise ValueError(f"Unexpected sprite name: {name}")
    with Image.open(io.BytesIO(download(f"{cdn}/img/sprite/{name}"))) as image:
        return name, image.convert("RGB")


def make_atlas(images, sources, columns, path):
    from PIL import Image
    rows = math.ceil(len(images) / columns)
    atlas = Image.new("RGB", (columns * CELL, rows * CELL))
    for index, ref in enumerate(images):
        source = sources[ref["sprite"]]
        x, y, w, h = (ref[field] for field in ("x", "y", "w", "h"))
        if min(x, y) < 0 or w != CELL or h != CELL or x + w > source.width or y + h > source.height:
            raise ValueError(f"Invalid icon rectangle for {ref['full']}")
        atlas.paste(source.crop((x, y, x + w, y + h)),
                    ((index % columns) * CELL, (index // columns) * CELL))
    atlas.save(path, "WEBP", quality=90, method=6)
    return {"image":path.name, "cols":columns, "rows":rows, "cell":CELL}


def build(version, portraits):
    if not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+", version):
        raise ValueError("Supply an explicit Data Dragon version, for example 16.23.1")
    cdn = f"https://ddragon.leagueoflegends.com/cdn/{version}"
    source_url = f"{cdn}/data/zh_CN/championFull.json"
    data = json.loads(download(source_url))
    if data["version"] != version or not data["data"]:
        raise ValueError("Data Dragon returned an empty collection or a different version")

    catalog = {}
    ability_icons, portrait_icons = [], []
    for champion in sorted(data["data"].values(), key=lambda c: int(c["key"])):
        game_id = champion["key"]
        if game_id in catalog or len(champion["spells"]) != 4:
            raise ValueError(f"Unexpected champion record for {game_id}")
        portrait_icons.append(champion["image"])
        skills = []
        for slot, skill in zip(SLOTS, [champion["passive"], *champion["spells"]]):
            details = description(skill["description"])
            if not details or not skill["name"]:
                raise ValueError(f"Missing skill text for {game_id} {slot}")
            skills.append({"slot":slot, "name":skill["name"], "description":details,
                           "icon":len(ability_icons)})
            ability_icons.append(skill["image"])
        catalog[game_id] = {
            "id":game_id, "key":champion["id"],
            # Data Dragon's zh_CN fields place the epithet first and the personal name second.
            "name":champion["title"], "title":champion["name"],
            "roles":[ROLES[tag] for tag in champion["tags"]],
            "resourceType":champion["partype"] or None,
            "stats":champion["stats"], "skills":skills,
        }

    images = ability_icons + (portrait_icons if portraits else [])
    names = sorted({ref["sprite"] for ref in images})
    with ThreadPoolExecutor(max_workers=4) as pool:
        sources = dict(pool.map(lambda name: image_source(name, cdn), names))
    # Stage all outputs before replacing the build inputs to keep download failures harmless.
    with tempfile.TemporaryDirectory(dir=ROOT) as directory:
        stage = Path(directory)
        skill_atlas = make_atlas(ability_icons, sources, 30, stage / "champion-skills.webp")
        book = {
            "version":version, "locale":"zh_CN", "sourceUrl":source_url,
            "sprite":skill_atlas, "byId":catalog,
        }
        try:
            add_keywords(book, json.loads(download(KEYWORDS_URL)))
        except (OSError, ValueError, KeyError) as error:
            print(f"Optional hero search aliases unavailable: {error}")
        save_json(stage / "champion-catalog.json", book)
        files = {"champion-skills.webp":"public", "champion-catalog.json":"data"}
        if portraits:
            portrait_atlas = make_atlas(portrait_icons, sources, 16, stage / "portraits.webp")
            save_json(stage / "portraits.json", {
                "version":version, **portrait_atlas, "byId":{k:i for i,k in enumerate(catalog)},
                "source":f"{cdn}/data/zh_CN/champion.json",
                "artSource":"https://ddragon.leagueoflegends.com/cdn/img/champion/splash/Ashe_0.jpg",
                "credit":"League of Legends artwork © Riot Games.",
            })
            files.update({"portraits.webp":"public", "portraits.json":"public"})
        for name, folder in files.items():
            (stage / name).replace(ROOT / folder / name)
    print(f"Data Dragon {version} · {len(catalog)} champions · {len(ability_icons)} abilities")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("version")
    parser.add_argument("--portraits", action="store_true")
    parser.add_argument("--keywords-only", type=Path, help="Merge a version-matched Tencent hero directory without rebuilding images")
    args = parser.parse_args()
    if args.keywords_only:
        path = ROOT / "data/champion-catalog.json"
        book = json.loads(path.read_text())
        directory = json.loads(args.keywords_only.read_text())
        if book["version"] != args.version or directory.get("version") != args.version.rsplit(".", 1)[0]:
            parser.error("The supplied directory and champion catalog must match the requested patch")
        add_keywords(book, directory)
        save_json(path, book)
    else:
        build(args.version, args.portraits)
