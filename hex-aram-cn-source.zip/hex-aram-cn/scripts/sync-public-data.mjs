import {readFile,writeFile,rename} from 'node:fs/promises';
import {collectGame,validateGameFeed} from '../src/game-feed.mjs';
import {fetchAramgg} from '../src/aramgg.mjs';

const target=process.argv[2];
if(!target)throw Error('需要公告同步文件路径');
const seed=async name=>JSON.parse(await readFile(new URL('../data/'+name+'.json',import.meta.url),'utf8'));
let prior;
try{prior=validateGameFeed(JSON.parse(await readFile(target,'utf8')));}
catch(error){if(error.code!=='ENOENT')throw error;}
let previous=prior?.official && {...prior.official};
if(!previous){previous=await seed('official');previous.mayhem=await seed('mayhem-notes');previous.heroPool=await seed('hero-pool');}
previous.balanceNotices ??= await seed('balance-notices');
const bundledBalance=await seed('champion-balance');
if(!previous.championBalance && bundledBalance.patch===previous.samplePatch)previous.championBalance=bundledBalance;
const roster=(await seed('stats')).heroes;
const next={schema:1,region:'CN',mode:'normal',official:previous,aramgg:prior?.aramgg ?? null};
let failed=false;
try{
  next.official=await collectGame(previous,process.env.HERO_POOL_URL,fetch,roster);
  if(next.official.notesPending || next.official.poolPending){
    console.warn('部分来源未更新，已保留可验证记录');failed=true;
  }
}catch{console.error('腾讯公告本次核对失败');failed=true;}
if(process.env.ARAMGG_API_KEY){
  try{
    const gg=await fetchAramgg(next.aramgg || await seed('aramgg'),process.env.ARAMGG_API_KEY);
    if(gg.status==='ready')next.aramgg=gg;
    else{console.warn('授权国服英雄榜 '+gg.status);failed=true;}
  }catch{console.warn('授权国服英雄榜暂不可用');failed=true;}
}
validateGameFeed(next);
// Publish changes immediately. Coalesce timestamp-only commits to one every four hours.
const withoutClock=feed=>JSON.stringify({...feed,official:{...feed.official,checkedAt:null}});
if(!prior || withoutClock(next)!==withoutClock(prior) || Date.parse(next.official.checkedAt)-Date.parse(prior.official.checkedAt)>=4*3600000){
  await writeFile(target+'.tmp',JSON.stringify(next)+'\n');
  await rename(target+'.tmp',target);
}
console.log('国服 '+next.official.patch+' · 公告条目 '+(next.official.mayhem?.entries.length ?? 0)+' · 最近成功采集 '+next.official.checkedAt);
if(failed)process.exitCode=1;
