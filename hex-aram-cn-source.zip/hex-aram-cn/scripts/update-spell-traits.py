"""Generate patch-matched root spell traits. Run with --offline to use the versioned cache."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tempfile


ROOT = Path(__file__).resolve().parents[1]
SLOTS = ("Q", "W", "E", "R")
# Some engine tags describe internal interactions whose gameplay semantics are
# ambiguous. Keep their names for provenance but display only translated traits.
LABELS = {
    "PositiveEffect_Boon": "增益效果",
    "PositiveEffect_EmpowerAttack": "强化普攻",
    "PositiveEffect_Teleport": "传送或闪烁",
    "Trait_ActiveHeal": "主动治疗",
    "Trait_Ammo": "充能",
    "Trait_AoE": "范围效果",
    "Trait_AttackBuff_Duration": "持续攻击增益",
    "Trait_AttackReset": "重置普攻",
    "Trait_CCImmune": "控制免疫",
    "Trait_Camouflage": "伪装",
    "Trait_ChannelSpell": "引导",
    "Trait_CreateClone": "生成分身",
    "Trait_CreateTerrain": "制造地形",
    "Trait_DamageAbility": "造成伤害",
    "Trait_DoT": "持续伤害",
    "Trait_ImmobilizingCCAbility": "含定身类控制",
    "Trait_ImmobilizingCCSpell": "含定身类控制",
    "Trait_Invisibility": "隐形",
    "Trait_KnockBack": "击退",
    "Trait_MultiTargetAttack": "多目标攻击",
    "Trait_NoCooldown": "无冷却标签",
    "Trait_NotBenefitFromHaste": "不受技能急速影响",
    "Trait_PassiveShield": "被动护盾",
    "Trait_PassiveSlot": "被动型技能栏",
    "Trait_Pet": "召唤物",
    "Trait_PlayerSelectedDashDirection": "可选方向的突进",
    "Trait_ProjectileDestruction": "清除弹体",
    "Trait_Ranged_Piercing": "远程贯穿",
    "Trait_Ranged_StopsFirstHit": "远程首个命中后停止",
    "Trait_Ranged_Zone": "远程区域效果",
    "Trait_RecastOrReplaceSpell": "再次施放或替换",
    "Trait_SelfHeal": "自我治疗",
    "Trait_Shield": "护盾",
    "Trait_SignatureSpell": "标志技能",
    "Trait_SwapsIntoImmobilizingCCAbility": "切换后可含定身控制",
    "Trait_Target_Area": "区域指向",
    "Trait_Target_Directional": "方向指向",
    "Trait_Toggle": "开关型技能",
    "Trait_Transformation": "形态转换",
    "Trait_Trap": "陷阱",
    "Trait_Ultimate": "终极技能",
    "Trait_Untargetable": "不可被选取",
    "Trait_Upgrade": "技能升级",
}
SCOPE = "标签取自英雄基础技能栏指向的根法术。子法术、重施段数及其他形态可能有不同属性。缺少标签表示此字段没有提供对应信息。"


def record_for(tree, alias):
    path = f"characters/{alias}/characterrecords/root"
    record = next((v for k, v in tree.items() if k.lower() == path), None)
    if not record or record.get("__type") != "CharacterRecord":
        raise ValueError(f"{alias}: missing base character record")
    if len(record.get("spells", [])) != len(SLOTS):
        raise ValueError(f"{alias}: unexpected number of basic spell slots")
    return record


def get_file(cache, alias, url, offline, refresh):
    dest = cache / (alias + ".json")
    if dest.is_file() and not refresh:
        return dest.read_bytes()
    if offline:
        raise ValueError(f"Missing cached patch file for {alias}")
    with tempfile.NamedTemporaryFile(dir=cache, delete=False) as temp:
        temp_path = Path(temp.name)
    try:
        subprocess.run(["curl", "--silent", "--show-error", "--fail", "--location",
                        "--retry", "2", "--connect-timeout", "10", "--max-time", "45",
                        "--output", str(temp_path), url], check=True)
        data = temp_path.read_bytes()
        record_for(json.loads(data), alias)
        temp_path.replace(dest)
        return data
    finally:
        temp_path.unlink(missing_ok=True)


def hero_traits(champion, tree, alias, url, digest):
    record = record_for(tree, alias)
    slot_names = {s["slot"]: s["name"] for s in champion["skills"]}
    slots, meta = {}, {}
    roots = [("P", record.get("mCharacterPassiveSpell")), *zip(SLOTS, record["spells"])]
    for slot, path in roots:
        if not slot_names.get(slot):
            raise ValueError(f"{alias}: missing localized slot {slot}")
        spell = tree.get(path, {})
        if (not isinstance(path, str) or
            not path.lower().startswith(f"characters/{alias}/spells/") or
            spell.get("__type") != "SpellObject"):
            slots[slot] = []
            meta[slot] = {"status": "unresolved"}
            continue
        data = spell.get("mSpell", {})
        tags = list(dict.fromkeys(t for t in data.get("mSpellTags", []) if t))
        if any(not isinstance(t, str) for t in tags):
            raise ValueError(f"{alias}: malformed tag list in {slot}")
        labels = list(dict.fromkeys(LABELS[t] for t in tags if t in LABELS))
        slots[slot] = labels
        meta[slot] = {"spell": path.rsplit("/", 1)[-1], "tags": tags,
                      "status": "tagged" if labels else "untranslated" if tags else "unlabelled"}
        missile = data.get("mMissileSpec", {})
        if isinstance(missile, dict) and missile.get("__type") == "MissileSpecification":
            meta[slot]["missileConfigured"] = True
    result = {"source": url, "sha256": digest, "slots": slots, "slotMeta": meta}
    # Alternate root abilities often lack a slot index. Do not infer one from
    # spelling or the order of mAbilities (Sona's order there is Q,W,E,P,R).
    assigned = {path for _, path in roots}
    alternates = []
    for key in record.get("mAbilities", []):
        ability = tree.get(key, {})
        alt = ability.get("mRootSpell")
        if ability.get("__type") == "AbilityObject" and isinstance(alt, str) and alt not in assigned:
            alternates.append(alt.rsplit("/", 1)[-1])
    if alternates:
        result["otherAbilityRoots"] = sorted(set(alternates))
    multiple = (alternates or any("/" in name or "／" in name for name in slot_names.values())
                or any("Trait_Transformation" in value.get("tags", []) for value in meta.values()))
    if multiple:
        result["note"] = "此处只列基础技能栏对应的法术标签，其他形态、武器或强化形态的效果需单独核对。"
    return result


def build(offline, refresh):
    book = json.loads((ROOT / "data/champion-catalog.json").read_bytes())
    if not re.fullmatch(r"\d+\.\d+\.\d+", book["version"]):
        raise ValueError("Unexpected champion catalog version")
    patch = book["version"].rsplit(".", 1)[0]
    cache = ROOT / ".cache/character-spells" / patch
    cache.mkdir(parents=True, exist_ok=True)

    def read_hero(item):
        hero_id, champion = item
        alias = champion["key"].lower()
        if not re.fullmatch(r"[a-z0-9]+", alias):
            raise ValueError("Invalid champion alias")
        url = f"https://raw.communitydragon.org/{patch}/game/data/characters/{alias}/{alias}.bin.json"
        raw = get_file(cache, alias, url, offline, refresh)
        return hero_id, hero_traits(champion, json.loads(raw), alias, url, hashlib.sha256(raw).hexdigest())

    with ThreadPoolExecutor(max_workers=8) as pool:
        heroes = dict(pool.map(read_hero, sorted(book["byId"].items(), key=lambda row: int(row[0]))))
    all_slots = [v for hero in heroes.values() for v in hero["slotMeta"].values()]
    coverage = {"heroes": len(heroes), "slots": len(all_slots),
                "resolved": sum(s["status"] != "unresolved" for s in all_slots),
                "tagged": sum(s["status"] == "tagged" for s in all_slots),
                "withMissileSpec": sum(bool(s.get("missileConfigured")) for s in all_slots),
                "unlabelled": sum(s["status"] == "unlabelled" for s in all_slots),
                "untranslated": sum(s["status"] == "untranslated" for s in all_slots)}
    return {"patch": patch, "version": book["version"], "scope": SCOPE,
            "coverage": coverage, "byHero": heroes}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--refresh", action="store_true", help="Re-download patch assets")
    mode.add_argument("--offline", action="store_true", help="Only read cached patch assets")
    args = parser.parse_args()
    document = build(args.offline, args.refresh)
    output = ROOT / "public/champion-spell-traits.json"
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=output.parent, delete=False) as f:
        json.dump(document, f, ensure_ascii=False, separators=(",", ":"))
        f.write("\n")
    staged = Path(f.name)
    staged.chmod(0o644)
    staged.replace(output)
    print(document["patch"], document["coverage"])
