from pathlib import Path
from shutil import copyfile
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parents[1]
target = root / "downloads" / "hex-aram-cn.zip"
target.parent.mkdir(exist_ok=True)
with ZipFile(target, "w", compression=ZIP_DEFLATED, compresslevel=9) as archive:
    archive.write(root / "dist/download/海克斯战局.html", "海克斯战局.html")
    archive.write(root / "使用说明.txt", "使用说明.txt")
print(target.name, target.stat().st_size)

publish = root / "dist" / "publish"
copyfile(target, publish / target.name)
for name in ("README.md", "MAINTENANCE.md", "CHANGELOG.md"):
    copyfile(root / name, publish / name)
for guide in sorted(root.glob("guide-*.webp")):
    copyfile(guide, publish / guide.name)
# Start a clean public archive. Only the named code folders and assets are part of the release.
files = [root / name for name in ("README.md", "MAINTENANCE.md", "CHANGELOG.md", "app-release.json", "package.json", "build.mjs", "server.mjs", "启动查询页.command", "使用说明.txt", ".gitignore")]
files.append(root / ".github/workflows/sync-data.yml")
files.extend(sorted(root.glob("guide-*.webp")))
for folder in ("data", "public", "scripts", "src", "test"):
    files.extend(p for p in sorted((root / folder).rglob("*")) if p.is_file() and not any(part.startswith(".") or part == "__pycache__" for part in p.relative_to(root).parts))
with ZipFile(publish / "hex-aram-cn-source.zip", "w", compression=ZIP_DEFLATED, compresslevel=9) as archive:
    for path in files:
        archive.write(path, "hex-aram-cn/" + path.relative_to(root).as_posix())
