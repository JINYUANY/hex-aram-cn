// Tencent's PC news list offers JSONP to browsers. Keep its script in an opaque frame.
function readTencentDirectory(){
  const frame=document.createElement('iframe');
  frame.hidden=true;
  frame.setAttribute('sandbox','allow-scripts');
  frame.referrerPolicy='no-referrer';
  const url=new URL('https://apps.game.qq.com/cmc/zmMcnTargetContentList');
  url.search=new URLSearchParams({r0:'jsonp',r1:'hexAtlasNews',page:'1',num:'30',target:'24',source:'web_pc',_t:String(Date.now())});
  return new Promise((resolve,reject)=>{
    const finish=(result,error)=>{
      clearTimeout(timer);
      window.removeEventListener('message',receive);
      frame.remove();
      if(error)reject(error);else resolve(result);
    };
    const receive=event=>{
      if(event.source!==frame.contentWindow || event.origin!=='null')return;
      if(event.data?.status===1 && Array.isArray(event.data.data?.result))finish(event.data);
      else finish(null,Error('腾讯公告目录暂不可读'));
    };
    const timer=setTimeout(()=>finish(null,Error('腾讯公告目录请求超时')),8000);
    window.addEventListener('message',receive);
    frame.srcdoc='<meta name="referrer" content="no-referrer"><meta http-equiv="Content-Security-Policy" content="default-src \'none\'; script-src \'unsafe-inline\' https://apps.game.qq.com/cmc/zmMcnTargetContentList"><script>function hexAtlasNews(data){parent.postMessage(data,"*");}</script><script src="'+url.href.replaceAll('&','&amp;')+'" onerror="parent.postMessage(null,\'*\')"></script>';
    document.body.append(frame);
  });
}
