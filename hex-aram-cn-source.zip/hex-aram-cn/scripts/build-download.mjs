import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {assets,browserService} from '../build.mjs';

const resources={};
const pictures={};
for(const [path,asset] of Object.entries(assets)){
  if(path.endsWith('.json'))resources[path]=asset;
  if(path.endsWith('.webp') && path!=='/hero.webp')pictures[path]=asset[1];
}
const stats=JSON.parse(await readFile('data/stats.json','utf8'));
const gg=JSON.parse(await readFile('data/aramgg.json','utf8'));
const official=JSON.parse(await readFile('data/official.json','utf8'));
const cacheId='hex-aram-cn-'+[stats.seq,official.patch,gg.config.version].join('-');
const runtime=await readFile('scripts/download-runtime.js','utf8');
const bridge=`
globalThis.offlineAtlas=(()=>{
  const assets=${JSON.stringify(resources)};
  const worker=(()=>{${browserService}})();
  ${runtime}
  const environment=openDownloadCache(${JSON.stringify(cacheId)}).then(db=>({BUCKET:downloadBucket(db)}));
  const images={};
  for(const [path,content] of Object.entries(${JSON.stringify(pictures)})){
    const bytes=Uint8Array.from(atob(content),c=>c.charCodeAt(0));
    images[path]=URL.createObjectURL(new Blob([bytes],{type:'image/webp'}));
  }
  return {images,async read(path){
    const response=await worker.fetch(new Request('https://atlas.invalid'+path),await environment);
    if(!response.ok)throw new Error('查询失败 '+response.status);
    return response.json();
  }};
})();`;
let html=assets['/index.html'][1];
const scripts=[...html.matchAll(/<script defer src="([^"]+)"><\/script>/g)].map(m=>assets[m[1]][1]);
const style=assets['/style.css'][1].replace('url(/hero.webp)',()=> 'url(data:image/webp;base64,'+assets['/hero.webp'][1]+')');
html=html.replace('<link rel="stylesheet" href="/style.css">',()=>'<style>'+style+'</style>')
  .replace(/<script defer src="[^"]+"><\/script>/g,'')
  .replace('查询英雄技能、海克斯效果、装备属性与国服样本排行。','免安装下载版 · 离线可查，联网时检查公开数据。')
  .replace('页面可见时每 5 分钟检查，返回页面时也会检查。','文件打开时每 5 分钟检查公开来源；离线或来源限制浏览器访问时，保留已取得的数据。')
  .replace(/<p>站点所有者可用 GitHub 登录[\s\S]*?<\/p>\s*<p>[\s\S]*?<\/p>/,'<p>下载版直接读取公开数据。受保护的统计可由站点运营者在自托管服务中接入。<a href="https://developer.riotgames.com/docs/lol#game-policy" target="_blank" rel="noopener noreferrer">Riot 游戏政策</a></p>');
const inline=text=>'<script>'+text.replace(/<\/script/gi,'<\\/script')+'<\/script>';
html=html.replace('</body>',()=>[bridge,...scripts].map(inline).join('\n')+'</body>');
const updater=await readFile('scripts/download-updates.js','utf8');
html=html.replace('<div class="sync-content">',()=>'<div class="sync-content"><p>程序版本 <code id="release-number"></code> · <span id="release-check-status" role="status">正在核对公开版…</span> · <button id="release-check" type="button">检查程序更新</button> · <a href="https://jinyuany.github.io/hex-aram-cn/">打开在线版</a></p>');
const build=createHash('sha256').update(html).update(updater).digest('hex');
const release={project:'hex-aram-cn',build,builtAt:Date.now()};
html=html.slice(0,html.lastIndexOf('</body>'))+inline(updater+'\nstartReleaseCheck('+JSON.stringify(release)+');')+'</body></html>\n';
await mkdir('dist/download',{recursive:true});
await mkdir('dist/publish',{recursive:true});
await writeFile('dist/download/海克斯战局.html',html);
await writeFile('dist/publish/index.html',html);
await writeFile('dist/publish/version.json',JSON.stringify(release)+'\n');
console.log('已生成免安装图鉴和在线发布页。');
