"""Join reviewed champion mechanics to compatible, non-designated augment descriptions.

Each fact names the acting champion, a skill and a condition. The two checksums in
this module's inputs pin both sides of the interpretation: changed skill prose
and changed augment rules do not inherit earlier claims. No match observations
or per-game spell assignments are inferred.
"""
import csv
import hashlib
from pathlib import Path


# An immobilize-only augment does not accept grounding alone. A dash-or-blink
# trigger is deliberately distinct from one that explicitly includes teleport.
AUGMENT_MECHANICS = {
    "1018": ("定身或缚地一个敌方英雄后", {"immobilize", "ground"}),
    "1136": ("定身或缚地一个敌人时", {"immobilize", "ground"}),
    "1323": ("定身或缚地一个英雄时", {"immobilize", "ground"}),
    "1375": ("定身一个敌方英雄时", {"immobilize"}),
    "2004": ("为友军提供治疗或护盾", {"ally_aid"}),
    "3163": ("为友方英雄提供治疗或护盾", {"ally_aid"}),
    "1019": ("冲刺、跳跃、闪烁或传送类技能", {"dash", "blink", "teleport", "leap"}),
    "1027": ("冲刺、闪烁或传送类技能", {"dash", "blink", "teleport"}),
    "1063": ("在使用一次冲刺、闪烁或传送之后", {"dash", "blink", "teleport"}),
    "1073": ("冲刺、闪烁或传送类技能或离开潜行状态之后", {"dash", "blink", "teleport", "leave_stealth"}),
    "1315": ("在冲刺或闪烁后", {"dash", "blink"}),
    "1104": ("你的召唤物", {"summon"}),
    "1092": ("你的装备效果和持续伤害效果可以暴击", {"dot"}),
    "1214": ("你的旋转类技能", {"spin"}),
    "1129": ("你的攻击造成", {"enhanced_attack"}),
}

REVIEWED_AUGMENTS = {
    "1018": "60a950d075579e1631e0", "1136": "74c613445354c45bae29",
    "1323": "8d6f5000bd6b5d5fd6e7", "1375": "76117969bf573ada6bba",
    "2004": "797b8e315e8750050bbd", "3163": "49c611f11d0a9b8e0ff5",
    "1019": "5c183061922c1779fc89", "1027": "332a2af229a102b7c7bf",
    "1063": "5e666391c919538b43d3", "1073": "ff92f49b62c4802ae2ee",
    "1315": "8cf8da44f939f550897d", "1104": "d740ce997ccf65ece60f",
    "1092": "734e0f4a26976628848d", "1214": "c82fec8eabf681e235ea",
    "1129": "38bb8cb6ddca9bfede56",
}

MECHANIC_NAMES = {
    "immobilize": "使敌人无法自主移动", "ground": "缚地敌人",
    "ally_aid": "治疗或保护友方英雄", "dash": "自身突进",
    "blink": "自身闪烁", "teleport": "自身传送", "leap": "自身跳跃",
    "leave_stealth": "离开隐身或伪装", "summon": "召出可作战的单位",
    "dot": "向目标施加持续伤害",
    "spin": "旋转攻击", "enhanced_attack": "强化普通攻击本体",
}


def skill_fingerprint(skill):
    text = skill["name"] + "\n" + skill["description"]
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:20]


def read_facts():
    path = Path(__file__).with_name("skill-condition-facts.tsv")
    with path.open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def build_links(champions, augments, targets):
    """Return augment ID -> champion ID -> skill-text evidence, without sample counts."""
    patch = augments["patch"]
    if not champions["version"].startswith(patch + "."):
        return {}
    if "byId" in targets:
        if targets.get("patch") != patch:
            return {}
        targets = targets["byId"]
    enabled = {}
    for aid, (phrase, mechanics) in AUGMENT_MECHANICS.items():
        card = augments["byId"].get(aid)
        if not card or targets.get(aid, {}).get("kind") != "conditional":
            continue
        if phrase in card["description"] and skill_fingerprint(card) == REVIEWED_AUGMENTS[aid]:
            enabled[aid] = mechanics

    spells = {(hid, s["slot"]): s for hid, champ in champions["byId"].items() for s in champ["skills"]}
    result = {}
    seen = set()
    for fact in read_facts():
        hid, slot, mechanic = fact["heroId"], fact["slot"], fact["mechanic"]
        key = (hid, slot, mechanic)
        if key in seen or mechanic not in MECHANIC_NAMES or not fact["note"].strip():
            raise ValueError(f"Invalid skill-mechanic evidence: {key}")
        seen.add(key)
        skill = spells.get((hid, slot))
        if not skill or skill_fingerprint(skill) != fact["skillHash"]:
            continue
        for aid, allowed in enabled.items():
            if mechanic not in allowed:
                continue
            row = {"slot": slot, "name": skill["name"], "note": fact["note"],
                   "mechanic": MECHANIC_NAMES[mechanic], "evidenceType": "text",
                   "sourceKeys": ["champions", "mode", "strings"]}
            result.setdefault(aid, {}).setdefault(hid, []).append(row)
    return result
