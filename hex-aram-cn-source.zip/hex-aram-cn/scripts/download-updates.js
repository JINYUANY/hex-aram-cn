// Updates open the project's public HTTPS page. The local file is never overwritten.
function showReleaseNotes(text,bundled=''){
  const box=document.getElementById('release-notes');
  const releases=new Map();
  for(const source of [bundled,text]){
    let record=null;
    for(const line of source.split(/\r?\n/)){
      if(line.startsWith('## ')){
        const match=line.match(/^## (\d+\.\d+\.\d+) · (\d{4}-\d{2}-\d{2})$/);
        record=match?{version:match[1],date:match[2],lines:[]}:null;
        if(record)releases.set(record.version,record);
      }else if(record && line.startsWith('- '))record.lines.push(line.slice(2));
    }
  }
  const body=document.createDocumentFragment();
  for(const r of [...releases.values()].sort((a,b)=>b.version.localeCompare(a.version,'en',{numeric:true}))){
    const h=document.createElement('h3');h.textContent='v'+r.version+' · '+r.date;
    const list=document.createElement('ul');
    for(const text of r.lines){const li=document.createElement('li');li.textContent=text;list.append(li);}
    body.append(h,list);
  }
  if(releases.size)box.replaceChildren(body);
}
function startReleaseCheck(release,bundledNotes){
  const site=new URL('https://jinyuany.github.io/hex-aram-cn/');
  const status=document.getElementById('release-check-status');
  const button=document.getElementById('release-check');
  const versionNode=document.getElementById('release-number');
  versionNode.textContent='v'+release.version;
  versionNode.title='构建 '+release.build.slice(0,8);
  showReleaseNotes(bundledNotes);
  if(location.hash==='#updates')document.getElementById('updates').open=true;
  const offlineStatus=document.getElementById('offline-status');
  if(location.protocol==='file:'){
    const link=document.createElement('a');link.href=site.href+(location.hash || '');
    link.textContent='打开可离线使用的在线版';
    offlineStatus.append('本地副本可离线使用。联网发现新版会自动打开新版。 ',link);
  }else if(typeof navigator!=='undefined' && 'serviceWorker' in navigator){
    offlineStatus.textContent='正在准备此网址的离线副本…';
    navigator.serviceWorker.register('./offline-worker.js',{updateViaCache:'none'}).then(async reg=>{
      const report=()=>{
        if(!reg.active)return;
        const key='hex-aram-cn/program/'+new URL(reg.scope).pathname+'/'+release.build;
        caches.has(key).then(async exists=>{
          if(exists && await (await caches.open(key)).match(reg.scope))offlineStatus.textContent='本版已保存。收藏此网址，断网也可打开；联网后自动检查新版。';
        }).catch(()=>{});
      };
      navigator.serviceWorker.addEventListener('controllerchange',report);
      await navigator.serviceWorker.ready;report();
    }).catch(()=>{offlineStatus.textContent='浏览器未启用离线缓存，可使用下载版离线查询。';});
  }
  let lastNotes=bundledNotes;
  let inProgress=false;
  async function refreshNotes(){
    try{
      const url=new URL('https://raw.githubusercontent.com/JINYUANY/hex-aram-cn/main/CHANGELOG.md');
      url.searchParams.set('t',String(Date.now()));
      const response=await fetch(url,{credentials:'omit',cache:'no-store',redirect:'error',referrerPolicy:'no-referrer',signal:AbortSignal.timeout(8000)});
      if(!response.ok)return;
      const text=await response.text();
      if(text.length<100000 && text!==lastNotes && /^## .+/m.test(text)){showReleaseNotes(text,bundledNotes);lastNotes=text;}
    }catch{/* The bundled or last successfully loaded notices stay readable offline. */}
  }
  async function check(){
    if(inProgress || document.hidden)return;
    inProgress=true;
    button.disabled=true;
    status.textContent='正在检查程序更新…';
    void refreshNotes();
    try{
      const url=new URL('version.json',site);
      url.searchParams.set('t',String(Date.now()));
      const response=await fetch(url,{credentials:'omit',cache:'no-store',redirect:'error',referrerPolicy:'no-referrer',signal:AbortSignal.timeout(8000)});
      if(!response.ok)throw new Error('unavailable');
      const published=await response.json();
      if(published.project!=='hex-aram-cn' || !/^\d+\.\d+\.\d+$/.test(published.version) || !/^[a-f0-9]{64}$/.test(published.build) || !Number.isSafeInteger(published.builtAt))throw new Error('invalid release');
      if(published.build===release.build){status.textContent='已是最新公开版 v'+release.version;return;}
      const byVersion=published.version.localeCompare(release.version,'en',{numeric:true});
      if(byVersion<0 || (byVersion===0 && published.builtAt<=release.builtAt)){status.textContent='当前副本较新，等待公开版发布';return;}
      const next=new URL(site);
      next.searchParams.set('v',published.build);
      next.hash=location.hash || (location.search.startsWith('?hero=') || location.search.startsWith('?tab=')?'#'+location.search:'');
      if(location.origin===site.origin && new URL(location.href).searchParams.get('v')===published.build){
        status.textContent='公开站正在切换版本，请稍后检查';return;
      }
      status.textContent='正在打开最新公开版…';
      location.replace(next.href);
    }catch{status.textContent='暂时无法核对公开版，当前图鉴可继续使用';}
    finally{button.disabled=false;inProgress=false;}
  }
  button.addEventListener('click',check);
  window.addEventListener('online',check);
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)void check();});
  setInterval(check,300000);
  void check();
}
