// Updates open the project's public HTTPS page. The local file is never overwritten.
function startReleaseCheck(release){
  const site=new URL('https://jinyuany.github.io/hex-aram-cn/');
  const status=document.getElementById('release-check-status');
  const button=document.getElementById('release-check');
  const versionNode=document.getElementById('release-number');
  versionNode.textContent=release.build.slice(0,8);
  let inProgress=false;
  async function check(){
    if(inProgress || document.hidden)return;
    inProgress=true;
    button.disabled=true;
    try{
      const url=new URL('version.json',site);
      url.searchParams.set('t',String(Date.now()));
      const response=await fetch(url,{credentials:'omit',cache:'no-store',redirect:'error',referrerPolicy:'no-referrer',signal:AbortSignal.timeout(8000)});
      if(!response.ok)throw new Error('unavailable');
      const published=await response.json();
      if(published.project!=='hex-aram-cn' || !/^[a-f0-9]{64}$/.test(published.build) || !Number.isSafeInteger(published.builtAt))throw new Error('invalid release');
      if(published.build===release.build){status.textContent='已与公开发布版同步';return;}
      if(published.builtAt<=release.builtAt){status.textContent='当前副本较新，等待公开版发布';return;}
      const next=new URL(site);
      next.searchParams.set('v',published.build);
      next.hash=location.hash || (location.search.startsWith('?hero=') || location.search.startsWith('?tab=')?'#'+location.search:'');
      if(location.origin===site.origin && new URL(location.href).searchParams.get('v')===published.build){
        status.textContent='公开站正在切换版本，请稍后检查';return;
      }
      status.textContent='正在打开最新公开版…';
      location.replace(next.href);
    }catch{status.textContent='暂时无法核对公开版，当前图鉴可继续使用';}
    finally{button.disabled=false;inProgress=false;}
  }
  button.addEventListener('click',check);
  window.addEventListener('online',check);
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)void check();});
  setInterval(check,300000);
  void check();
}
