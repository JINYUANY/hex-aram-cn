// Updates open the project's public HTTPS page. The local file is never overwritten.
function showReleaseNotes(text){
  const box=document.getElementById('release-notes');
  const body=document.createDocumentFragment();
  let list=null,sections=0;
  for(const line of text.split(/\r?\n/)){
    if(line.startsWith('## ')){
      if(++sections>6)break;
      const heading=document.createElement('h3');heading.textContent=line.slice(3);
      list=document.createElement('ul');body.append(heading,list);
    }else if(list && line.startsWith('- ')){
      const item=document.createElement('li');item.textContent=line.slice(2);list.append(item);
    }
  }
  if(sections)box.replaceChildren(body);
}
function startReleaseCheck(release,bundledNotes){
  const site=new URL('https://jinyuany.github.io/hex-aram-cn/');
  const status=document.getElementById('release-check-status');
  const button=document.getElementById('release-check');
  const versionNode=document.getElementById('release-number');
  versionNode.textContent='v'+release.version;
  versionNode.title='构建 '+release.build.slice(0,8);
  showReleaseNotes(bundledNotes);
  if(location.hash==='#updates')document.getElementById('updates').open=true;
  let lastNotes=bundledNotes;
  let inProgress=false;
  async function refreshNotes(){
    try{
      const url=new URL('https://raw.githubusercontent.com/JINYUANY/hex-aram-cn/main/CHANGELOG.md');
      url.searchParams.set('t',String(Date.now()));
      const response=await fetch(url,{credentials:'omit',cache:'no-store',redirect:'error',referrerPolicy:'no-referrer',signal:AbortSignal.timeout(8000)});
      if(!response.ok)return;
      const text=await response.text();
      if(text.length<100000 && text!==lastNotes && /^## .+/m.test(text)){showReleaseNotes(text);lastNotes=text;}
    }catch{/* The bundled or last successfully loaded notices stay readable offline. */}
  }
  async function check(){
    if(inProgress || document.hidden)return;
    inProgress=true;
    button.disabled=true;
    status.textContent='正在检查程序更新…';
    void refreshNotes();
    try{
      const url=new URL('version.json',site);
      url.searchParams.set('t',String(Date.now()));
      const response=await fetch(url,{credentials:'omit',cache:'no-store',redirect:'error',referrerPolicy:'no-referrer',signal:AbortSignal.timeout(8000)});
      if(!response.ok)throw new Error('unavailable');
      const published=await response.json();
      if(published.project!=='hex-aram-cn' || !/^\d+\.\d+\.\d+$/.test(published.version) || !/^[a-f0-9]{64}$/.test(published.build) || !Number.isSafeInteger(published.builtAt))throw new Error('invalid release');
      if(published.build===release.build){status.textContent='已是最新公开版 v'+release.version;return;}
      const byVersion=published.version.localeCompare(release.version,'en',{numeric:true});
      if(byVersion<0 || (byVersion===0 && published.builtAt<=release.builtAt)){status.textContent='当前副本较新，等待公开版发布';return;}
      const next=new URL(site);
      next.searchParams.set('v',published.build);
      next.hash=location.hash || (location.search.startsWith('?hero=') || location.search.startsWith('?tab=')?'#'+location.search:'');
      if(location.origin===site.origin && new URL(location.href).searchParams.get('v')===published.build){
        status.textContent='公开站正在切换版本，请稍后检查';return;
      }
      status.textContent='正在打开最新公开版…';
      location.replace(next.href);
    }catch{status.textContent='暂时无法核对公开版，当前图鉴可继续使用';}
    finally{button.disabled=false;inProgress=false;}
  }
  button.addEventListener('click',check);
  window.addEventListener('online',check);
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)void check();});
  setInterval(check,300000);
  void check();
}
