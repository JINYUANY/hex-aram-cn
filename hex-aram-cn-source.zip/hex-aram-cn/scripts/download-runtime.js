// This runs inside the downloadable HTML. Data requests stay local unless an
// existing source adapter explicitly asks for a public HTTPS resource.
function openDownloadCache(name){
  return new Promise(resolve=>{
    let request;
    try{request=indexedDB.open(name,1);}catch{resolve(null);return;}
    request.onupgradeneeded=()=>request.result.createObjectStore('snapshots');
    request.onsuccess=()=>resolve(request.result);
    request.onerror=request.onblocked=()=>resolve(null);
  });
}
function downloadBucket(database){
  const memory=new Map();
  async function localRead(key){
    if(!database)return memory.get(key);
    return new Promise(resolve=>{
      try{
        const get=database.transaction('snapshots').objectStore('snapshots').get(key);
        get.onsuccess=()=>resolve(get.result || memory.get(key));
        get.onerror=()=>resolve(memory.get(key));
      }catch{resolve(memory.get(key));}
    });
  }
  return {
    async get(key){
      const row=await localRead(key);
      return row?{etag:row.etag,json:async()=>JSON.parse(row.data)}:null;
    },
    async put(key,data,{onlyIf}){
      const row={data,etag:crypto.randomUUID()};
      const matches=old=>onlyIf.etagMatches?old?.etag===onlyIf.etagMatches:!old;
      const fallback=()=>{if(!matches(memory.get(key)))return null;memory.set(key,row);return {etag:row.etag};};
      if(!database)return fallback();
      return new Promise(resolve=>{
        try{
          const tx=database.transaction('snapshots','readwrite'),store=tx.objectStore('snapshots');
          const get=store.get(key);let changed=false;
          get.onsuccess=()=>{if(matches(get.result)){store.put(row,key);changed=true;}};
          tx.oncomplete=()=>{if(changed)memory.set(key,row);resolve(changed?{etag:row.etag}:null);};
          tx.onabort=()=>resolve(fallback());
        }catch{resolve(fallback());}
      });
    }
  };
}
